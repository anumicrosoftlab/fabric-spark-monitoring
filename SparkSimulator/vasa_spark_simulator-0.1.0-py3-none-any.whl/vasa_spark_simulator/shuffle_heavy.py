"""
Shuffle-heavy Spark simulations
Simulations that incur heavy shuffle due to wide transformations.
"""


def _set_recommended_shuffle_partitions(spark, num_rows: int) -> None:
    """Set a reasonable spark.sql.shuffle.partitions for large synthetic jobs.

    Best-practice intent: avoid tiny partitions (scheduler overhead) and avoid
    gigantic partitions (stragglers / spills). We keep it conservative and
    bounded because environments vary widely (Fabric, local, small clusters).
    """

    try:
        default_parallelism = int(spark.sparkContext.defaultParallelism) or 1
    except Exception:
        default_parallelism = 1

    # Heuristic: 2–4x parallelism, with caps to avoid runaway partition counts.
    multiplier = 4 if num_rows >= 50_000_000 else 2
    target = max(default_parallelism * multiplier, 200)
    target = min(target, 2000)

    try:
        spark.conf.set("spark.sql.shuffle.partitions", str(target))
    except Exception:
        # Non-fatal: some managed environments restrict setting configs.
        pass

def shuffle_groupby(spark):
    """
    Wide groupBy aggregation on synthetic records.

    Best practices applied:
    - Right-size shuffle partitions (bounded heuristic)
    - Avoid repeated actions / recomputation
    - Keep transformations column-pruned and deterministic where practical
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=50_000_000)
    print_job_params("Shuffle Heavy GroupBy", params)
    
    num_rows = params['num_rows']

    _set_recommended_shuffle_partitions(spark, num_rows)
    
    # Create DataFrame with random experiment IDs
    print(f"🔄 Creating DataFrame with {num_rows:,} rows...")

    num_experiments = 1000
    df = spark.range(num_rows).select(
        (F.rand(42) * num_experiments).cast("int").alias("experiment_id"),
        (F.rand(7) * 200).alias("measurement"),
    )
    
    # groupBy causes shuffle
    print(f"🔀 Performing shuffle-heavy groupBy operation...")
    result = df.groupBy("experiment_id").agg(
        F.avg("measurement").alias("avg_measurement"),
        F.count("*").alias("row_count"),
    )

    group_count = result.count()  # single materializing action
    print(f"✅ Completed groupBy aggregation: {group_count:,} experiment groups processed.")

def shuffle_join(spark):
    """
    Join + multi-level aggregation typical of analytics enrichment.

    Best practices applied:
    - Right-size shuffle partitions (bounded heuristic)
    - Avoid forced pre-repartition (let Spark/AQE plan the shuffle)
    - Broadcast only truly small dimension tables
    - Cache only when reusing results across multiple actions
    """
    from pyspark.sql import functions as F
    from pyspark.sql.functions import broadcast
    from .params import get_job_parameters, print_job_params
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=10_000_000)
    print_job_params("Shuffle Heavy Join", params)
    
    num_rows = params['num_rows']

    _set_recommended_shuffle_partitions(spark, num_rows)
    
    # Create left and right DataFrames with specified size
    left_rows = num_rows
    right_rows = num_rows // 2
    num_keys = max(num_rows // 1000, 10_000)
    
    print(f"🔄 Creating left DataFrame with {left_rows:,} rows...")
    left = spark.range(left_rows).select(
        (F.rand(1) * num_keys).cast("int").alias("experiment_id"),
        (F.rand(2) * 100).alias("measurement"),
        (F.rand(3) * 365).cast("int").alias("timestamp"),
    )
    
    print(f"🔄 Creating right DataFrame with {right_rows:,} rows...")
    right = spark.range(right_rows).select(
        (F.rand(4) * num_keys).cast("int").alias("experiment_id"),
        F.when(F.rand(5) < 0.5, F.lit("Control")).otherwise(F.lit("Treatment")).alias("sample_type"),
        (F.rand(6) * 50).cast("int").alias("batch_id"),
    )

    print(f"🔀 Performing join on experiment_id (Spark will shuffle as needed)...")
    joined = left.join(right, "experiment_id", "inner")
    
    print(f"🔄 Stage 4: Multi-level aggregations and broadcast join...")
    # Create a small lookup table for broadcast join
    lookup = spark.range(50).select(
        F.col("id").cast("int").alias("batch_id"),
        F.concat(F.lit("Batch_"), F.col("id")).alias("batch_name"),
        F.when(F.col("id") % 3 == 0, F.lit("Site_A"))
        .when(F.col("id") % 3 == 1, F.lit("Site_B"))
        .otherwise(F.lit("Site_C"))
        .alias("manufacturing_site"),
    )

    enriched = joined.join(broadcast(lookup), "batch_id", "left")
    
    print(f"🔄 Stage 5: Complex multi-dimensional aggregation...")
    # Multi-level aggregation with multiple stages
    detailed_result = enriched.groupBy("sample_type", "batch_name", "manufacturing_site").agg(
        F.avg("measurement").alias("avg_measurement"),
        F.count("*").alias("record_count"),
        F.min("measurement").alias("min_measurement"),
        F.max("measurement").alias("max_measurement"),
        F.stddev("measurement").alias("stddev_measurement")
    )
    
    # Final rollup aggregation
    summary_result = detailed_result.groupBy("manufacturing_site").agg(
        F.sum("record_count").alias("total_records"),
        F.avg("avg_measurement").alias("site_avg_measurement"),
        F.count("*").alias("batch_count")
    )
    
    # Show results to trigger all stages
    summary_cached = summary_result.cache()
    site_count = summary_cached.count()  # materialize once

    print(f"\n📈 Site Summary (sample):")
    summary_cached.show(truncate=False)

    print(f"✅ Completed join + aggregation: {site_count:,} site rows produced.")

    summary_cached.unpersist()