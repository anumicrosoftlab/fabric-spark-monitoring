"""
Parameter utilities for vasa_spark_simulator jobs.
Provides helper functions to extract parameters from Spark configuration.
"""

def get_job_parameters(spark, default_num_rows=1_000_000, default_duration_minutes=5):
    """
    Extract job parameters from Spark configuration or use defaults.
    
    Args:
        spark (SparkSession): Active Spark session
        default_num_rows (int): Default number of rows if not specified
        default_duration_minutes (int): Default duration if not specified
        
    Returns:
        dict: Dictionary containing job parameters
    """
    try:
        # Try to get parameters from Spark config (set by main.py)
        num_rows = int(spark.conf.get("vasa.sim.num_rows", default_num_rows))
    except:
        num_rows = default_num_rows
    
    try:
        duration_minutes = int(spark.conf.get("vasa.sim.duration_minutes", default_duration_minutes))
    except:
        duration_minutes = default_duration_minutes
    
    try:
        # Additional optional parameters
        batch_size = int(spark.conf.get("vasa.sim.batch_size", 10000))
    except:
        batch_size = 10000
        
    try:
        memory_fraction = float(spark.conf.get("vasa.sim.memory_fraction", 0.8))
    except:
        memory_fraction = 0.8
    
    return {
        'num_rows': num_rows,
        'duration_minutes': duration_minutes,
        'batch_size': batch_size,
        'memory_fraction': memory_fraction
    }

def print_job_params(job_name, params):
    """Print job parameters in a formatted way."""
    print(f"🔧 {job_name} Parameters:")
    for key, value in params.items():
        if key == 'num_rows':
            print(f"   📊 {key}: {value:,}")
        elif 'minutes' in key:
            print(f"   ⏱️  {key}: {value} minutes")
        else:
            print(f"   ⚙️  {key}: {value}")
    print()

def simulate_duration(duration_minutes):
    """Simulate work for a specified duration.

    Historically this function did driver-side looping/sleeping, which made many
    simulations appear "driver heavy" (executors idle) even when the Spark part
    was healthy.

    Current behavior:
    - If an active SparkSession exists, spend the requested time doing work on
      executors (so utilization looks executor-heavy).
    - If Spark isn't available, fall back to a lightweight driver-side sleep.
    """

    import time

    print(f"⏱️  Simulating work for {duration_minutes} minutes...")

    # For demo purposes, treat "minutes" as ~10 seconds each (keeps tests fast).
    # In production you could change this to: duration_minutes * 60
    simulation_seconds = int(min(max(duration_minutes, 0) * 10, 300))
    if simulation_seconds <= 0:
        print("✅ Simulation skipped (duration_minutes <= 0)")
        return

    spark = None
    try:
        from pyspark.sql import SparkSession

        spark = SparkSession.getActiveSession()
    except Exception:
        spark = None

    # If Spark isn't available (e.g., local unit runs), keep behavior safe.
    if spark is None:
        start_time = time.time()
        time.sleep(min(simulation_seconds, 5))
        actual_duration = time.time() - start_time
        print(f"✅ Simulation completed after {actual_duration:.1f} seconds (driver fallback)")
        return

    sc = spark.sparkContext
    # Aim for ~one task per available core so tasks run concurrently.
    try:
        partitions = int(sc.defaultParallelism) or 1
    except Exception:
        partitions = 1
    partitions = max(1, min(partitions, 128))

    seconds_per_partition = float(simulation_seconds)

    def _burn_cpu(_):
        import math
        import time as _time

        end = _time.time() + seconds_per_partition
        acc = 0.0

        # Busy loop doing cheap math (keeps Python workers active on executors).
        while _time.time() < end:
            # Inner loop reduces time.time() calls overhead.
            for i in range(20000):
                acc += math.sqrt(i + 0.123)

        return [acc]

    start_time = time.time()
    # One Spark job whose tasks run for ~simulation_seconds.
    sc.parallelize(range(partitions), partitions).mapPartitions(_burn_cpu).sum()
    actual_duration = time.time() - start_time
    print(f"✅ Simulation completed after {actual_duration:.1f} seconds (executor workload)")