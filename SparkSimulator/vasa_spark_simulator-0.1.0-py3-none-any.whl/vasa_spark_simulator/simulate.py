"""
Unified interface to run any simulation in the vasa_spark_simulator package.
"""

from .driver_heavy import driver_heavy_collect, driver_heavy_map
from .shuffle_heavy import shuffle_groupby, shuffle_join
from .spill_heavy import spill_large_join, spill_aggregation
from .skew_heavy import skew_key_join, skew_groupby
from .bad_practices import (
    no_caching_recompute,
    python_udf_instead_of_builtin,
    groupbykey_instead_of_reducebykey,
    excessive_repartitioning,
    cartesian_product_join,
    count_then_collect,
    small_file_problem,
    broadcast_large_table,
    iterative_without_caching,
    select_star_large_table,
)
from .industry_apps import (
    pharma_etl,
    adverse_event_agg,
    patient_journey,
    genomic_variant,
    pharma_fraud,
    inventory_analytics,
    prescription_token,
    cohort_selection,
    drug_recommend,
    time_series_health,
    cost_prediction,
    log_analysis,
)

ALL_SIMULATIONS = {
    # Anti-patterns / Bad Practices (for analyzer testing)
    'driver_heavy_collect': driver_heavy_collect,
    'driver_heavy_map': driver_heavy_map,
    'no_caching_recompute': no_caching_recompute,
    'python_udf_instead_of_builtin': python_udf_instead_of_builtin,
    'groupbykey_instead_of_reducebykey': groupbykey_instead_of_reducebykey,
    'excessive_repartitioning': excessive_repartitioning,
    'cartesian_product_join': cartesian_product_join,
    'count_then_collect': count_then_collect,
    'small_file_problem': small_file_problem,
    'broadcast_large_table': broadcast_large_table,
    'iterative_without_caching': iterative_without_caching,
    'select_star_large_table': select_star_large_table,
    
    # Performance Issues (Skew, Spill, Shuffle)
    'shuffle_groupby': shuffle_groupby,
    'shuffle_join': shuffle_join,
    'spill_large_join': spill_large_join,
    'spill_aggregation': spill_aggregation,
    'skew_key_join': skew_key_join,
    'skew_groupby': skew_groupby,
    
    # Good Practice Industry Apps
    'pharma_etl': pharma_etl,
    'adverse_event_agg': adverse_event_agg,
    'patient_journey': patient_journey,
    'genomic_variant': genomic_variant,
    'pharma_fraud': pharma_fraud,
    'inventory_analytics': inventory_analytics,
    'prescription_token': prescription_token,
    'cohort_selection': cohort_selection,
    'drug_recommend': drug_recommend,
    'time_series_health': time_series_health,
    'cost_prediction': cost_prediction,
    'log_analysis': log_analysis,
}

# Numeric job mapping for easy selection (1, 2, 3...)
NUMERIC_JOB_MAP = {
    # Bad Practices / Anti-patterns (1-12)
    1: 'driver_heavy_collect',
    2: 'driver_heavy_map',
    3: 'no_caching_recompute',
    4: 'python_udf_instead_of_builtin',
    5: 'groupbykey_instead_of_reducebykey',
    6: 'excessive_repartitioning',
    7: 'cartesian_product_join',
    8: 'count_then_collect',
    9: 'small_file_problem',
    10: 'broadcast_large_table',
    11: 'iterative_without_caching',
    12: 'select_star_large_table',
    
    # Performance Issues (13-18)
    13: 'shuffle_groupby',
    14: 'shuffle_join',
    15: 'spill_large_join',
    16: 'spill_aggregation',
    17: 'skew_key_join',
    18: 'skew_groupby',
    
    # Good Practice Industry Apps (19-30)
    19: 'pharma_etl',
    20: 'adverse_event_agg',
    21: 'patient_journey',
    22: 'genomic_variant',
    23: 'pharma_fraud',
    24: 'inventory_analytics',
    25: 'prescription_token',
    26: 'cohort_selection',
    27: 'drug_recommend',
    28: 'time_series_health',
    29: 'cost_prediction',
    30: 'log_analysis',
}

# Reverse mapping for getting job number from name
JOB_NAME_TO_NUMBER = {name: num for num, name in NUMERIC_JOB_MAP.items()}

def get_job_by_number(job_number):
    """Get job name by numeric ID."""
    if job_number not in NUMERIC_JOB_MAP:
        available = ', '.join(f"{k}" for k in sorted(NUMERIC_JOB_MAP.keys()))
        raise ValueError(f"Job number {job_number} not found. Available: {available}")
    return NUMERIC_JOB_MAP[job_number]

def get_job_number(job_name):
    """Get numeric ID by job name."""
    return JOB_NAME_TO_NUMBER.get(job_name, None)

def list_simulations():
    """
    List available simulation names with numeric IDs.
    """
    return list(ALL_SIMULATIONS.keys())

def list_simulations_with_numbers():
    """
    List available simulations with their numeric IDs.
    """
    result = []
    for num in sorted(NUMERIC_JOB_MAP.keys()):
        job_name = NUMERIC_JOB_MAP[num]
        result.append((num, job_name))
    return result

def run_simulation(name_or_number, spark):
    """
    Run a simulation by name or numeric ID.

    Parameters:
        name_or_number (str or int): Simulation function name or numeric ID
        spark (SparkSession): Active SparkSession

    Returns: None
    """
    # Handle numeric input
    if isinstance(name_or_number, (int, str)) and str(name_or_number).isdigit():
        job_number = int(name_or_number)
        if job_number not in NUMERIC_JOB_MAP:
            available = ', '.join(f"{k}" for k in sorted(NUMERIC_JOB_MAP.keys()))
            raise ValueError(f"Job number {job_number} not found. Available: {available}")
        name = NUMERIC_JOB_MAP[job_number]
        print(f"🔢 Running job #{job_number}: {name}")
    else:
        # Handle string input
        name = str(name_or_number)
        job_number = get_job_number(name)
        if job_number:
            print(f"📝 Running job '{name}' (#{job_number})")
        else:
            print(f"📝 Running job '{name}' (custom)")
    
    if name not in ALL_SIMULATIONS:
        raise ValueError(f"Simulation '{name}' not found. Use list_simulations().")
    
    ALL_SIMULATIONS[name](spark)