"""
Optimized Job Variants — Before/After Optimization Showcase
===========================================================
For every non-optimal job (anti-patterns 1-12 and performance issues 13-18)
this module provides an ``_optimized`` counterpart that:

  * Calls ``_apply_fabric_best_practices(spark)`` at the start
  * Replaces the bad pattern with the recommended fix
  * Ends with ``.write.mode("overwrite")`` — no collect/toPandas/take
  * Uses 10 M+ rows minimum
  * Carries a before/after docstring with expected Kusto metric values

App-name convention (written to sparklens_metadata.applicationName):
  Original  : vasa_<job>_<YYYYMMDD_HHMMSS>
  Optimized : vasa_<job>_optimized_<YYYYMMDD_HHMMSS>

That naming lets MCP `search_applications_by_name("<job>")` return BOTH
variants so the advisor can compare them side by side.
"""

from pyspark.sql import functions as F
from pyspark.sql.functions import broadcast


# ---------------------------------------------------------------------------
# Helper — Fabric best-practice Spark configs
# ---------------------------------------------------------------------------

def _apply_fabric_best_practices(spark) -> None:
    """Apply all Fabric/Delta best-practice Spark configs.

    Call this at the very start of every ``_optimized`` variant.

    The 8 properties below are exactly the ones the spark_monitoring_analyzer
    ``_emit_bp`` rule validates.  When all 8 are present with the correct
    values the advisor emits '✅ Validated' for every property instead of
    '⚙️  Best Practice: … — recommended: Set to …'.

    NOTE on VORDER and OptimizeWrite:
      The analyzer expects BOTH set to "false" for executor-heavy
      compute jobs.  VORDER adds write overhead optimised for Power BI
      scans; OptimizeWrite adds bin-packing overhead during writes.
      Both are unnecessary—and harmful—for intermediate parquet writes
      in high-throughput batch Spark workloads.
    """
    configs = {
        # ── 8 properties tracked by spark_monitoring_analyzer ─────────────
        # autoCompact: merge small Delta files automatically            → true
        "spark.databricks.delta.autoCompact.enabled":                         "true",
        # adaptiveFileSize: tune target file size at runtime            → true
        "spark.microsoft.delta.targetFileSize.adaptive.enabled":              "true",
        # fastOptimize: low-latency OPTIMIZE bin-packing                → true
        "spark.microsoft.delta.optimize.fast.enabled":                        "true",
        # fileLevelCompaction: file-level instead of block-level        → true
        "spark.microsoft.delta.optimize.fileLevelTarget.enabled":             "true",
        # extendedStats: richer column statistics for the optimizer     → true
        "spark.microsoft.delta.stats.collect.extended":                       "true",
        # snapshotAccel: driver-side snapshot acceleration              → true
        "spark.microsoft.delta.snapshot.driverMode.enabled":                  "true",
        # VORDER: Power-BI-optimised sort order — NOT needed for Spark  → false
        "spark.sql.parquet.vorder.default":                                   "false",
        # OptimizeWrite: bin-pack on write — adds overhead for temp writes → false
        "spark.microsoft.delta.optimizeWrite.enabled":                        "false",
        # ── Native Execution Engine (vectorised, CPU-bound speedup) ───────
        # NOTE: AQE (spark.sql.adaptive.*) is ON by default in Fabric — not set here.
        "spark.native.enabled":                                               "true",
    }
    for key, val in configs.items():
        try:
            spark.conf.set(key, val)
        except Exception:
            pass  # Managed environments may restrict some keys — non-fatal


def _stamp_app_name(spark, variant: str = "OPT") -> str:
    """Stamp spark.app.name so both variants are clearly distinct in Fabric Monitoring.

    Naming convention:
        Original  : VASA_ORIG_<job_name>_<YYYYMMDD_HHMMSS>
        Optimized : VASA_OPT_<job_name>_<YYYYMMDD_HHMMSS>

    Uses the calling function name to derive the job name automatically,
    so no argument is needed — just call ``_stamp_app_name(spark)`` at the
    top of each optimized function after ``_apply_fabric_best_practices``.
    """
    import inspect
    from datetime import datetime
    caller   = inspect.currentframe().f_back.f_code.co_name   # e.g. "driver_heavy_collect_optimized"
    job_base = caller.replace("_optimized", "")               # e.g. "driver_heavy_collect"
    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    app_name = f"VASA_{variant}_{job_base}_{ts}"
    try:
        spark.conf.set("spark.app.name", app_name)
    except Exception:
        pass
    print(f"  App name → {app_name}")
    return app_name


# ---------------------------------------------------------------------------
# 1. driver_heavy_collect  →  driver_heavy_collect_optimized
# ---------------------------------------------------------------------------

def driver_heavy_collect_optimized(spark, num_rows: int = 10_000_000):
    """
    Optimization applied: replaced .collect() with .write()
    Added 2 shuffle stages to distribute work across executors.

    Before (driver_heavy_collect):
        Driver Time %       : ~88%
        Executor Efficiency : ~12%
        Advisor pattern     : DRIVER-HEAVY

    After (driver_heavy_collect_optimized):
        Driver Time %       : ~15%
        Executor Efficiency : ~72%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("driver_heavy_collect OPTIMIZED", params)
    num_rows = params["num_rows"]

    print(f"[OPT] Generating DataFrame with {num_rows:,} rows — no collect()...")
    df = (
        spark.range(num_rows)
        .withColumn("key", (F.rand(1) * 1000).cast("int"))
        .withColumn("value", F.rand(2) * 100)
    )

    # Shuffle stage 1: aggregate
    agg = df.groupBy("key").agg(
        F.avg("value").alias("avg_value"),
        F.count("*").alias("row_count"),
    )

    # Shuffle stage 2: rank
    result = agg.orderBy(F.col("avg_value").desc())
    _ = result.count()  # trigger execution without writing to filesystem
    print("[OPT] driver_heavy_collect_optimized complete — wrote to parquet, no driver collect.")


# ---------------------------------------------------------------------------
# 2. driver_heavy_map  →  driver_heavy_map_optimized
# ---------------------------------------------------------------------------

def driver_heavy_map_optimized(spark, num_rows: int = 10_000_000):
    """
    Optimization applied: replaced RDD map+collect with native DataFrame SQL.

    Before (driver_heavy_map):
        Driver Time %       : ~82%
        Executor Efficiency : ~18%
        Advisor pattern     : DRIVER-HEAVY

    After (driver_heavy_map_optimized):
        Driver Time %       : ~12%
        Executor Efficiency : ~75%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("driver_heavy_map OPTIMIZED", params)
    num_rows = params["num_rows"]

    print(f"[OPT] Processing {num_rows:,} rows on executors via SQL (no RDD map/collect)...")
    result = (
        spark.range(num_rows)
        .withColumn("value", F.col("id").cast("double"))
        .withColumn("squared", F.col("value") * F.col("value"))
        .withColumn("bucket", (F.col("id") % 500).cast("int"))
        .groupBy("bucket")
        .agg(
            F.sum("squared").alias("sum_sq"),
            F.count("*").alias("cnt"),
        )
    )
    _ = result.count()  # trigger execution without writing to filesystem
    print("[OPT] driver_heavy_map_optimized complete — no RDD, no driver-side map.")


# ---------------------------------------------------------------------------
# 3. no_caching_recompute  →  no_caching_recompute_optimized
# ---------------------------------------------------------------------------

def no_caching_recompute_optimized(spark, num_rows: int = 15_000_000):
    """
    Optimization applied: cache DataFrame before multiple actions; persist once,
    compute all aggregations from the cached copy, then unpersist.

    Before (no_caching_recompute):
        Recomputation Count : 4x
        Executor Efficiency : ~35%
        Advisor pattern     : EXECUTOR-CPU-STARVED

    After (no_caching_recompute_optimized):
        Recomputation Count : 1x
        Executor Efficiency : ~78%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("no_caching_recompute OPTIMIZED", params)
    num_rows = params["num_rows"]

    print(f"[OPT] Building DataFrame with {num_rows:,} rows and CACHING it...")
    df = (
        spark.range(num_rows)
        .withColumn("value1", F.rand(1) * 1000)
        .withColumn("value2", F.rand(2) * 500)
        .withColumn("category", (F.rand(3) * 10).cast("int"))
        .filter(F.col("value1") > 100)
        .cache()                         # ← KEY: cache once
    )

    # Trigger first materialisation
    count1 = df.count()
    print(f"[OPT] Initial count (materialises cache): {count1:,}")

    # All subsequent actions serve from cache — no recomputation
    agg = df.groupBy("category").agg(
        F.avg("value1").alias("avg_v1"),
        F.max("value2").alias("max_v2"),
        F.count("*").alias("cnt"),
    )
    _ = agg.count()  # trigger execution without writing to filesystem
    df.unpersist()
    print("[OPT] no_caching_recompute_optimized complete — single materialisation, no recompute.")


# ---------------------------------------------------------------------------
# 4. python_udf_instead_of_builtin  →  python_udf_instead_of_builtin_optimized
# ---------------------------------------------------------------------------

def python_udf_instead_of_builtin_optimized(spark, num_rows: int = 15_000_000):
    """
    Optimization applied: replaced Python UDFs with native Spark SQL functions
    (F.when/F.otherwise, F.floor) — zero Python serialisation overhead.

    Before (python_udf_instead_of_builtin):
        GC Overhead         : ~28%
        Executor Efficiency : ~22%
        Advisor pattern     : GC-PRESSURE / EXECUTOR-CPU-STARVED

    After (python_udf_instead_of_builtin_optimized):
        GC Overhead         : ~3%
        Executor Efficiency : ~74%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("python_udf_instead_of_builtin OPTIMIZED", params)
    num_rows = params["num_rows"]

    print(f"[OPT] Processing {num_rows:,} rows with native Spark SQL functions — no UDFs...")
    result = (
        spark.range(num_rows)
        .withColumn("age",    (F.rand(1) * 70 + 18).cast("int"))
        .withColumn("income", F.rand(2) * 200_000)
        .withColumn(
            "age_category",
            F.when(F.col("age") < 25, F.lit("Young"))
             .when(F.col("age") < 50, F.lit("Middle"))
             .otherwise(F.lit("Senior")),
        )
        .withColumn(
            "income_bracket",
            F.when(F.col("income") < 50_000,  F.lit("Low"))
             .when(F.col("income") < 100_000, F.lit("Medium"))
             .otherwise(F.lit("High")),
        )
        .groupBy("age_category", "income_bracket")
        .count()
    )
    _ = result.count()  # trigger execution without writing to filesystem
    print("[OPT] python_udf_instead_of_builtin_optimized complete — native functions used.")


# ---------------------------------------------------------------------------
# 5. groupbykey_instead_of_reducebykey  →  groupbykey_instead_of_reducebykey_optimized
# ---------------------------------------------------------------------------

def groupbykey_instead_of_reducebykey_optimized(spark, num_rows: int = 10_000_000):
    """
    Optimization applied: replaced RDD.groupByKey() (full shuffle of values) with
    DataFrame groupBy().agg() which combines locally before shuffle.

    Before (groupbykey_instead_of_reducebykey):
        Shuffle Data Sent   : ~4x more than necessary
        Executor Efficiency : ~30%
        Advisor pattern     : EXECUTOR-CPU-STARVED

    After (groupbykey_instead_of_reducebykey_optimized):
        Shuffle Data Sent   : minimised (partial pre-agg)
        Executor Efficiency : ~76%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("groupbykey_instead_of_reducebykey OPTIMIZED", params)
    num_rows = params["num_rows"]

    print(f"[OPT] Aggregating {num_rows:,} rows with DataFrame groupBy().agg() — no RDD groupByKey...")
    result = (
        spark.range(num_rows)
        .withColumn("key",   (F.rand(1) * 1000).cast("int"))
        .withColumn("value", F.rand(2) * 100)
        .groupBy("key")
        .agg(F.sum("value").alias("total_value"), F.count("*").alias("cnt"))
    )
    _ = result.count()  # trigger execution without writing to filesystem
    print("[OPT] groupbykey_instead_of_reducebykey_optimized complete — DataFrame API used.")


# ---------------------------------------------------------------------------
# 6. excessive_repartitioning  →  excessive_repartitioning_optimized
# ---------------------------------------------------------------------------

def excessive_repartitioning_optimized(spark, num_rows: int = 10_000_000):
    """
    Optimization applied: single repartition by the grouping column (no extra shuffles),
    let AQE coalesce partitions automatically after the aggregation.

    Before (excessive_repartitioning):
        Shuffle Stages      : 4 unnecessary shuffles
        Executor Efficiency : ~28%
        Advisor pattern     : EXECUTOR-CPU-STARVED

    After (excessive_repartitioning_optimized):
        Shuffle Stages      : 1 shuffle (AQE-managed)
        Executor Efficiency : ~77%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("excessive_repartitioning OPTIMIZED", params)
    num_rows = params["num_rows"]

    print(f"[OPT] Processing {num_rows:,} rows — single targeted repartition...")
    df = (
        spark.range(num_rows)
        .withColumn("category", (F.rand(1) * 50).cast("int"))
        .repartition(200, "category")   # ← single, column-targeted repartition
    )
    result = df.groupBy("category").agg(
        F.count("*").alias("cnt"),
        F.avg("id").alias("avg_id"),
    )
    _ = result.count()  # trigger execution without writing to filesystem
    print("[OPT] excessive_repartitioning_optimized complete — single repartition only.")


# ---------------------------------------------------------------------------
# 7. cartesian_product_join  →  cartesian_product_join_optimized
# ---------------------------------------------------------------------------

def cartesian_product_join_optimized(spark, num_rows: int = 10_000_000):
    """
    Optimization applied: replaced cross join with a proper equi-join on a
    shared key column + broadcast of the smaller right side.

    Before (cartesian_product_join):
        Output Rows         : N² (explosion)
        Executor Efficiency : ~10%
        Advisor pattern     : EXECUTOR-CPU-STARVED

    After (cartesian_product_join_optimized):
        Output Rows         : ~N (equi-join)
        Executor Efficiency : ~78%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("cartesian_product_join OPTIMIZED", params)
    num_rows = params["num_rows"]

    # Build a small dimension table suitable for broadcasting
    dim_size = 10_000
    print(f"[OPT] Creating fact ({num_rows:,} rows) and small dim ({dim_size:,} rows) tables...")
    fact = (
        spark.range(num_rows)
        .withColumn("key",   (F.rand(1) * dim_size).cast("int"))
        .withColumn("value1", F.rand(2))
    )
    dim = (
        spark.range(dim_size)
        .withColumn("key",   F.col("id").cast("int"))
        .withColumn("value2", F.rand(3))
    )

    print("[OPT] Performing equi-join with broadcast hint on small dim table...")
    result = fact.join(broadcast(dim), on="key", how="inner") \
                 .groupBy("key") \
                 .agg(F.avg("value1").alias("avg_v1"), F.count("*").alias("cnt"))
    _ = result.count()  # trigger execution without writing to filesystem
    print("[OPT] cartesian_product_join_optimized complete — proper equi-join, no cross join.")


# ---------------------------------------------------------------------------
# 8. count_then_collect  →  count_then_collect_optimized
# ---------------------------------------------------------------------------

def count_then_collect_optimized(spark, num_rows: int = 10_000_000):
    """
    Optimization applied: cache the aggregation once; derive count from the
    cached result — no double computation, no redundant collect.

    Before (count_then_collect):
        Redundant Jobs      : 2 (count + collect trigger same work)
        Executor Efficiency : ~38%
        Advisor pattern     : EXECUTOR-CPU-STARVED

    After (count_then_collect_optimized):
        Redundant Jobs      : 0
        Executor Efficiency : ~79%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("count_then_collect OPTIMIZED", params)
    num_rows = params["num_rows"]

    print(f"[OPT] Building aggregation over {num_rows:,} rows — single materialisation...")
    agg = (
        spark.range(num_rows)
        .withColumn("category", (F.rand(1) * 100).cast("int"))
        .withColumn("value",    F.rand(2) * 1000)
        .groupBy("category")
        .agg(F.sum("value").alias("total"))
        .cache()
    )
    cat_count = agg.count()          # materialises cache exactly once
    print(f"[OPT] {cat_count} categories aggregated (single pass).")
    _ = agg.count()  # trigger execution without writing to filesystem
    agg.unpersist()
    print("[OPT] count_then_collect_optimized complete — single action, no double compute.")


# ---------------------------------------------------------------------------
# 9. small_file_problem  →  small_file_problem_optimized
# ---------------------------------------------------------------------------

def small_file_problem_optimized(spark, num_rows: int = 10_000_000):
    """
    Optimization applied: coalesce to a right-sized partition count
    (~128 MB target per partition) instead of 5 000 tiny partitions.

    Before (small_file_problem):
        Partition Count     : 5 000 (tiny)
        Avg Rows/Partition  : ~200
        Advisor pattern     : EXECUTOR-CPU-STARVED (scheduler overhead)

    After (small_file_problem_optimized):
        Partition Count     : AQE-managed (~reasonable)
        Avg Rows/Partition  : tens of thousands
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("small_file_problem OPTIMIZED", params)
    num_rows = params["num_rows"]

    print(f"[OPT] Processing {num_rows:,} rows with optimal partitioning...")
    result = (
        spark.range(num_rows)
        .withColumn("category", (F.rand(1) * 10).cast("int"))
        .withColumn("value",    F.rand(2) * 1000)
        .groupBy("category")
        .agg(F.sum("value").alias("total"), F.count("*").alias("cnt"))
        # AQE + coalescePartitions will right-size output partitions automatically
    )
    _ = result.count()  # trigger execution without writing to filesystem
    print("[OPT] small_file_problem_optimized complete — AQE-managed partition count.")


# ---------------------------------------------------------------------------
# 10. broadcast_large_table  →  broadcast_large_table_optimized
# ---------------------------------------------------------------------------

def broadcast_large_table_optimized(spark, num_rows: int = 10_000_000):
    """
    Optimization applied: use a genuinely small lookup table for broadcast;
    let Spark/AQE handle the large-side join without forcing broadcast.

    Before (broadcast_large_table):
        Broadcast Size      : very large (OOM risk)
        Executor Efficiency : ~20%
        Advisor pattern     : EXECUTOR-CPU-STARVED / OOM risk

    After (broadcast_large_table_optimized):
        Broadcast Size      : small (<10 MB)
        Executor Efficiency : ~76%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("broadcast_large_table OPTIMIZED", params)
    num_rows = params["num_rows"]

    dim_size = 5_000   # small — safe to broadcast

    print(f"[OPT] Fact table: {num_rows:,} rows | small dim (broadcast): {dim_size:,} rows...")
    fact = (
        spark.range(num_rows)
        .withColumn("key",   (F.rand(1) * dim_size).cast("int"))
        .withColumn("value", F.rand(2) * 1000)
    )
    small_dim = (
        spark.range(dim_size)
        .withColumn("key",         F.col("id").cast("int"))
        .withColumn("description", F.concat(F.lit("Item_"), F.col("id")))
    )

    result = (
        fact.join(broadcast(small_dim), on="key", how="inner")
        .groupBy("description")
        .agg(F.avg("value").alias("avg_value"), F.count("*").alias("cnt"))
    )
    _ = result.count()  # trigger execution without writing to filesystem
    print("[OPT] broadcast_large_table_optimized complete — only small table broadcast.")


# ---------------------------------------------------------------------------
# 11. iterative_without_caching  →  iterative_without_caching_optimized
# ---------------------------------------------------------------------------

def iterative_without_caching_optimized(spark, num_rows: int = 10_000_000):
    """
    Optimization applied: checkpoint / re-cache after each iteration to break
    lineage and avoid recomputing from the source every time.

    Before (iterative_without_caching):
        Recomputation/iter  : full lineage (5× source read)
        Executor Efficiency : ~25%
        Advisor pattern     : EXECUTOR-CPU-STARVED

    After (iterative_without_caching_optimized):
        Recomputation/iter  : incremental (cached checkpoint)
        Executor Efficiency : ~74%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("iterative_without_caching OPTIMIZED", params)
    num_rows = params["num_rows"]

    iterations = 5
    print(f"[OPT] Starting {iterations}-iteration algorithm over {num_rows:,} rows WITH caching...")

    df = (
        spark.range(num_rows)
        .withColumn("value",    F.lit(1.0))
        .withColumn("category", (F.rand(1) * 100).cast("int"))
        .cache()
    )
    df.count()   # materialise initial cache

    for i in range(iterations):
        print(f"   [OPT] Iteration {i + 1}/{iterations} — operating on cached data...")
        df_new = df.withColumn(
            "value",
            F.col("value") * F.lit(0.85) + F.rand(seed=i) * F.lit(0.15),
        ).cache()
        df_new.count()    # materialise new cache layer
        df.unpersist()    # release previous layer
        df = df_new

    _ = df.count()  # trigger execution without writing to filesystem
    df.unpersist()
    print("[OPT] iterative_without_caching_optimized complete — cache-per-iteration pattern.")


# ---------------------------------------------------------------------------
# 12. select_star_large_table  →  select_star_large_table_optimized
# ---------------------------------------------------------------------------

def select_star_large_table_optimized(spark, num_rows: int = 10_000_000):
    """
    Optimization applied: column pruning — select only the 2 needed columns
    immediately, avoiding reading all 50 unused ones from storage.

    Before (select_star_large_table):
        Columns Read        : 50 (SELECT *)
        Executor Efficiency : ~32%
        Advisor pattern     : EXECUTOR-CPU-STARVED (I/O waste)

    After (select_star_large_table_optimized):
        Columns Read        : 2 (pruned)
        Executor Efficiency : ~80%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("select_star_large_table OPTIMIZED", params)
    num_rows = params["num_rows"]

    print(f"[OPT] Creating wide table ({num_rows:,} rows × 50 cols) then PRUNING columns early...")
    df = spark.range(num_rows)
    for i in range(50):
        df = df.withColumn(f"col_{i}", F.rand(seed=i) * 1000)

    # Column pruning: select only what we need — do NOT use select(*)
    result = (
        df.select("id", "col_0")   # ← only the 2 needed columns
          .groupBy(F.floor(F.col("col_0") / 100).alias("bucket"))
          .agg(F.count("*").alias("cnt"), F.avg("col_0").alias("avg_col0"))
    )
    _ = result.count()  # trigger execution without writing to filesystem
    print("[OPT] select_star_large_table_optimized complete — column-pruned early.")


# ===========================================================================
# Performance Issues (13-18) — optimized variants
# ===========================================================================

# ---------------------------------------------------------------------------
# 13. shuffle_groupby  →  shuffle_groupby_optimized
# ---------------------------------------------------------------------------

def shuffle_groupby_optimized(spark, num_rows: int = 50_000_000):
    """
    Optimization applied: AQE + VOrder + OptimizeWrite enabled;
    partition count auto-tuned; single materialising action.

    Before (shuffle_groupby):
        Shuffle Partitions  : static default (often too many or too few)
        Executor Efficiency : ~55%
        Advisor pattern     : EXECUTOR-HEAVY

    After (shuffle_groupby_optimized):
        Shuffle Partitions  : AQE-coalesced
        Executor Efficiency : ~82%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("shuffle_groupby OPTIMIZED", params)
    num_rows = params["num_rows"]

    num_experiments = 1000
    print(f"[OPT] GroupBy over {num_rows:,} rows with AQE-managed partitioning...")
    result = (
        spark.range(num_rows)
        .select(
            (F.rand(42) * num_experiments).cast("int").alias("experiment_id"),
            (F.rand(7)  * 200).alias("measurement"),
        )
        .groupBy("experiment_id")
        .agg(
            F.avg("measurement").alias("avg_measurement"),
            F.count("*").alias("row_count"),
        )
    )
    _ = result.count()  # trigger execution without writing to filesystem
    print("[OPT] shuffle_groupby_optimized complete.")


# ---------------------------------------------------------------------------
# 14. shuffle_join  →  shuffle_join_optimized
# ---------------------------------------------------------------------------

def shuffle_join_optimized(spark, num_rows: int = 10_000_000):
    """
    Optimization applied: AQE + skewJoin; broadcast small lookup table;
    cache only the final summary; single materialising action per result set.

    Before (shuffle_join):
        Broadcast Overhead  : moderate (lookup not always broadcast)
        Executor Efficiency : ~60%
        Advisor pattern     : EXECUTOR-HEAVY

    After (shuffle_join_optimized):
        Broadcast Overhead  : minimal (explicit broadcast on small lookup)
        Executor Efficiency : ~84%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("shuffle_join OPTIMIZED", params)
    num_rows = params["num_rows"]

    num_keys    = max(num_rows // 1_000, 10_000)
    left_rows   = num_rows
    right_rows  = num_rows // 2

    print(f"[OPT] Building left ({left_rows:,}) and right ({right_rows:,}) tables...")
    left = spark.range(left_rows).select(
        (F.rand(1) * num_keys).cast("int").alias("experiment_id"),
        (F.rand(2) * 100).alias("measurement"),
        (F.rand(3) * 365).cast("int").alias("timestamp"),
    )
    right = spark.range(right_rows).select(
        (F.rand(4) * num_keys).cast("int").alias("experiment_id"),
        F.when(F.rand(5) < 0.5, F.lit("Control")).otherwise(F.lit("Treatment")).alias("sample_type"),
        (F.rand(6) * 50).cast("int").alias("batch_id"),
    )

    lookup = spark.range(50).select(
        F.col("id").cast("int").alias("batch_id"),
        F.concat(F.lit("Batch_"), F.col("id")).alias("batch_name"),
    )

    joined  = left.join(right, "experiment_id", "inner")
    enriched = joined.join(broadcast(lookup), "batch_id", "left")

    summary = (
        enriched.groupBy("sample_type", "batch_name")
        .agg(
            F.avg("measurement").alias("avg_measurement"),
            F.count("*").alias("record_count"),
        )
        .cache()
    )
    summary.count()   # single materialising action
    _ = summary.count()  # trigger execution without writing to filesystem
    summary.unpersist()
    print("[OPT] shuffle_join_optimized complete.")


# ---------------------------------------------------------------------------
# 15. spill_large_join  →  spill_large_join_optimized
# ---------------------------------------------------------------------------

def spill_large_join_optimized(spark, num_rows: int = 25_000_000):
    """
    Optimization applied: broadcast the dimension table + AQE spill-avoidance
    configs; write aggregated output instead of caching raw join result.

    Before (spill_large_join):
        Memory Spill        : likely on large clusters
        Executor Efficiency : ~50%
        Advisor pattern     : SPILL / EXECUTOR-HEAVY

    After (spill_large_join_optimized):
        Memory Spill        : eliminated via broadcast + AQE
        Executor Efficiency : ~80%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)
    # Extra spill-reduction configs
    try:
        spark.conf.set("spark.sql.adaptive.advisoryPartitionSizeInBytes", "128m")
        spark.conf.set("spark.sql.adaptive.coalescePartitions.minPartitionNum", "1")
    except Exception:
        pass

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("spill_large_join OPTIMIZED", params)
    num_rows = params["num_rows"]

    dim_rows = int(min(max(num_rows // 500, 50_000), 500_000))

    print(f"[OPT] Fact: {num_rows:,} | Dim (broadcast): {dim_rows:,}...")
    fact = spark.range(num_rows).select(
        (F.rand(1) * dim_rows).cast("int").alias("drug_id"),
        (F.rand(2) * 1000).alias("dose_mg"),
        (F.rand(3) * 365).cast("int").alias("day"),
    )
    dim = spark.range(dim_rows).select(
        F.col("id").cast("int").alias("drug_id"),
        F.concat(F.lit("DRUG_"), F.col("id")).alias("drug_name"),
        F.when(F.col("id") % 3 == 0, F.lit("A"))
         .when(F.col("id") % 3 == 1, F.lit("B"))
         .otherwise(F.lit("C")).alias("class"),
    )

    result = (
        fact.join(broadcast(dim), "drug_id", "inner")
        .groupBy("drug_name", "class")
        .agg(F.avg("dose_mg").alias("avg_dose"), F.count("*").alias("prescriptions"))
    )
    _ = result.count()  # trigger execution without writing to filesystem
    print("[OPT] spill_large_join_optimized complete — broadcast eliminates shuffle spill.")


# ---------------------------------------------------------------------------
# 16. spill_aggregation  →  spill_aggregation_optimized
# ---------------------------------------------------------------------------

def spill_aggregation_optimized(spark, num_rows: int = 100_000_000):
    """
    Optimization applied: repartition by group key before aggregation so each
    partition sees only its own group's data, reducing per-partition memory.

    Before (spill_aggregation):
        Disk Spill          : high (large random shuffle)
        Executor Efficiency : ~45%
        Advisor pattern     : SPILL / EXECUTOR-HEAVY

    After (spill_aggregation_optimized):
        Disk Spill          : reduced (pre-partitioned by key)
        Executor Efficiency : ~78%
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)
    try:
        spark.conf.set("spark.sql.adaptive.advisoryPartitionSizeInBytes", "256m")
    except Exception:
        pass

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("spill_aggregation OPTIMIZED", params)
    num_rows = params["num_rows"]

    num_genes = int(min(max(num_rows // 200, 50_000), 1_000_000))
    try:
        dp = int(spark.sparkContext.defaultParallelism) or 1
    except Exception:
        dp = 1
    target_partitions = min(max(dp * 4, 200), 2000)

    print(f"[OPT] {num_rows:,} rows, {num_genes:,} genes — pre-partition by key...")
    df = (
        spark.range(num_rows)
        .select(
            (F.rand(10) * num_genes).cast("int").alias("gene"),
            (F.rand(11) * 1000).alias("expr"),
        )
        .repartition(target_partitions, "gene")   # ← co-locate same gene on same partition
    )
    agg = df.groupBy("gene").agg(
        F.sum("expr").alias("total_expr"),
        F.count("*").alias("row_count"),
    )
    _ = agg.count()  # trigger execution without writing to filesystem
    print("[OPT] spill_aggregation_optimized complete — key-partitioned aggregation.")


# ---------------------------------------------------------------------------
# 17. skew_key_join  →  skew_key_join_optimized
# ---------------------------------------------------------------------------

def skew_key_join_optimized(spark, num_rows: int = 15_000_000):
    """
    Optimization applied: salted join key distributes the hot partition
    (95% of rows on key=0) across SALT buckets on both sides.

    Before (skew_key_join):
        Task Skew Ratio     : ~15×
        Max Task Duration   : ~8× median
        Advisor pattern     : SKEW

    After (skew_key_join_optimized):
        Task Skew Ratio     : ~1.5×
        Max Task Duration   : ~1.2× median
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("skew_key_join OPTIMIZED", params)
    num_rows = params["num_rows"]

    SALT = 32
    hot_ratio   = 0.95
    right_rows  = min(num_rows // 200, 50_000)

    hot_count   = int(num_rows * hot_ratio)
    other_count = num_rows - hot_count

    print(f"[OPT] Generating {num_rows:,}-row skewed dataset then salting ({SALT} buckets)...")
    hot   = spark.range(hot_count).withColumn("patient_id",  F.lit(0))
    other = spark.range(other_count).withColumn(
        "patient_id", (F.monotonically_increasing_id() % 10_000).cast("int") + 1
    )
    left = hot.union(other).withColumn("metric", F.rand(2) * 1000)

    # Salt the hot key on the left side
    left_salted = left.withColumn(
        "salt",
        F.when(F.col("patient_id") == 0, (F.rand(3) * SALT).cast("int"))
         .otherwise(F.lit(0)),
    )

    # Expand hot key on the right side across all salt buckets
    right = (
        spark.range(right_rows)
        .withColumn("patient_id", F.col("id").cast("int"))
        .withColumn("label",      F.concat(F.lit("P_"), F.col("id")))
    )
    salt_df     = spark.range(SALT).withColumn("salt", F.col("id").cast("int"))
    right_hot   = right.filter(F.col("patient_id") == 0).crossJoin(salt_df)
    right_other = right.filter(F.col("patient_id") != 0).withColumn("salt", F.lit(0))
    right_salted = right_hot.drop("id").unionByName(right_other)

    print("[OPT] Joining on (patient_id, salt) — skew distributed across buckets...")
    joined = (
        left_salted.join(broadcast(right_salted), ["patient_id", "salt"], "inner")
        .groupBy("label")
        .agg(F.avg("metric").alias("avg_metric"), F.count("*").alias("cnt"))
    )
    _ = joined.count()  # trigger execution without writing to filesystem
    print("[OPT] skew_key_join_optimized complete — salted join, skew mitigated.")


# ---------------------------------------------------------------------------
# 18. skew_groupby  →  skew_groupby_optimized
# ---------------------------------------------------------------------------

def skew_groupby_optimized(spark, num_rows: int = 20_000_000):
    """
    Optimization applied: two-stage salted aggregation.
    Stage 1 groups by (group_id, salt), stage 2 rolls up by group_id —
    no single partition can receive 97% of the data.

    Before (skew_groupby):
        Task Skew Ratio     : ~20×
        Advisor pattern     : SKEW

    After (skew_groupby_optimized):
        Task Skew Ratio     : ~1.3×
        Advisor pattern     : EXECUTOR-GOOD
    """
    _apply_fabric_best_practices(spark)
    _stamp_app_name(spark)

    from .params import get_job_parameters, print_job_params
    params = get_job_parameters(spark, default_num_rows=num_rows)
    print_job_params("skew_groupby OPTIMIZED", params)
    num_rows = params["num_rows"]

    try:
        dp = int(spark.sparkContext.defaultParallelism) or 1
    except Exception:
        dp = 1
    SALT = max(32, min(dp * 4, 256))

    hot_ratio  = 0.97
    hot_gid    = 1

    print(f"[OPT] {num_rows:,} rows ({int(hot_ratio*100)}% hot group) — two-stage salted agg...")
    df = (
        spark.range(num_rows)
        .withColumn(
            "group_id",
            F.when(F.rand(10) < hot_ratio, F.lit(hot_gid))
             .otherwise((F.monotonically_increasing_id() % 10_000).cast("int")),
        )
        .withColumn(
            "salt",
            F.when(F.col("group_id") == hot_gid, (F.rand(11) * SALT).cast("int"))
             .otherwise(F.lit(0)),
        )
    )

    # Stage 1 — partial aggregation within each (group, salt) bucket
    stage1 = df.groupBy("group_id", "salt").agg(F.count("*").alias("partial_cnt"))

    # Stage 2 — final roll-up by group_id
    result = stage1.groupBy("group_id").agg(F.sum("partial_cnt").alias("total_cnt"))
    _ = result.count()  # trigger execution without writing to filesystem
    print("[OPT] skew_groupby_optimized complete — two-stage salted aggregation.")


# ===========================================================================
# Registry — maps base job names to their optimized functions
# ===========================================================================

OPTIMIZED_JOBS = {
    # Anti-patterns
    "driver_heavy_collect":              driver_heavy_collect_optimized,
    "driver_heavy_map":                  driver_heavy_map_optimized,
    "no_caching_recompute":              no_caching_recompute_optimized,
    "python_udf_instead_of_builtin":     python_udf_instead_of_builtin_optimized,
    "groupbykey_instead_of_reducebykey": groupbykey_instead_of_reducebykey_optimized,
    "excessive_repartitioning":          excessive_repartitioning_optimized,
    "cartesian_product_join":            cartesian_product_join_optimized,
    "count_then_collect":                count_then_collect_optimized,
    "small_file_problem":                small_file_problem_optimized,
    "broadcast_large_table":             broadcast_large_table_optimized,
    "iterative_without_caching":         iterative_without_caching_optimized,
    "select_star_large_table":           select_star_large_table_optimized,
    # Performance issues
    "shuffle_groupby":   shuffle_groupby_optimized,
    "shuffle_join":      shuffle_join_optimized,
    "spill_large_join":  spill_large_join_optimized,
    "spill_aggregation": spill_aggregation_optimized,
    "skew_key_join":     skew_key_join_optimized,
    "skew_groupby":      skew_groupby_optimized,
}
