"""
Driver-heavy Spark simulations
Simulations where most of the workload, either in memory or compute, happens on the Driver node.
"""

def driver_heavy_collect(spark):
    """
    Simulates a Spark job that collects a very large dataset to the driver.
    Not recommended in production, used here to illustrate bad patterns.

    Args:
        spark (SparkSession): An active SparkSession.

    Returns: None
    """
    import random
    import string
    from pyspark.sql.functions import monotonically_increasing_id
    from .params import get_job_parameters, print_job_params
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=5_000_000)
    print_job_params("Driver Heavy Collect", params)
    
    num_rows = params['num_rows']
    
    # Generate a DataFrame with specified size
    print(f"🔄 Generating DataFrame with {num_rows:,} rows...")
    df = spark.range(num_rows).withColumn("random_str",
        (monotonically_increasing_id() % 1000)
    )
    # Collect entire dataset to driver!
    print(f"⚠️  Collecting {num_rows:,} rows to driver (anti-pattern)...")
    data = df.collect()
    print(f"✅ Collected {len(data):,} rows to driver memory.")

def driver_heavy_map(spark):
    """
    Simulates a job using excessive driver-side mapping (convert DataFrame to RDD and collect).
    """
    from .params import get_job_parameters, print_job_params
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=1_000_000)
    print_job_params("Driver Heavy Map", params)
    
    num_rows = params['num_rows']
    
    # Generate a DataFrame with specified size
    print(f"🔄 Generating DataFrame with {num_rows:,} rows...")
    df = spark.range(num_rows).withColumnRenamed("id", "value")
    
    # Convert to RDD and collect, then perform driver-side map operation
    print(f"⚠️  Converting to RDD and collecting {num_rows:,} rows to driver...")
    data = df.rdd.collect()
    
    # Perform complex logic on driver
    print(f"🔄 Processing {len(data):,} rows in driver memory...")
    processed = [x[0] ** 2 for x in data]
    print(f"✅ Processed {len(processed):,} rows with driver-side computation.")
