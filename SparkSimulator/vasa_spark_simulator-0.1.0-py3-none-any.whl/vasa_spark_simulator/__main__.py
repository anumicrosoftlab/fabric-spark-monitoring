"""
Entry point for running vasa_spark_simulator as a module.
Supports: python -m vasa_spark_simulator
"""

from .main import main

if __name__ == "__main__":
    main()