#!/usr/bin/env python3
"""
Main entry point for vasa_spark_simulator package on Microsoft Fabric.
Provides command-line interface to run specific Spark jobs with parameters.
"""

import argparse
import os
import sys
import time
from typing import Optional, Union
from pyspark.sql import SparkSession
from vasa_spark_simulator.simulate import (
    run_simulation, list_simulations, list_simulations_with_numbers, 
    ALL_SIMULATIONS, get_job_by_number, NUMERIC_JOB_MAP
)


def create_fabric_spark_session(
    app_name: str = "VasaSparkSimulator",
    spark_master: Optional[str] = None,
    require_yarn: bool = False,
) -> SparkSession:
    """
    Create a Spark session optimized for Microsoft Fabric.
    Pipeline-safe: No notebook dependencies, handles session cleanup automatically.
    """
    try:
        # For pipeline usage, try to reuse existing session if available and healthy
        try:
            existing_session = SparkSession.getActiveSession()
            if existing_session is not None:
                # Check if session is healthy
                try:
                    existing_session.sparkContext.statusTracker()
                    print(f"✅ Reusing existing healthy Spark session")
                    print(f"📊 Application ID: {existing_session.sparkContext.applicationId}")
                    print(f"🔧 Spark Version: {existing_session.version}")

                    active_master = existing_session.sparkContext.master
                    print(f"🧭 Spark Master: {active_master}")

                    # If the user requested a specific master, we can't change it on an existing session.
                    if spark_master is None:
                        spark_master = os.getenv("VASA_SPARK_MASTER")
                    if spark_master and spark_master != active_master:
                        print(
                            f"⚠️  Requested master '{spark_master}' but active session master is '{active_master}'. "
                            f"Master cannot be changed after the session is created; continuing with the active session."
                        )

                    if require_yarn:
                        master_lower = (active_master or "").lower()
                        if not master_lower.startswith("yarn"):
                            raise RuntimeError(
                                f"Spark is not running on YARN (master={active_master}). "
                                f"Stop the existing session and start a YARN-backed Spark session."
                            )
                    return existing_session
                except:
                    # Session exists but unhealthy, clean it up
                    print("🧹 Existing session unhealthy, cleaning up...")
                    existing_session.stop()
                    import time
                    time.sleep(2)  # Give it time to fully stop
        except:
            pass  # No existing session or already stopped
        
        # Resolve master selection.
        # In managed environments (e.g., Fabric), the master is set by the platform.
        # Only set it explicitly when the user asks (arg/env).
        if spark_master is None:
            spark_master = os.getenv("VASA_SPARK_MASTER")

        builder = SparkSession.builder.appName(app_name)
        if spark_master:
            builder = builder.master(spark_master)

        # Create new session with Fabric-optimized settings
        spark = builder \
            .config("spark.sql.adaptive.enabled", "true") \
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true") \
            .config("spark.sql.adaptive.advisoryPartitionSizeInBytes", "128MB") \
            .config("spark.sql.adaptive.skewJoin.enabled", "true") \
            .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
            .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
            .getOrCreate()
        
        print(f"✅ Spark session created successfully")
        print(f"📊 Application ID: {spark.sparkContext.applicationId}")
        print(f"🔧 Spark Version: {spark.version}")
        print(f"🧭 Spark Master: {spark.sparkContext.master}")

        if require_yarn:
            master = (spark.sparkContext.master or "").lower()
            if not master.startswith("yarn"):
                raise RuntimeError(
                    f"Spark is not running on YARN (master={spark.sparkContext.master}). "
                    f"Run on a YARN-backed Spark (e.g., spark-submit --master yarn) "
                    f"or pass a master via --master / VASA_SPARK_MASTER where supported."
                )
        return spark
        
    except Exception as e:
        print(f"❌ Failed to create Spark session: {e}")
        # For pipeline usage, raise the exception instead of exiting
        raise e


def run_job(
    job_identifier: Union[str, int],
    num_rows: Optional[int] = None,
    duration_minutes: Optional[int] = None,
    spark_master: Optional[str] = None,
    require_yarn: bool = False,
) -> bool:
    """
    Run a specific Spark job with optional parameters.
    
    Args:
        job_identifier: Name of the job (str) or numeric ID (int) to run
        num_rows: Number of rows to process (if applicable)
        duration_minutes: How long to run the job (if applicable)
        
    Returns:
        bool: True if successful, False otherwise
    """
    # Convert numeric ID to job name if needed
    if isinstance(job_identifier, (int, str)) and str(job_identifier).isdigit():
        job_number = int(job_identifier)
        try:
            job_name = get_job_by_number(job_number)
            print(f"🔢 Selected job #{job_number}: {job_name}")
        except ValueError as e:
            print(f"❌ {e}")
            return False
    else:
        job_name = str(job_identifier)
        print(f"📝 Selected job: {job_name}")
    
    if job_name not in ALL_SIMULATIONS:
        print(f"❌ Job '{job_name}' not found!")
        print(f"📋 Available jobs:")
        for num, name in list_simulations_with_numbers():
            print(f"  {num:2d}. {name}")
        return False
    
    start_time = time.time()
    spark = None
    
    try:
        # Create Spark session with better error handling
        spark = create_fabric_spark_session(
            f"VasaSimulator_{job_name}",
            spark_master=spark_master,
            require_yarn=require_yarn,
        )
        
        # Set optional parameters in Spark config if provided
        if num_rows:
            spark.conf.set("vasa.sim.num_rows", str(num_rows))
            print(f"📊 Set num_rows parameter: {num_rows:,}")
            
        if duration_minutes:
            spark.conf.set("vasa.sim.duration_minutes", str(duration_minutes))
            print(f"⏱️  Set duration_minutes parameter: {duration_minutes}")
        
        # Run the simulation
        print(f"🔄 Executing {job_name}...")
        run_simulation(job_name, spark)
        
        elapsed_time = time.time() - start_time
        print(f"✅ Job '{job_name}' completed successfully in {elapsed_time:.2f} seconds")
        
        return True
        
    except Exception as e:
        print(f"❌ Job '{job_name}' failed: {str(e)}")
        elapsed_time = time.time() - start_time
        print(f"⏱️  Failed after {elapsed_time:.2f} seconds")
        
        # If this is a session conflict error, suggest emergency cleanup
        if "Promise already completed" in str(e) or "IllegalStateException" in str(e):
            print("💡 This appears to be a Spark session conflict.")
            print("💡 Try running the emergency cleanup cell first, then retry the job.")
        
        return False
        
    finally:
        # For pipeline usage: Only stop session if explicitly requested
        # Pipelines may want to reuse sessions across multiple jobs
        if spark is not None:
            try:
                # Instead of always stopping, just ensure session is in good state
                spark.sparkContext.statusTracker()  # Health check
                print(f"🔍 Spark session remains active for potential reuse")
            except:
                # Session is unhealthy, clean it up
                try:
                    spark.stop()
                    print(f"🛑 Unhealthy Spark session stopped")
                except:
                    print("⚠️  Session cleanup encountered minor issues (this is normal)")
                    pass


def main():
    """
    Main entry point for command-line execution.
    """
    parser = argparse.ArgumentParser(
        description="Vasa Spark Simulator - Run pharma industry Spark workload simulations",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m vasa_spark_simulator --list
  python -m vasa_spark_simulator --job pharma_etl
  python -m vasa_spark_simulator --job driver_heavy_collect --num-rows 1000000
  python -m vasa_spark_simulator --job adverse_event_agg --duration 5
        """
    )
    
    parser.add_argument(
        "--list", "-l",
        action="store_true",
        help="List all available simulation jobs"
    )
    
    parser.add_argument(
        "--job", "-j",
        type=str,
        help="Name of the simulation job to run"
    )
    
    parser.add_argument(
        "--num-rows", "-n",
        type=int,
        help="Number of rows to process (for applicable jobs)"
    )
    
    parser.add_argument(
        "--duration", "-d",
        type=int,
        help="Duration in minutes to run the job (for applicable jobs)"
    )

    parser.add_argument(
        "--master",
        type=str,
        default=None,
        help="Spark master URL (e.g., 'yarn', 'yarn-client', 'local[*]'). If omitted, uses the environment default.",
    )

    parser.add_argument(
        "--require-yarn",
        action="store_true",
        help="Fail fast unless the Spark master is YARN (master starts with 'yarn').",
    )
    
    parser.add_argument(
        "--sequential", "-s",
        type=int,
        help="Run the specified job N times sequentially with fresh sessions"
    )
    
    args = parser.parse_args()
    
    # Handle list command
    if args.list:
        print("📋 Available Spark simulation jobs:")
        print("=" * 60)
        jobs_with_numbers = list_simulations_with_numbers()
        for num, job_name in jobs_with_numbers:
            print(f"{num:2d}. {job_name}")
        print(f"\n💡 Usage: --job {jobs_with_numbers[0][0]} or --job {jobs_with_numbers[0][1]}")
        print(f"📈 Total: {len(jobs_with_numbers)} jobs available")
        return 0
    
    # Validate job parameter
    if not args.job:
        print("❌ Error: --job parameter is required")
        parser.print_help()
        return 1
    
    # Handle sequential execution
    if args.sequential:
        print(f"🔄 Running job '{args.job}' {args.sequential} times sequentially...")
        successful_runs = 0
        
        for run in range(1, args.sequential + 1):
            print(f"\n{'='*60}")
            print(f"🏃 Run {run}/{args.sequential}")
            print(f"{'='*60}")
            
            success = run_job(
                args.job,
                args.num_rows,
                args.duration,
                spark_master=args.master,
                require_yarn=args.require_yarn,
            )
            if success:
                successful_runs += 1
            else:
                print(f"❌ Run {run} failed, continuing...")
            
            # Brief pause between runs
            if run < args.sequential:
                time.sleep(2)
        
        print(f"\n{'='*60}")
        print(f"🏁 Sequential execution completed!")
        print(f"✅ Successful runs: {successful_runs}/{args.sequential}")
        print(f"❌ Failed runs: {args.sequential - successful_runs}/{args.sequential}")
        
        return 0 if successful_runs > 0 else 1
    
    # Handle single job execution
    else:
        success = run_job(
            args.job,
            args.num_rows,
            args.duration,
            spark_master=args.master,
            require_yarn=args.require_yarn,
        )
        return 0 if success else 1


def fabric_notebook_entry(job_identifier: Union[str, int], **kwargs):
    """
    Entry point for Fabric notebooks.
    
    Usage in Fabric notebook:
        from vasa_spark_simulator.main import fabric_notebook_entry
        
        # By job number (easier)
        fabric_notebook_entry(1, num_rows=1000000)  # driver_heavy_collect
        fabric_notebook_entry(9)  # pharma_etl
        
        # By job name (traditional)
        fabric_notebook_entry('pharma_etl', num_rows=1000000)
    """
    print(f"🏭 Fabric Notebook Entry Point")
    
    # Handle numeric job selection
    if isinstance(job_identifier, (int, str)) and str(job_identifier).isdigit():
        job_number = int(job_identifier)
        try:
            job_name = get_job_by_number(job_number)
            print(f"🔢 Job #{job_number}: {job_name}")
        except ValueError as e:
            print(f"❌ {e}")
            print(f"📋 Available job numbers:")
            for num, name in list_simulations_with_numbers():
                print(f"  {num:2d}. {name}")
            raise Exception(f"Invalid job number: {job_identifier}")
    else:
        job_name = str(job_identifier)
        job_number = None
        for num, name in NUMERIC_JOB_MAP.items():
            if name == job_name:
                job_number = num
                break
        print(f"📝 Job: {job_name}" + (f" (#{job_number})" if job_number else ""))
    
    if kwargs:
        print(f"⚙️  Parameters: {kwargs}")
    
    # Extract parameters
    num_rows = kwargs.get('num_rows')
    duration_minutes = kwargs.get('duration_minutes') or kwargs.get('duration')
    spark_master = kwargs.get('master') or kwargs.get('spark_master')
    require_yarn = bool(kwargs.get('require_yarn') or kwargs.get('requireYarn') or False)
    
    # Run the job
    success = run_job(
        job_name,
        num_rows,
        duration_minutes,
        spark_master=spark_master,
        require_yarn=require_yarn,
    )
    
    if not success:
        raise Exception(f"Job '{job_name}' failed to execute")
    
    return f"Job '{job_name}' completed successfully"


def pipeline_entry(job_identifier: Union[str, int], **kwargs) -> dict:
    """
    Pipeline-optimized entry point for automated execution.
    
    Returns structured results for pipeline consumption.
    No notebook dependencies, optimized for session reuse.
    
    Args:
        job_identifier: Job number (1-20) or job name
        **kwargs: Parameters like num_rows, duration_minutes
        
    Returns:
        dict: Structured result with status, duration, etc.
        
    Example:
        result = pipeline_entry(1, num_rows=100000, duration_minutes=2)
        print(result['status'])  # 'success' or 'failed'
        print(result['duration'])  # execution time in seconds
    """
    import time
    
    start_time = time.time()
    
    # Handle numeric job selection
    if isinstance(job_identifier, (int, str)) and str(job_identifier).isdigit():
        job_number = int(job_identifier)
        try:
            job_name = get_job_by_number(job_number)
        except ValueError as e:
            return {
                'status': 'failed',
                'error': f"Invalid job number: {job_identifier}",
                'available_jobs': list(NUMERIC_JOB_MAP.keys()),
                'duration': time.time() - start_time
            }
    else:
        job_name = str(job_identifier)
        job_number = None
        for num, name in NUMERIC_JOB_MAP.items():
            if name == job_name:
                job_number = num
                break
    
    # Extract parameters
    num_rows = kwargs.get('num_rows')
    duration_minutes = kwargs.get('duration_minutes') or kwargs.get('duration')
    spark_master = kwargs.get('master') or kwargs.get('spark_master')
    require_yarn = bool(kwargs.get('require_yarn') or kwargs.get('requireYarn') or False)
    
    try:
        # Run the job
        success = run_job(
            job_name,
            num_rows,
            duration_minutes,
            spark_master=spark_master,
            require_yarn=require_yarn,
        )
        duration = time.time() - start_time
        
        if success:
            return {
                'status': 'success',
                'job_name': job_name,
                'job_number': job_number,
                'parameters': {
                    'num_rows': num_rows,
                    'duration_minutes': duration_minutes
                },
                'duration': duration,
                'message': f"Job '{job_name}' completed successfully"
            }
        else:
            return {
                'status': 'failed',
                'job_name': job_name,
                'job_number': job_number,
                'error': f"Job execution failed",
                'duration': duration
            }
            
    except Exception as e:
        return {
            'status': 'failed',
            'job_name': job_name if 'job_name' in locals() else str(job_identifier),
            'job_number': job_number if 'job_number' in locals() else None,
            'error': str(e),
            'duration': time.time() - start_time
        }


if __name__ == "__main__":
    sys.exit(main())