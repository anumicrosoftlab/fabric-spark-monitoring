"""
Industry/Pharma-specific Spark simulations for "vasa"
"""

def pharma_etl(spark):
    """
    Simulate pharma clinical trial ETL: load, clean, and aggregate data.
    Multi-stage pipeline with intermediate transformations.
    """
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window
    from .params import get_job_parameters, print_job_params, simulate_duration
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=5_000_000)
    print_job_params("Pharma ETL", params)
    
    num_rows = params['num_rows']
    
    print(f"🔄 Stage 1: Generating clinical trial data with {num_rows:,} records...")
    raw_df = spark.range(num_rows)\
        .withColumn("patient_id", (F.rand()*100000).cast("int"))\
        .withColumn("age", (F.rand()*70 + 18).cast("int"))\
        .withColumn("site_id", (F.rand()*100).cast("int"))\
        .withColumn("visit_day", (F.rand()*365).cast("int"))\
        .withColumn("bp_systolic", F.rand()*60 + 80)\
        .withColumn("bp_diastolic", F.rand()*40 + 60)\
        .withColumn("heart_rate", F.rand()*40 + 60)\
        .withColumn("treatment_arm", F.when(F.rand() < 0.5, "Treatment").otherwise("Control"))\
        .withColumn("dropout", F.rand() > 0.95)
    
    print(f"🔄 Stage 2: Data quality checks and enrichment...")
    # Multi-stage transformations with window functions
    patient_window = Window.partitionBy("patient_id").orderBy("visit_day")
    
    enriched_df = raw_df\
        .withColumn("bp_mean", (F.col("bp_systolic") + F.col("bp_diastolic")) / 2)\
        .withColumn("visit_sequence", F.row_number().over(patient_window))\
        .withColumn("days_since_last_visit", 
                   F.col("visit_day") - F.lag("visit_day", 1).over(patient_window))\
        .withColumn("baseline_bp", F.first("bp_mean").over(patient_window))\
        .withColumn("bp_change_from_baseline", F.col("bp_mean") - F.col("baseline_bp"))
    
    print(f"🔄 Stage 3: Filtering and data cleaning...")
    # Complex filtering logic
    clean_df = enriched_df.filter(
        (F.col("age") > 18) & 
        (F.col("age") < 80) &
        (F.col("bp_systolic") < 200) &
        (F.col("bp_diastolic") < 120) &
        (F.col("heart_rate") > 40) &
        (F.col("heart_rate") < 150)
    )
    
    # Cache for reuse in multiple aggregations
    clean_df.cache()
    print(f"   Cached cleaned dataset for reuse")
    
    print(f"🔄 Stage 4: Multi-level aggregations...")
    # Site-level statistics
    site_stats = clean_df.groupBy("site_id", "treatment_arm").agg(
        F.avg("bp_mean").alias("mean_bp"), 
        F.stddev("bp_mean").alias("stddev_bp"),
        F.avg("bp_change_from_baseline").alias("mean_bp_change"),
        F.sum(F.col("dropout").cast("int")).alias("num_dropouts"),
        F.count("*").alias("visit_count"),
        F.countDistinct("patient_id").alias("unique_patients")
    )
    
    # Patient-level summaries
    patient_stats = clean_df.groupBy("patient_id", "treatment_arm").agg(
        F.max("visit_sequence").alias("total_visits"),
        F.avg("bp_mean").alias("avg_bp"),
        F.first("baseline_bp").alias("baseline"),
        F.last("bp_mean").alias("final_bp"),
        F.max("dropout").alias("dropped_out")
    )
    
    print(f"🔄 Stage 5: Cross-join analysis for treatment efficacy...")
    # Complex analysis with multiple joins
    treatment_efficacy = patient_stats.filter(F.col("total_visits") >= 3)\
        .groupBy("treatment_arm").agg(
            F.avg("avg_bp").alias("group_avg_bp"),
            F.avg(F.col("final_bp") - F.col("baseline")).alias("group_avg_change"),
            F.count("*").alias("evaluable_patients"),
            F.sum(F.col("dropped_out").cast("int")).alias("dropouts")
        )
    
    # Trigger execution and show results
    print(f"\n📊 Site Statistics:")
    site_stats.show(20)
    print(f"\n📈 Treatment Efficacy Analysis:")
    treatment_efficacy.show()
    
    site_count = site_stats.count()
    patient_count = patient_stats.count()
    
    # Unpersist cached data
    clean_df.unpersist()
    
    print(f"✅ Completed multi-stage pharma ETL: processed {num_rows:,} visits across {site_count} site groups and {patient_count} patients.")

def adverse_event_agg(spark):
    """
    Simulate aggregation of adverse event records for reporting.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params, simulate_duration
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=2_000_000, default_duration_minutes=3)
    print_job_params("Adverse Event Aggregation", params)
    
    num_rows = params['num_rows']
    duration_minutes = params['duration_minutes']
    
    print(f"🔄 Generating adverse event data with {num_rows:,} records...")
    events = spark.range(num_rows)\
        .withColumn("event_type", (F.rand()*7).cast("int"))\
        .withColumn("severity", (F.rand()*3+1).cast("int"))
    
    print(f"📈 Aggregating adverse events...")
    result = events.groupBy("event_type").agg(
        F.count("*").alias("num"), 
        F.avg("severity").alias("avg_severity")
    )
    
    result.show()
    
    # Simulate additional processing time if duration specified
    if duration_minutes > 0:
        simulate_duration(duration_minutes)
    
    print(f"✅ Completed adverse event aggregation: {num_rows:,} events processed.")

def patient_journey(spark):
    """
    Simulate building patient journey analytic table (event sequencing).
    Uses Spark window functions for lead/lag analysis - common in patient journey analytics.
    """
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window
    from .params import get_job_parameters, print_job_params, simulate_duration
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=2_000_000, default_duration_minutes=4)
    print_job_params("Patient Journey Analysis", params)
    
    num_rows = params['num_rows']
    duration_minutes = params['duration_minutes']
    num_patients = max(num_rows // 80, 1000)  # Each patient has ~80 visits on average
    
    print(f"🔄 Generating patient visit data with {num_rows:,} visits for {num_patients:,} patients...")
    visits = spark.range(num_rows)\
        .withColumn("patient_id", (F.rand()*num_patients).cast("int"))\
        .withColumn("visit_day", (F.rand()*365).cast("int"))\
        .withColumn("treatment", F.when(F.rand()<0.5, "A").otherwise("B"))\
        .withColumn("cost", (F.rand()*500 + 50).cast("double"))
    
    # Define window for patient journey analysis (Spark window functions)
    patient_window = Window.partitionBy("patient_id").orderBy("visit_day")
    
    print(f"🔄 Computing lead/lag window functions for journey analysis...")
    journey_analysis = visits\
        .withColumn("prev_treatment", F.lag("treatment", 1).over(patient_window))\
        .withColumn("next_treatment", F.lead("treatment", 1).over(patient_window))\
        .withColumn("days_since_last", F.col("visit_day") - F.lag("visit_day", 1).over(patient_window))\
        .withColumn("cumulative_cost", F.sum("cost").over(patient_window.rowsBetween(Window.unboundedPreceding, Window.currentRow)))\
        .withColumn("visit_rank", F.row_number().over(patient_window))
    
    print(f"🔄 Building patient journey sequences...")
    result = journey_analysis.groupBy("patient_id")\
        .agg(
            F.collect_list("treatment").alias("treat_seq"),
            F.max("cumulative_cost").alias("total_cost"),
            F.avg("days_since_last").alias("avg_days_between_visits"),
            F.max("visit_rank").alias("total_visits")
        )
    
    # Trigger Spark job execution
    result.show(5)
    journey_count = result.count()
    
    # Simulate additional processing time if duration specified
    if duration_minutes > 0:
        simulate_duration(duration_minutes)
        
    print(f"✅ Completed patient journey analysis: {journey_count:,} patient journeys built from {num_rows:,} visits.")

def genomic_variant(spark):
    """
    Simulate variant frequency processing (genomics).
    Uses Spark pivot/unpivot operations - common pattern for genomic and wide-format data.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params, simulate_duration
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=50_000_000, default_duration_minutes=6)
    print_job_params("Genomic Variant Analysis", params)
    
    num_rows = params['num_rows']
    duration_minutes = params['duration_minutes']
    num_variants = min(num_rows // 1000, 50_000)  # More variants for production scale
    num_samples = min(num_rows // 5000, 10_000)    # More samples for realistic genomic studies
    
    print(f"🔄 Generating genomic variant data with {num_rows:,} variant calls...")
    df = spark.range(num_rows)\
        .withColumn("variant_id", (F.rand()*num_variants).cast("int"))\
        .withColumn("sample_id", (F.rand()*num_samples).cast("int"))\
        .withColumn("present", F.rand() < 0.025)\
        .withColumn("chromosome", (F.rand()*22 + 1).cast("int"))\
        .withColumn("quality_score", F.rand()*100)\
        .withColumn("read_depth", (F.rand()*100 + 10).cast("int"))\
        .withColumn("genotype", F.when(F.rand() < 0.6, "0/0")
                                 .when(F.rand() < 0.8, "0/1")
                                 .otherwise("1/1"))
    
    print(f"🧬 Computing variant allele frequencies with groupBy...")
    # Calculate variant frequencies
    variant_freq = df.groupBy("variant_id", "chromosome").agg(
        F.avg(F.col("present").cast("float")).alias("allele_frequency"),
        F.avg("quality_score").alias("avg_quality"),
        F.avg("read_depth").alias("avg_depth"),
        F.count("*").alias("sample_count")
    )
    
    print(f"📊 Creating chromosome-level pivot table (Spark pivot operation)...")
    # Pivot by genotype to create wide-format data (common genomic pattern)
    genotype_pivot = df.groupBy("chromosome").pivot("genotype", ["0/0", "0/1", "1/1"]).agg(
        F.count("*").alias("count")
    ).na.fill(0)
    
    # Calculate variant statistics per chromosome
    chromosome_stats = df.groupBy("chromosome").agg(
        F.countDistinct("variant_id").alias("unique_variants"),
        F.avg(F.col("present").cast("int")).alias("avg_minor_allele_freq"),
        F.avg("quality_score").alias("avg_quality"),
        F.sum(F.when(F.col("genotype") != "0/0", 1).otherwise(0)).alias("variant_calls")
    ).orderBy("chromosome")
    
    # Trigger Spark job execution
    print(f"\n🧦 Variant Frequency Summary:")
    variant_freq.show(10)
    print(f"\n📊 Genotype Distribution by Chromosome (Pivoted):")
    genotype_pivot.orderBy("chromosome").show(23)
    print(f"\n📈 Chromosome Statistics:")
    chromosome_stats.show(23)
    
    variant_count = variant_freq.count()
    
    # Simulate additional processing time if duration specified
    if duration_minutes > 0:
        simulate_duration(duration_minutes)
    
    print(f"✅ Completed genomic variant frequency processing: {variant_count:,} unique variants analyzed from {num_rows:,} samples.")

def pharma_fraud(spark):
    """
    Simulate pharma sales fraud detection using rule-based analytics.
    Uses Spark array functions, explode, and UDFs - common patterns for complex data processing.
    """
    from pyspark.sql import functions as F
    from pyspark.sql.types import ArrayType, StringType, StructType, StructField, DoubleType
    from .params import get_job_parameters, print_job_params, simulate_duration
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=1_000_000, default_duration_minutes=8)
    print_job_params("Pharmaceutical Fraud Detection", params)
    
    num_rows = params['num_rows']
    duration_minutes = params['duration_minutes']
    
    print(f"🔄 Generating pharmaceutical sales data with {num_rows:,} transactions...")
    sales = spark.range(num_rows).withColumn("rep_id", (F.rand()*300).cast("int"))\
        .withColumn("claim_amount", F.rand()*10000)\
        .withColumn("quantity", (F.rand()*100 + 1).cast("int"))\
        .withColumn("discount_rate", F.rand()*0.5)\
        .withColumn("region", F.when(F.rand() < 0.25, "North")
                              .when(F.rand() < 0.5, "South")
                              .when(F.rand() < 0.75, "East")
                              .otherwise("West"))
    
    print(f"🔍 Creating fraud detection rules using array functions...")
    # Use Spark array functions to build fraud indicators
    sales_with_flags = sales.withColumn("fraud_indicators", 
        F.array(
            F.when(F.col("claim_amount") > 8000, F.lit("high_claim")).otherwise(F.lit(None)),
            F.when(F.col("quantity") > 80, F.lit("high_quantity")).otherwise(F.lit(None)),
            F.when(F.col("discount_rate") > 0.4, F.lit("excessive_discount")).otherwise(F.lit(None)),
            F.when(F.col("claim_amount") / F.col("quantity") > 150, F.lit("high_unit_price")).otherwise(F.lit(None))
        )
    )
    
    # Filter array to remove nulls and count indicators
    sales_analyzed = sales_with_flags.withColumn(
        "active_flags", F.array_compact(F.col("fraud_indicators"))
    ).withColumn(
        "flag_count", F.size(F.col("active_flags"))
    ).withColumn(
        "is_suspicious", F.col("flag_count") > 0
    )
    
    print(f"📊 Exploding fraud indicators for detailed analysis...")
    # Explode array for per-indicator analysis (common Spark pattern)
    exploded_flags = sales_analyzed.filter(F.col("is_suspicious"))\
        .select("rep_id", "region", "claim_amount", F.explode("active_flags").alias("fraud_type"))
    
    # Aggregate by fraud type
    fraud_by_type = exploded_flags.groupBy("fraud_type").agg(
        F.count("*").alias("occurrence_count"),
        F.avg("claim_amount").alias("avg_claim_amount"),
        F.countDistinct("rep_id").alias("unique_reps")
    )
    
    # Aggregate suspicious activity by rep
    fraud_by_rep = sales_analyzed.filter(F.col("is_suspicious"))\
        .groupBy("rep_id", "region").agg(
            F.sum("claim_amount").alias("total_suspicious_amount"),
            F.count("*").alias("suspicious_transaction_count"),
            F.avg("flag_count").alias("avg_flags_per_transaction"),
            F.collect_set(F.col("active_flags")[0]).alias("flag_types_seen")
        )
    
    # Trigger Spark job execution
    print(f"\n🚩 Fraud by Type:")
    fraud_by_type.show()
    print(f"\n👤 Top Suspicious Representatives:")
    fraud_by_rep.orderBy(F.desc("suspicious_transaction_count")).show(10)
    
    suspicious_reps = fraud_by_rep.count()
    
    # Simulate additional processing time if duration specified
    if duration_minutes > 0:
        simulate_duration(duration_minutes)
    
    print(f"✅ Completed pharma fraud simulation: {suspicious_reps:,} representatives flagged from {num_rows:,} transactions analyzed.")

def inventory_analytics(spark):
    """
    Simulate analytics on pharma inventory and supply chain data.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params, simulate_duration
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=200_000, default_duration_minutes=4)
    print_job_params("Inventory Analytics", params)
    
    num_rows = params['num_rows']
    duration_minutes = params['duration_minutes']
    
    print(f"🔄 Generating pharmaceutical inventory data with {num_rows:,} items...")
    inventory = spark.range(num_rows).withColumn("warehouse", (F.rand()*50).cast("int"))\
        .withColumn("stock", (F.rand()*10000).cast("int"))\
        .withColumn("reorder_point", (F.rand()*1000 + 500).cast("int"))\
        .withColumn("drug_category", (F.rand()*10).cast("int"))\
        .withColumn("reorder", F.col("stock") < F.col("reorder_point"))
        
    print(f"📊 Computing inventory analytics and reorder recommendations...")
    # Reorder stats per warehouse with detailed analytics
    analytics = inventory.groupBy("warehouse").agg(
        F.avg(F.col("reorder").cast("int")).alias("reorder_fraction"),
        F.sum("stock").alias("total_stock"),
        F.count("*").alias("item_count"),
        F.countDistinct("drug_category").alias("category_diversity")
    )
    
    # Trigger Spark job execution
    analytics.show(10)
    warehouse_count = analytics.count()
    
    # Simulate additional processing time if duration specified
    if duration_minutes > 0:
        simulate_duration(duration_minutes)
    
    print(f"✅ Completed inventory analytics: {warehouse_count:,} warehouses analyzed from {num_rows:,} inventory items.")

def prescription_token(spark):
    """
    Simulate prescription tokenization and de-id for privacy.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params, simulate_duration
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=500_000, default_duration_minutes=3)
    print_job_params("Prescription Tokenization", params)
    
    num_rows = params['num_rows']
    duration_minutes = params['duration_minutes']
    
    print(f"🔄 Generating prescription data with {num_rows:,} prescriptions...")
    df = spark.range(num_rows).withColumn("presc_id", (F.rand()*100_000).cast("int"))\
        .withColumn("patient_id", (F.rand()*50_000).cast("int"))\
        .withColumn("doctor_id", (F.rand()*2_000).cast("int"))\
        .withColumn("drug_ndc", (F.rand()*10_000).cast("string"))\
        .withColumn("quantity", (F.rand()*90 + 10).cast("int"))
        
    print(f"🔐 Tokenizing prescription data for privacy compliance...")
    # Create comprehensive tokenization with multiple hash tokens
    tokenized = df.withColumn("patient_token", F.hash(F.col("patient_id")))\
        .withColumn("doctor_token", F.hash(F.col("doctor_id")))\
        .withColumn("presc_token", F.sha2(F.concat(F.col("presc_id").cast("string")), 256))\
        .drop("patient_id", "doctor_id", "presc_id")
        
    # Trigger Spark job execution
    tokenized.show(10)
    tokenized_count = tokenized.count()
    
    # Simulate additional processing time if duration specified
    if duration_minutes > 0:
        simulate_duration(duration_minutes)
    
    print(f"✅ Completed prescription tokenization: {tokenized_count:,} prescriptions tokenized and de-identified.")

def cohort_selection(spark):
    """
    Simulate patient cohort selection for targeting.
    Uses Spark window functions with rank/percent_rank for patient prioritization - common pattern in cohort analytics.
    """
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window
    from .params import get_job_parameters, print_job_params, simulate_duration
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=1_000_000, default_duration_minutes=5)
    print_job_params("Patient Cohort Selection", params)
    
    num_rows = params['num_rows']
    duration_minutes = params['duration_minutes']
    
    print(f"🔄 Generating patient screening data with {num_rows:,} patients...")
    patients = spark.range(num_rows).withColumn("age", (F.rand()*70+18).cast("int"))\
        .withColumn("condition", (F.rand()*10).cast("int"))\
        .withColumn("bmi", F.rand()*20 + 18)\
        .withColumn("compliance_score", F.rand())\
        .withColumn("site_id", (F.rand()*50).cast("int"))\
        .withColumn("eligible", F.rand() > 0.9)
        
    print(f"🎯 Applying cohort selection criteria...")
    # Select cohort with multiple criteria
    cohort = patients.filter(
        (F.col("age") > 45) & (F.col("age") < 75) &
        (F.col("condition") < 5) &
        (F.col("bmi") > 20) & (F.col("bmi") < 35) &
        (F.col("compliance_score") > 0.7) &
        (F.col("eligible") == True)
    )
    
    # Define window for ranking within each site (Spark window functions)
    site_window = Window.partitionBy("site_id").orderBy(F.desc("compliance_score"))
    condition_window = Window.partitionBy("condition").orderBy(F.desc("compliance_score"))
    
    print(f"📊 Computing patient rankings with window functions...")
    # Apply ranking - common Spark pattern for prioritization
    ranked_cohort = cohort\
        .withColumn("site_rank", F.rank().over(site_window))\
        .withColumn("site_dense_rank", F.dense_rank().over(site_window))\
        .withColumn("compliance_percentile", F.percent_rank().over(condition_window))\
        .withColumn("ntile_group", F.ntile(4).over(condition_window))
    
    # Select top candidates per site
    top_candidates = ranked_cohort.filter(F.col("site_rank") <= 10)
    
    # Additional cohort analytics
    cohort_summary = ranked_cohort.groupBy("condition").agg(
        F.count("*").alias("patient_count"),
        F.avg("age").alias("avg_age"),
        F.avg("compliance_score").alias("avg_compliance"),
        F.avg("compliance_percentile").alias("avg_percentile")
    )
    
    # Trigger Spark job execution
    top_candidates.show(10)
    cohort_summary.show()
    selected_count = ranked_cohort.count()
    top_count = top_candidates.count()
    
    # Simulate additional processing time if duration specified
    if duration_minutes > 0:
        simulate_duration(duration_minutes)
    
    print(f"✅ Completed cohort selection: {selected_count:,} patients selected ({top_count:,} top candidates) from {num_rows:,} patients screened.")

def drug_recommend(spark):
    """
    Simulate drug recommendation using broadcast join with drug formulary.
    Uses Spark broadcast join optimization - common pattern for joining large tables with small lookup tables.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params, simulate_duration
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=200_000, default_duration_minutes=6)
    print_job_params("Drug Recommendation Engine", params)
    
    num_rows = params['num_rows']
    duration_minutes = params['duration_minutes']
    
    print(f"🔄 Generating patient diagnosis data with {num_rows:,} records...")
    records = spark.range(num_rows).withColumn("diag_code", (F.rand()*500).cast("int"))\
        .withColumn("patient_age", (F.rand()*70 + 18).cast("int"))\
        .withColumn("severity", (F.rand()*5).cast("int"))\
        .withColumn("comorbidity_count", (F.rand()*3).cast("int"))
    
    # Create drug formulary lookup table (small dimension table for broadcast join)
    print(f"📋 Creating drug formulary lookup table for broadcast join...")
    drug_data = [(i, f"Drug_{chr(65 + i % 26)}", ["Low", "Medium", "High"][i % 3], 10.0 + (i * 2.5)) 
                 for i in range(500)]
    drug_formulary = spark.createDataFrame(drug_data, 
        ["diag_code", "drug_name", "default_dosage", "unit_cost"])
    
    # Broadcast join - Spark optimization for small table joins
    print(f"💊 Performing broadcast join with drug formulary...")
    from pyspark.sql.functions import broadcast
    result = records.join(
        broadcast(drug_formulary), 
        on="diag_code", 
        how="left"
    )
    
    # Adjust dosage based on severity and age
    result = result.withColumn("adjusted_dosage",
        F.when((F.col("severity") >= 4) | (F.col("patient_age") > 65), "High")
        .when(F.col("severity") <= 1, "Low")
        .otherwise(F.col("default_dosage"))
    ).withColumn("estimated_cost",
        F.col("unit_cost") * F.when(F.col("adjusted_dosage") == "High", 2.0)
        .when(F.col("adjusted_dosage") == "Medium", 1.5)
        .otherwise(1.0)
    )
    
    # Generate recommendation summary
    recommendation_summary = result.groupBy("drug_name", "adjusted_dosage").agg(
        F.count("*").alias("recommendation_count"),
        F.avg("patient_age").alias("avg_patient_age"),
        F.sum("estimated_cost").alias("total_cost")
    )
    
    # Trigger Spark job execution
    recommendation_summary.show()
    total_recommendations = result.count()
    
    # Simulate additional processing time if duration specified
    if duration_minutes > 0:
        simulate_duration(duration_minutes)
    
    print(f"✅ Completed drug recommendation: {total_recommendations:,} recommendations generated from {num_rows:,} patient records.")

def time_series_health(spark):
    """
    Simulate time series analysis of patient vital signs.
    Uses Spark window functions for rolling averages and anomaly detection - common time series patterns.
    """
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window
    from .params import get_job_parameters, print_job_params, simulate_duration
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=5_000_000, default_duration_minutes=8)
    print_job_params("Health Time Series Analysis", params)
    
    num_rows = params['num_rows']
    duration_minutes = params['duration_minutes']
    
    print(f"🔄 Generating health monitoring time series with {num_rows:,} readings...")
    df = spark.range(num_rows).withColumn("patient_id", (F.rand()*50_000).cast("int"))\
        .withColumn("timestamp", (F.rand()*365*2).cast("int"))\
        .withColumn("heart_rate", (F.rand()*40 + 60).cast("double"))\
        .withColumn("blood_pressure_sys", (F.rand()*60 + 90).cast("double"))\
        .withColumn("blood_pressure_dia", (F.rand()*30 + 60).cast("double"))\
        .withColumn("temperature", (F.rand()*4 + 96.5).cast("double"))\
        .withColumn("month", (F.col("timestamp") / 30).cast("int"))
    
    # Define window for rolling time series analysis (Spark window functions)
    time_window = Window.partitionBy("patient_id").orderBy("timestamp")
    rolling_window = time_window.rowsBetween(-6, 0)  # 7-day rolling window
    
    print(f"📈 Computing rolling averages and anomaly detection with window functions...")
    # Apply rolling window calculations - typical Spark time series pattern
    df_with_rolling = df\
        .withColumn("rolling_avg_hr", F.avg("heart_rate").over(rolling_window))\
        .withColumn("rolling_avg_bp", F.avg("blood_pressure_sys").over(rolling_window))\
        .withColumn("hr_deviation", F.abs(F.col("heart_rate") - F.col("rolling_avg_hr")))\
        .withColumn("is_anomaly", F.when(F.col("hr_deviation") > 15, True).otherwise(False))\
        .withColumn("prev_reading", F.lag("heart_rate", 1).over(time_window))\
        .withColumn("hr_change", F.col("heart_rate") - F.col("prev_reading"))
        
    print(f"📊 Computing patient health trends and anomaly summaries...")
    # Comprehensive health analytics with rolling trends
    patient_trends = df_with_rolling.groupBy("patient_id").agg(
        F.avg("heart_rate").alias("avg_heart_rate"),
        F.stddev("heart_rate").alias("hr_variability"),
        F.avg("blood_pressure_sys").alias("avg_sys_bp"),
        F.max("temperature").alias("max_temperature"),
        F.sum(F.col("is_anomaly").cast("int")).alias("anomaly_count"),
        F.count("*").alias("reading_count")
    )
    
    # Monthly health trends
    monthly_trends = df_with_rolling.groupBy("month").agg(
        F.avg("heart_rate").alias("monthly_avg_hr"),
        F.avg("blood_pressure_sys").alias("monthly_avg_bp"),
        F.sum(F.col("is_anomaly").cast("int")).alias("monthly_anomalies"),
        F.count("*").alias("monthly_readings")
    ).orderBy("month")
    
    # Trigger Spark job execution
    patient_trends.show(10)
    monthly_trends.show(20)
    total_patients = patient_trends.count()
    
    # Simulate additional processing time if duration specified
    if duration_minutes > 0:
        simulate_duration(duration_minutes)
    
    print(f"✅ Completed health time series analysis: {total_patients:,} patient health profiles from {num_rows:,} vital sign readings.")

def cost_prediction(spark):
    """
    Simulate healthcare cost prediction using comprehensive ML feature engineering.
    GOOD PRACTICE EXAMPLE: Demonstrates optimal Spark patterns with proper caching, 
    broadcast joins, and column pruning.
    """
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window
    from .params import get_job_parameters, print_job_params, simulate_duration
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=8_000_000, default_duration_minutes=10)
    print_job_params("Healthcare Cost Prediction (GOOD PRACTICES)", params)
    
    num_rows = params['num_rows']
    duration_minutes = params['duration_minutes']
    
    print(f"🔄 Stage 1: Generating healthcare claims data with {num_rows:,} records...")
    claims_df = spark.range(num_rows)\
        .withColumn("patient_id", (F.rand()*200_000).cast("int"))\
        .withColumn("provider_id", (F.rand()*5_000).cast("int"))\
        .withColumn("diagnosis_code", (F.rand()*1000 + 1).cast("int"))\
        .withColumn("procedure_code", (F.rand()*500 + 1).cast("int"))\
        .withColumn("claim_amount", F.rand()*50000 + 100)\
        .withColumn("patient_age", (F.rand()*70 + 18).cast("int"))\
        .withColumn("length_of_stay", (F.rand()*14 + 1).cast("int"))\
        .withColumn("claim_date", (F.rand()*730).cast("int"))\
        .withColumn("chronic_conditions", (F.rand()*5).cast("int"))
    
    print(f"🔄 Stage 2: GOOD PRACTICE - Select only needed columns early...")
    # GOOD: Column pruning early in pipeline to reduce shuffle data
    core_claims = claims_df.select("patient_id", "provider_id", "diagnosis_code", 
                                  "procedure_code", "claim_amount", "patient_age",
                                  "length_of_stay", "claim_date", "chronic_conditions")
    
    print(f"🔄 Stage 3: GOOD PRACTICE - Cache frequently reused DataFrame...")
    # GOOD: Cache intermediate results that will be reused multiple times
    core_claims.cache()
    
    print(f"🔄 Stage 4: Feature engineering with window functions...")
    patient_window = Window.partitionBy("patient_id").orderBy("claim_date")
    
    # Create comprehensive features using window functions
    featured_claims = core_claims\
        .withColumn("claim_sequence", F.row_number().over(patient_window))\
        .withColumn("cumulative_cost", F.sum("claim_amount").over(
            patient_window.rowsBetween(Window.unboundedPreceding, Window.currentRow)))\
        .withColumn("avg_prev_claim", F.avg("claim_amount").over(
            patient_window.rowsBetween(Window.unboundedPreceding, -1)))\
        .withColumn("days_since_last_claim", 
                   F.col("claim_date") - F.lag("claim_date", 1).over(patient_window))\
        .withColumn("is_readmission", F.col("days_since_last_claim") < 30)
    
    print(f"🔄 Stage 5: GOOD PRACTICE - Create small lookup table for broadcast join...")
    # GOOD: Create small dimension table for broadcast join
    provider_lookup = spark.range(5000)\
        .withColumn("provider_id", F.col("id"))\
        .withColumn("provider_type", F.when(F.col("id") % 5 == 0, "Hospital")
                                     .when(F.col("id") % 5 == 1, "Clinic") 
                                     .when(F.col("id") % 5 == 2, "Specialist")
                                     .when(F.col("id") % 5 == 3, "Lab")
                                     .otherwise("Pharmacy"))\
        .withColumn("region", F.when(F.col("id") % 4 == 0, "North")
                             .when(F.col("id") % 4 == 1, "South")
                             .when(F.col("id") % 4 == 2, "East")
                             .otherwise("West"))\
        .select("provider_id", "provider_type", "region")  # Select only needed columns
    
    print(f"🔄 Stage 6: GOOD PRACTICE - Use broadcast join for small lookup...")
    from pyspark.sql.functions import broadcast
    # GOOD: Broadcast small lookup table instead of shuffle join
    enriched_claims = featured_claims.join(
        broadcast(provider_lookup), "provider_id", "left"
    )
    
    print(f"🔄 Stage 7: Multi-level aggregations for ML features...")
    # Patient-level features
    patient_features = enriched_claims.groupBy("patient_id").agg(
        F.avg("claim_amount").alias("avg_claim_amount"),
        F.sum("claim_amount").alias("total_healthcare_cost"),
        F.max("cumulative_cost").alias("lifetime_cost"),
        F.count("*").alias("total_claims"),
        F.sum(F.col("is_readmission").cast("int")).alias("readmission_count"),
        F.avg("length_of_stay").alias("avg_los"),
        F.first("patient_age").alias("age"),
        F.first("chronic_conditions").alias("chronic_conditions"),
        F.countDistinct("provider_type").alias("provider_diversity"),
        F.collect_set("region").alias("regions_visited")
    )
    
    # Provider performance metrics  
    provider_metrics = enriched_claims.groupBy("provider_id", "provider_type").agg(
        F.avg("claim_amount").alias("provider_avg_cost"),
        F.count("*").alias("provider_volume"),
        F.avg("length_of_stay").alias("provider_avg_los"),
        F.sum(F.col("is_readmission").cast("int")).alias("provider_readmissions")
    )
    
    print(f"🔄 Stage 8: Risk stratification and cost prediction model preparation...")
    # Create risk tiers based on multiple factors
    risk_stratified = patient_features\
        .withColumn("cost_per_claim", F.col("total_healthcare_cost") / F.col("total_claims"))\
        .withColumn("readmission_rate", F.col("readmission_count") / F.col("total_claims"))\
        .withColumn("risk_score", 
                   F.col("age") * 0.1 + 
                   F.col("chronic_conditions") * 2 + 
                   F.col("readmission_rate") * 10)\
        .withColumn("risk_tier", 
                   F.when(F.col("risk_score") > 15, "High")
                   .when(F.col("risk_score") > 8, "Medium")
                   .otherwise("Low"))
    
    # Final aggregations for model insights
    risk_summary = risk_stratified.groupBy("risk_tier").agg(
        F.count("*").alias("patient_count"),
        F.avg("total_healthcare_cost").alias("avg_total_cost"),
        F.avg("cost_per_claim").alias("avg_cost_per_claim"),
        F.avg("readmission_rate").alias("avg_readmission_rate"),
        F.avg("provider_diversity").alias("avg_provider_diversity")
    )
    
    # Show results and trigger execution
    print(f"\n📊 Risk Stratification Summary:")
    risk_summary.show()
    
    print(f"\n🏥 Provider Performance (Top 15):")
    provider_metrics.orderBy(F.desc("provider_volume")).show(15)
    
    print(f"\n👥 Patient Risk Profile Sample:")
    risk_stratified.select("patient_id", "risk_tier", "total_healthcare_cost", 
                          "readmission_rate", "provider_diversity").show(10)
    
    total_patients = risk_stratified.count()
    total_providers = provider_metrics.count()
    
    print(f"🔄 Stage 9: GOOD PRACTICE - Unpersist cached DataFrame...")
    # GOOD: Clean up cached data when no longer needed
    core_claims.unpersist()
    
    # Simulate additional processing time if duration specified
    if duration_minutes > 0:
        simulate_duration(duration_minutes)
    
    print(f"✅ Completed cost prediction pipeline: analyzed {total_patients:,} patients and {total_providers:,} providers from {num_rows:,} claims.")
    print(f"🎯 GOOD PRACTICES DEMONSTRATED:")
    print(f"   ✅ Early column pruning to reduce shuffle data")
    print(f"   ✅ Caching intermediate results for reuse")
    print(f"   ✅ Broadcast joins for small lookup tables") 
    print(f"   ✅ Proper resource cleanup with unpersist()")
    print(f"   ✅ Multi-stage pipeline with clear separation of concerns")
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params, simulate_duration
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=2_000_000, default_duration_minutes=5)
    print_job_params("Cost Prediction Analysis", params)
    
    num_rows = params['num_rows']
    duration_minutes = params['duration_minutes']
    
    print(f"🔄 Generating patient cost data with {num_rows:,} records...")
    df = spark.range(num_rows).withColumn("age_group", (F.rand()*6).cast("int"))\
        .withColumn("cost", F.rand()*40000)
    
    print(f"💰 Computing cost predictions by age group...")
    stats = df.groupBy("age_group").agg(
        F.avg("cost").alias("avg_cost"), 
        F.max("cost").alias("max_cost"),
        F.count("*").alias("patient_count")
    )
    
    # Trigger Spark job execution
    stats.show()
    group_count = stats.count()
    
    # Simulate additional processing time if duration specified
    if duration_minutes > 0:
        simulate_duration(duration_minutes)
    
    print(f"✅ Completed cost prediction analysis: {group_count:,} age groups analyzed from {num_rows:,} patient records.")

def log_analysis(spark):
    """
    Simulate large-scale log analysis with optimal Spark patterns.
    BEST PRACTICE EXAMPLE: Shows proper partitioning, caching, and aggregation strategies.
    Multi-stage pipeline processing millions of log entries.
    """
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window
    from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType
    from .params import get_job_parameters, print_job_params, simulate_duration
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=30_000_000, default_duration_minutes=12)
    print_job_params("Large-Scale Log Analysis (BEST PRACTICES)", params)
    
    num_rows = params['num_rows']
    duration_minutes = params['duration_minutes']
    
    print(f"🔄 Stage 1: Generating application logs with {num_rows:,} entries...")
    # Simulate realistic application log structure
    logs_df = spark.range(num_rows)\
        .withColumn("timestamp_hour", (F.rand()*24*30).cast("int"))\
        .withColumn("log_level", F.when(F.rand() < 0.7, "INFO")
                                 .when(F.rand() < 0.9, "WARN") 
                                 .when(F.rand() < 0.98, "ERROR")
                                 .otherwise("FATAL"))\
        .withColumn("service", F.when(F.rand() < 0.3, "auth-service")
                              .when(F.rand() < 0.6, "user-service") 
                              .when(F.rand() < 0.8, "payment-service")
                              .otherwise("notification-service"))\
        .withColumn("response_time_ms", F.when(F.col("log_level") == "ERROR", F.rand()*5000 + 1000)
                                       .otherwise(F.rand()*500 + 50))\
        .withColumn("user_id", (F.rand()*1_000_000).cast("int"))\
        .withColumn("status_code", F.when(F.col("log_level") == "ERROR", 500)
                                  .when(F.col("log_level") == "WARN", F.when(F.rand() < 0.5, 404).otherwise(429))
                                  .otherwise(200))\
        .withColumn("bytes_transferred", (F.rand()*10000 + 100).cast("int"))
    
    print(f"🔄 Stage 2: BEST PRACTICE - Optimal partitioning by time for time-series data...")
    # BEST PRACTICE: Repartition by time-based column for optimal time-series processing
    partitioned_logs = logs_df.repartition(200, "timestamp_hour")
    
    print(f"🔄 Stage 3: BEST PRACTICE - Cache partitioned data for multiple operations...")
    # BEST PRACTICE: Cache after expensive repartitioning for reuse
    partitioned_logs.cache()
    
    print(f"🔄 Stage 4: Error analysis with window functions...")
    # Time-based window for rolling error rate analysis
    time_window = Window.partitionBy("service").orderBy("timestamp_hour")
    rolling_window = time_window.rowsBetween(-2, 0)  # 3-hour rolling window
    
    # Advanced error analysis with rolling metrics
    error_analysis = partitioned_logs\
        .withColumn("is_error", F.when(F.col("log_level").isin(["ERROR", "FATAL"]), 1).otherwise(0))\
        .withColumn("is_slow", F.when(F.col("response_time_ms") > 1000, 1).otherwise(0))\
        .groupBy("timestamp_hour", "service", "log_level").agg(
            F.count("*").alias("log_count"),
            F.avg("response_time_ms").alias("avg_response_time"),
            F.sum("bytes_transferred").alias("total_bytes"),
            F.countDistinct("user_id").alias("unique_users")
        )
    
    print(f"🔄 Stage 5: BEST PRACTICE - Efficient aggregations with broadcast joins...")
    # Create service metadata for enrichment (small lookup table)
    service_metadata = spark.createDataFrame([
        ("auth-service", "Authentication", "Critical", "Team-A"),
        ("user-service", "User Management", "High", "Team-B"), 
        ("payment-service", "Payments", "Critical", "Team-C"),
        ("notification-service", "Notifications", "Medium", "Team-D")
    ], ["service", "service_name", "priority", "team"])
    
    # BEST PRACTICE: Broadcast small lookup table
    from pyspark.sql.functions import broadcast
    enriched_logs = error_analysis.join(
        broadcast(service_metadata), "service", "left"
    )
    
    print(f"🔄 Stage 6: Multi-dimensional analysis with complex aggregations...")
    # Service health dashboard metrics
    service_health = enriched_logs.groupBy("service", "service_name", "priority", "team").agg(
        F.sum("log_count").alias("total_requests"),
        F.sum(F.when(F.col("log_level").isin(["ERROR", "FATAL"]), F.col("log_count")).otherwise(0)).alias("error_count"),
        F.avg("avg_response_time").alias("overall_avg_response_time"),
        F.sum("total_bytes").alias("total_data_transferred"),
        F.sum("unique_users").alias("total_unique_users")
    )\
        .withColumn("error_rate", F.col("error_count") / F.col("total_requests"))\
        .withColumn("health_score", 
                   F.when(F.col("error_rate") < 0.01, "Healthy")
                   .when(F.col("error_rate") < 0.05, "Warning")
                   .otherwise("Critical"))
    
    # Hourly system-wide trends
    hourly_trends = enriched_logs.groupBy("timestamp_hour").agg(
        F.sum("log_count").alias("hourly_requests"),
        F.sum(F.when(F.col("log_level").isin(["ERROR", "FATAL"]), F.col("log_count")).otherwise(0)).alias("hourly_errors"),
        F.avg("avg_response_time").alias("hourly_avg_response_time"),
        F.sum("total_bytes").alias("hourly_bytes")
    )\
        .withColumn("hourly_error_rate", F.col("hourly_errors") / F.col("hourly_requests"))\
        .orderBy("timestamp_hour")
    
    # Execute and display analysis results
    print(f"\n🏥 Service Health Dashboard:")
    service_health.show(10, truncate=False)
    
    print(f"\n📈 Hourly System Trends (Last 15 hours):")
    hourly_trends.orderBy(F.desc("timestamp_hour")).show(15)
    
    # Count results to force full execution
    total_services = service_health.count()
    
    print(f"🔄 Stage 7: BEST PRACTICE - Clean up cached resources...")
    # BEST PRACTICE: Unpersist cached DataFrame when done
    partitioned_logs.unpersist()
    
    # Simulate additional processing time if duration specified
    if duration_minutes > 0:
        simulate_duration(duration_minutes)
    
    print(f"✅ Completed comprehensive log analysis:")
    print(f"   📊 Analyzed {num_rows:,} log entries")
    print(f"   🏥 Monitored {total_services} services") 
    print(f"\n🎯 BEST PRACTICES DEMONSTRATED:")
    print(f"   ✅ Optimal partitioning by time-series column")
    print(f"   ✅ Strategic caching after expensive operations") 
    print(f"   ✅ Broadcast joins for small dimension tables")
    print(f"   ✅ Multi-stage pipeline with clear stages")
    print(f"   ✅ Proper resource management and cleanup")
    print(f"   ✅ Production-scale data processing (30M+ records)")