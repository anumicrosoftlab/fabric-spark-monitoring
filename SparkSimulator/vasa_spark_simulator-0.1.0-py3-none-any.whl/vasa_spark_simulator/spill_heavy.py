"""
Spill-heavy Spark simulations
Simulations that can cause spills (memory/disk) due to large records or aggregations.
"""

from .params import simulate_duration

def spill_large_join(spark):
    """
    Large fact-to-dimension join.

    Best practices applied:
    - Broadcast the (small) dimension table to avoid shuffle
    - Keep schemas narrow (column pruning)
    - Avoid driver-side collect() patterns
    """
    from pyspark.sql import functions as F
    from pyspark.sql.functions import broadcast
    from .params import get_job_parameters, print_job_params
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=25_000_000)
    print_job_params("Spill Large Join", params)
    
    num_rows = params['num_rows']

    # Dimension table size: keep it small enough to broadcast safely.
    dim_rows = int(min(max(num_rows // 500, 50_000), 500_000))

    print(f"🔄 Creating fact table with {num_rows:,} rows...")
    fact = spark.range(num_rows).select(
        (F.rand(1) * dim_rows).cast("int").alias("drug_id"),
        (F.rand(2) * 1000).alias("dose_mg"),
        (F.rand(3) * 365).cast("int").alias("day"),
    )

    print(f"🔄 Creating dimension table with {dim_rows:,} rows (broadcast)...")
    dim = spark.range(dim_rows).select(
        F.col("id").cast("int").alias("drug_id"),
        F.concat(F.lit("DRUG_"), F.col("id")).alias("drug_name"),
        F.when(F.col("id") % 3 == 0, F.lit("A"))
        .when(F.col("id") % 3 == 1, F.lit("B"))
        .otherwise(F.lit("C"))
        .alias("class"),
    )

    print(f"🔗 Performing broadcast join (best practice)...")
    joined = fact.join(broadcast(dim), "drug_id", "inner")

    joined_count = joined.count()
    print(f"✅ Completed fact-to-dimension join: {joined_count:,} rows after join.")
    simulate_duration(params['duration_minutes'])

def spill_aggregation(spark):
    """
    Large aggregation over many groups.

    Best practices applied:
    - Repartition by grouping key to balance shuffle work
    - Use a single materializing action
    - Keep dataset narrow
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=100_000_000)
    print_job_params("Spill Aggregation", params)
    
    num_rows = params['num_rows']
    num_genes = int(min(max(num_rows // 200, 50_000), 1_000_000))

    try:
        default_parallelism = int(spark.sparkContext.defaultParallelism) or 1
    except Exception:
        default_parallelism = 1
    target_partitions = max(default_parallelism * 4, 200)
    target_partitions = min(target_partitions, 2000)
    
    # Generate large dataset with many groups
    print(f"🔄 Generating dataset with {num_rows:,} rows and {num_genes:,} gene groups...")
    df = spark.range(num_rows).select(
        (F.rand(10) * num_genes).cast("int").alias("gene"),
        (F.rand(11) * 1000).alias("expr"),
    )

    # Balance work across executors for the aggregation.
    df = df.repartition(target_partitions, "gene")

    print(f"🔄 Performing aggregation with balanced partitioning...")
    agg = df.groupBy("gene").agg(
        F.sum("expr").alias("total_expr"),
        F.count("*").alias("row_count"),
    )

    group_count = agg.count()
    print(f"✅ Completed aggregation: {group_count:,} gene groups processed.")
    simulate_duration(params['duration_minutes'])