"""
Skew-heavy Spark simulations
Simulations that introduce severe data skew to highlight partition or straggler issues.
"""

from .params import simulate_duration

def skew_key_join(spark):
    """
    Skewed join pattern with best-practice mitigation (salting).

    Best practices applied:
    - Salt the hot key to distribute work
    - Broadcast small dimension table when appropriate
    - Avoid unnecessary actions
    """
    from pyspark.sql import functions as F
    from pyspark.sql.functions import broadcast
    from .params import get_job_parameters, print_job_params
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=15_000_000)
    print_job_params("Skew Key Join", params)
    
    num_rows = params['num_rows']
    right_rows = min(num_rows // 200, 50000)  # Much smaller right table

    try:
        default_parallelism = int(spark.sparkContext.defaultParallelism) or 1
    except Exception:
        default_parallelism = 1
    salt_buckets = max(16, min(default_parallelism * 4, 256))
    
    hot_key_ratio = 0.95

    # Left: intentionally skewed, but we SALT the hot key to avoid stragglers.
    print(
        f"🔄 Creating left DataFrame with {num_rows:,} rows "
        f"({int(hot_key_ratio * 100)}% hot key), then applying salting ({salt_buckets} buckets)..."
    )
    left = spark.range(num_rows).select(
        F.when(F.rand(1) < hot_key_ratio, F.lit(0))
        .otherwise((F.monotonically_increasing_id() % 10000).cast("int"))
        .alias("patient_id"),
        (F.rand(2) * 1000).alias("metric"),
    )

    left_salted = left.withColumn(
        "salt",
        F.when(F.col("patient_id") == 0, (F.rand(3) * salt_buckets).cast("int")).otherwise(F.lit(0)),
    )

    print(f"🔄 Creating right dimension DataFrame with {right_rows:,} rows...")
    right = spark.range(right_rows).select(
        F.col("id").cast("int").alias("patient_id"),
        F.concat(F.lit("P_"), F.col("id")).alias("patient_label"),
    )

    # Expand the hot key row across salt buckets.
    salt_df = spark.range(salt_buckets).select(F.col("id").cast("int").alias("salt"))
    right_hot = right.filter(F.col("patient_id") == 0).crossJoin(salt_df)
    right_non_hot = right.filter(F.col("patient_id") != 0).withColumn("salt", F.lit(0))
    right_salted = right_non_hot.unionByName(right_hot)

    print(f"🔗 Joining on (patient_id, salt) with broadcast dimension (best practice)...")
    joined = left_salted.join(broadcast(right_salted), ["patient_id", "salt"], "inner")

    joined_count = joined.count()
    print(f"✅ Completed salted join: {joined_count:,} rows after join (skew mitigated).")
    simulate_duration(params['duration_minutes'])

def skew_groupby(spark):
    """
    Skewed groupBy pattern with best-practice mitigation (salting + two-stage agg).
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params
    
    # Get parameters
    params = get_job_parameters(spark, default_num_rows=20_000_000)
    print_job_params("Skew GroupBy", params)
    
    num_rows = params['num_rows']

    try:
        default_parallelism = int(spark.sparkContext.defaultParallelism) or 1
    except Exception:
        default_parallelism = 1
    salt_buckets = max(16, min(default_parallelism * 4, 256))
    
    hot_group_ratio = 0.97
    hot_group_id = 1

    print(
        f"🔄 Generating dataset with {num_rows:,} rows "
        f"({int(hot_group_ratio * 100)}% in one group), then salting ({salt_buckets} buckets)..."
    )
    df = spark.range(num_rows).select(
        F.when(F.rand(10) < hot_group_ratio, F.lit(hot_group_id))
        .otherwise((F.monotonically_increasing_id() % 10000).cast("int"))
        .alias("group_id")
    )

    df_salted = df.withColumn(
        "salt",
        F.when(F.col("group_id") == hot_group_id, (F.rand(11) * salt_buckets).cast("int")).otherwise(F.lit(0)),
    )

    print("🔄 Performing two-stage aggregation to mitigate skew...")
    stage1 = df_salted.groupBy("group_id", "salt").count()
    result = stage1.groupBy("group_id").agg(F.sum("count").alias("row_count"))

    result_cached = result.cache()
    group_count = result_cached.count()
    result_cached.show(20)
    result_cached.unpersist()

    print(f"✅ Completed skew-mitigated groupBy: {group_count:,} groups produced.")
    simulate_duration(params['duration_minutes'])