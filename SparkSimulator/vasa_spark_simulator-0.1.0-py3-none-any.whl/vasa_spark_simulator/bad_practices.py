"""
Bad Practice Spark Simulations
Anti-patterns and inefficient code that should be avoided in production.
These jobs intentionally demonstrate common Spark mistakes for analyzer testing.
"""

def no_caching_recompute(spark):
    """
    BAD PRACTICE: Recomputes the same DataFrame multiple times without caching.
    This causes Spark to re-execute the entire lineage for each action.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params
    
    params = get_job_parameters(spark, default_num_rows=15_000_000)
    print_job_params("No Caching - Recomputation Anti-Pattern", params)
    
    num_rows = params['num_rows']
    
    print(f"🔄 Generating expensive DataFrame with {num_rows:,} rows...")
    # Create an expensive transformation chain
    df = spark.range(num_rows)\
        .withColumn("value1", F.rand() * 1000)\
        .withColumn("value2", F.rand() * 500)\
        .withColumn("category", (F.rand() * 10).cast("int"))\
        .filter(F.col("value1") > 100)  # Expensive filter
    
    # BAD: Multiple actions without caching - causes full recomputation each time
    print(f"⚠️  Performing multiple actions WITHOUT caching (anti-pattern)...")
    count1 = df.count()
    print(f"   Action 1 - Count: {count1:,}")
    
    # This triggers full recomputation from spark.range()!
    avg_val = df.agg(F.avg("value1")).collect()[0][0]
    print(f"   Action 2 - Avg: {avg_val:.2f}")
    
    # Another full recomputation!
    max_val = df.agg(F.max("value2")).collect()[0][0]
    print(f"   Action 3 - Max: {max_val:.2f}")
    
    # Yet another recomputation!
    df.groupBy("category").count().show()
    
    print(f"⚠️  Completed 4 actions with full recomputation each time!")
    print(f"💡 RECOMMENDATION: Use df.cache() or df.persist() before multiple actions")

def python_udf_instead_of_builtin(spark):
    """
    BAD PRACTICE: Using Python UDFs instead of built-in Spark functions.
    Python UDFs are significantly slower due to serialization overhead.
    """
    from pyspark.sql import functions as F
    from pyspark.sql.types import IntegerType, StringType
    from .params import get_job_parameters, print_job_params
    
    params = get_job_parameters(spark, default_num_rows=10_000_000)
    print_job_params("Python UDF Anti-Pattern", params)
    
    num_rows = params['num_rows']
    
    print(f"🔄 Generating DataFrame with {num_rows:,} rows...")
    df = spark.range(num_rows)\
        .withColumn("age", (F.rand() * 70 + 18).cast("int"))\
        .withColumn("income", F.rand() * 200000)
    
    # BAD: Define Python UDF for simple categorization
    print(f"⚠️  Using Python UDF for simple logic (anti-pattern)...")
    @F.udf(returnType=StringType())
    def categorize_age_udf(age):
        if age < 25:
            return "Young"
        elif age < 50:
            return "Middle"
        else:
            return "Senior"
    
    @F.udf(returnType=StringType())
    def income_bracket_udf(income):
        if income < 50000:
            return "Low"
        elif income < 100000:
            return "Medium"
        else:
            return "High"
    
    # Apply UDFs - causes Python<->JVM serialization overhead
    result = df.withColumn("age_category", categorize_age_udf(F.col("age")))\
        .withColumn("income_bracket", income_bracket_udf(F.col("income")))
    
    result.groupBy("age_category", "income_bracket").count().show()
    
    print(f"⚠️  UDFs force Python serialization for {num_rows:,} rows!")
    print(f"💡 RECOMMENDATION: Use F.when().otherwise() for simple logic")

def groupbykey_instead_of_reducebykey(spark):
    """
    BAD PRACTICE: Using groupByKey instead of reduceByKey/aggregateByKey.
    groupByKey shuffles all values, while reduceByKey combines locally first.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params
    
    params = get_job_parameters(spark, default_num_rows=5_000_000)
    print_job_params("GroupByKey Anti-Pattern", params)
    
    num_rows = params['num_rows']
    
    print(f"🔄 Generating DataFrame with {num_rows:,} rows...")
    df = spark.range(num_rows)\
        .withColumn("key", (F.rand() * 1000).cast("int"))\
        .withColumn("value", F.rand() * 100)
    
    # BAD: Convert to RDD and use groupByKey
    print(f"⚠️  Using RDD groupByKey (anti-pattern - shuffles all data)...")
    rdd = df.rdd.map(lambda row: (row['key'], row['value']))
    
    # groupByKey shuffles ALL values without local combining
    grouped = rdd.groupByKey()
    result = grouped.mapValues(lambda values: sum(values))
    
    count = result.count()
    print(f"⚠️  Shuffled all {num_rows:,} values across network!")
    print(f"💡 RECOMMENDATION: Use reduceByKey or DataFrame groupBy().agg()")

def excessive_repartitioning(spark):
    """
    BAD PRACTICE: Unnecessary repartitioning causing excessive shuffles.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params
    
    params = get_job_parameters(spark, default_num_rows=2_000_000)
    print_job_params("Excessive Repartitioning Anti-Pattern", params)
    
    num_rows = params['num_rows']
    
    print(f"🔄 Generating DataFrame with {num_rows:,} rows...")
    df = spark.range(num_rows).withColumn("category", (F.rand() * 50).cast("int"))
    
    # BAD: Repartition multiple times unnecessarily
    print(f"⚠️  Performing excessive repartitioning (anti-pattern)...")
    df = df.repartition(100)  # First shuffle
    df = df.repartition(50)   # Second shuffle
    df = df.repartition(200)  # Third shuffle
    df = df.repartition(10)   # Fourth shuffle - way too few partitions
    
    result = df.groupBy("category").count()
    result.show(10)
    
    print(f"⚠️  Performed 4 unnecessary shuffles!")
    print(f"💡 RECOMMENDATION: Repartition only when needed, choose appropriate partition count")

def cartesian_product_join(spark):
    """
    BAD PRACTICE: Unintentional cartesian product (cross join).
    Creates N*M rows, causing OOM and extreme slowness.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params
    
    params = get_job_parameters(spark, default_num_rows=50_000)  # Small to avoid actual OOM
    print_job_params("Cartesian Product Anti-Pattern", params)
    
    num_rows = params['num_rows']
    
    print(f"🔄 Creating two DataFrames with {num_rows:,} rows each...")
    df1 = spark.range(num_rows).withColumn("value1", F.rand())
    df2 = spark.range(num_rows).withColumn("value2", F.rand())
    
    # BAD: Join without a join condition = cartesian product
    print(f"⚠️  Performing cartesian join (anti-pattern)...")
    print(f"⚠️  This will create {num_rows:,} × {num_rows:,} = {num_rows*num_rows:,} rows!")
    
    # Intentionally use crossJoin to show the anti-pattern
    result = df1.crossJoin(df2)
    
    count = result.count()
    print(f"⚠️  Created {count:,} rows from cartesian product!")
    print(f"💡 RECOMMENDATION: Always specify join conditions, avoid crossJoin")

def count_then_collect(spark):
    """
    BAD PRACTICE: Using count() then collect() - redundant and inefficient.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params
    
    params = get_job_parameters(spark, default_num_rows=1_000_000)
    print_job_params("Count Then Collect Anti-Pattern", params)
    
    num_rows = params['num_rows']
    
    print(f"🔄 Generating DataFrame with {num_rows:,} rows...")
    df = spark.range(num_rows)\
        .withColumn("category", (F.rand() * 100).cast("int"))\
        .withColumn("value", F.rand() * 1000)
    
    aggregated = df.groupBy("category").agg(F.sum("value").alias("total"))
    
    # BAD: Count first (triggers full computation)
    print(f"⚠️  Calling count() first (triggers computation)...")
    count = aggregated.count()
    print(f"   Found {count} categories")
    
    # BAD: Then collect (recomputes everything!)
    print(f"⚠️  Then calling collect() (recomputes entire aggregation)...")
    data = aggregated.collect()
    print(f"   Collected {len(data)} rows")
    
    print(f"⚠️  Computed the same aggregation twice!")
    print(f"💡 RECOMMENDATION: Just collect() if you need the data, or cache before count")

def small_file_problem(spark):
    """
    BAD PRACTICE: Creating too many small partitions/files.
    Results in excessive overhead and small file problem in storage.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params
    
    params = get_job_parameters(spark, default_num_rows=1_000_000)
    print_job_params("Small File Problem Anti-Pattern", params)
    
    num_rows = params['num_rows']
    
    print(f"🔄 Generating DataFrame with {num_rows:,} rows...")
    df = spark.range(num_rows)\
        .withColumn("category", (F.rand() * 10).cast("int"))\
        .withColumn("value", F.rand() * 1000)
    
    # BAD: Repartition into too many small partitions
    print(f"⚠️  Repartitioning into 5000 partitions (anti-pattern)...")
    df_over_partitioned = df.repartition(5000)
    
    # This would create 5000 small files if written
    count = df_over_partitioned.count()
    partitions = df_over_partitioned.rdd.getNumPartitions()
    
    print(f"⚠️  Created {partitions} partitions for only {count:,} rows!")
    print(f"⚠️  Avg rows per partition: {count/partitions:.1f}")
    print(f"💡 RECOMMENDATION: Use appropriate partition count (~128MB per partition)")

def broadcast_large_table(spark):
    """
    BAD PRACTICE: Broadcasting a large table in join.
    Should only broadcast small lookup tables that fit in memory.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params
    
    params = get_job_parameters(spark, default_num_rows=500_000)
    print_job_params("Broadcast Large Table Anti-Pattern", params)
    
    num_rows = params['num_rows']
    
    print(f"🔄 Creating large fact table ({num_rows:,} rows)...")
    fact_table = spark.range(num_rows)\
        .withColumn("key", (F.rand() * 1000).cast("int"))\
        .withColumn("value", F.rand() * 1000)
    
    print(f"🔄 Creating large dimension table ({num_rows:,} rows)...")
    # BAD: This is too large to broadcast!
    large_dim_table = spark.range(num_rows)\
        .withColumn("key", (F.rand() * 1000).cast("int"))\
        .withColumn("description", F.concat(F.lit("Item_"), F.col("id")))
    
    # BAD: Forcing broadcast of large table
    print(f"⚠️  Broadcasting large table with {num_rows:,} rows (anti-pattern)...")
    from pyspark.sql.functions import broadcast
    
    result = fact_table.join(
        broadcast(large_dim_table),  # BAD: Too large!
        on="key",
        how="inner"
    )
    
    count = result.count()
    print(f"⚠️  Broadcasted {num_rows:,} rows across all executors!")
    print(f"💡 RECOMMENDATION: Only broadcast small tables (<10MB), let Spark decide for large joins")

def iterative_without_caching(spark):
    """
    BAD PRACTICE: Iterative algorithm without caching intermediate results.
    Common in ML algorithms like PageRank, K-means, etc.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params
    
    params = get_job_parameters(spark, default_num_rows=500_000)
    print_job_params("Iterative Without Caching Anti-Pattern", params)
    
    num_rows = params['num_rows']
    iterations = 5
    
    print(f"🔄 Generating initial DataFrame with {num_rows:,} rows...")
    df = spark.range(num_rows)\
        .withColumn("value", F.lit(1.0))\
        .withColumn("category", (F.rand() * 100).cast("int"))
    
    # BAD: Iterative updates without caching
    print(f"⚠️  Running {iterations} iterations WITHOUT caching (anti-pattern)...")
    for i in range(iterations):
        print(f"   Iteration {i+1}/{iterations} - recomputing entire lineage...")
        # Each iteration recomputes from spark.range()!
        df = df.withColumn("value", F.col("value") * 0.85 + F.rand() * 0.15)
        
        # Force computation
        avg = df.agg(F.avg("value")).collect()[0][0]
        print(f"   Avg value: {avg:.4f}")
    
    print(f"⚠️  Recomputed full lineage {iterations} times!")
    print(f"💡 RECOMMENDATION: Cache intermediate results in iterative algorithms")

def select_star_large_table(spark):
    """
    BAD PRACTICE: SELECT * on wide tables with many columns.
    Reads unnecessary columns, wasting I/O and memory.
    """
    from pyspark.sql import functions as F
    from .params import get_job_parameters, print_job_params
    
    params = get_job_parameters(spark, default_num_rows=1_000_000)
    print_job_params("SELECT * Anti-Pattern", params)
    
    num_rows = params['num_rows']
    
    print(f"🔄 Creating wide table with {num_rows:,} rows and 50 columns...")
    df = spark.range(num_rows)
    
    # Create 50 columns
    for i in range(50):
        df = df.withColumn(f"col_{i}", F.rand() * 1000)
    
    # BAD: Select all columns when only need a few
    print(f"⚠️  Selecting ALL 50 columns when only need 2 (anti-pattern)...")
    all_columns = df.select("*")  # Reads all 50 columns from storage
    
    # Only use 2 columns
    result = all_columns.select("id", "col_0").groupBy("id").agg(F.avg("col_0"))
    
    count = result.count()
    print(f"⚠️  Read 50 columns but only used 2!")
    print(f"💡 RECOMMENDATION: Select only needed columns: df.select('id', 'col_0')")
