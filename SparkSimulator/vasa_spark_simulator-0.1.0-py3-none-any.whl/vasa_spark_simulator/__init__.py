"""
vasa_spark_simulator

A package providing 30 realistic PySpark workload simulations for the pharma industry,
optimized for Microsoft Fabric environments.  Includes optimized variants for all
18 non-optimal jobs (anti-patterns 1-12 and performance issues 13-18) to support
before/after comparison workflows.
"""

# Import all simulation functions for quick access
from .driver_heavy import *
from .shuffle_heavy import *
from .spill_heavy import *
from .skew_heavy import *
from .industry_apps import *
from .simulate import (
    run_simulation, list_simulations, list_simulations_with_numbers,
    ALL_SIMULATIONS, get_job_by_number, get_job_number, NUMERIC_JOB_MAP
)

# Import optimized job variants (before/after comparison support)
from .optimized_jobs import (
    OPTIMIZED_JOBS,
    _apply_fabric_best_practices,
    # --- Anti-pattern optimized variants ---
    driver_heavy_collect_optimized,
    driver_heavy_map_optimized,
    no_caching_recompute_optimized,
    python_udf_instead_of_builtin_optimized,
    groupbykey_instead_of_reducebykey_optimized,
    excessive_repartitioning_optimized,
    cartesian_product_join_optimized,
    count_then_collect_optimized,
    small_file_problem_optimized,
    broadcast_large_table_optimized,
    iterative_without_caching_optimized,
    select_star_large_table_optimized,
    # --- Performance-issue optimized variants ---
    shuffle_groupby_optimized,
    shuffle_join_optimized,
    spill_large_join_optimized,
    spill_aggregation_optimized,
    skew_key_join_optimized,
    skew_groupby_optimized,
)

# Import main entry points for Fabric and Pipelines
from .main import fabric_notebook_entry, pipeline_entry, run_job, create_fabric_spark_session

# Import parameter utilities
from .params import get_job_parameters, print_job_params

__version__ = '0.1.0'
__all__ = [
    # Main entry points
    'fabric_notebook_entry',
    'pipeline_entry',
    'run_job',
    'create_fabric_spark_session',
    # Original simulation management
    'run_simulation',
    'list_simulations',
    'list_simulations_with_numbers',
    'ALL_SIMULATIONS',
    'NUMERIC_JOB_MAP',
    'get_job_by_number',
    'get_job_number',
    # Optimized variants registry
    'OPTIMIZED_JOBS',
    '_apply_fabric_best_practices',
    # Anti-pattern optimized
    'driver_heavy_collect_optimized',
    'driver_heavy_map_optimized',
    'no_caching_recompute_optimized',
    'python_udf_instead_of_builtin_optimized',
    'groupbykey_instead_of_reducebykey_optimized',
    'excessive_repartitioning_optimized',
    'cartesian_product_join_optimized',
    'count_then_collect_optimized',
    'small_file_problem_optimized',
    'broadcast_large_table_optimized',
    'iterative_without_caching_optimized',
    'select_star_large_table_optimized',
    # Performance-issue optimized
    'shuffle_groupby_optimized',
    'shuffle_join_optimized',
    'spill_large_join_optimized',
    'spill_aggregation_optimized',
    'skew_key_join_optimized',
    'skew_groupby_optimized',
    # Parameter utilities
    'get_job_parameters',
    'print_job_params',
]