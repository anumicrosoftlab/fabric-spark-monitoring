"""
mcp_server/server.py — Vasa Spark Simulator MCP Server
=======================================================
Model Context Protocol server that exposes Spark advisor tools backed by
Kusto (Azure Data Explorer).  The VS Code Copilot agent can call these
tools with natural language commands such as:

    "compare pharma_etl before and after optimization"
    "analyze vasa_skew_key_join_optimized_20260302_143022"

Prerequisites
-------------
Install the MCP SDK and Kusto client::

    pip install mcp azure-kusto-data

Configure the Kusto connection via environment variables or a ``.env`` file:

    KUSTO_CLUSTER   = https://<cluster>.kusto.windows.net
    KUSTO_DATABASE  = <database>
    KUSTO_CLIENT_ID = <AAD app client id>       # optional — uses DefaultAzureCredential if absent
    KUSTO_CLIENT_SECRET = <secret>              # optional
    KUSTO_TENANT_ID     = <AAD tenant id>       # optional

Running the server
------------------
::

    python -m mcp_server.server
    # or
    python mcp_server/server.py
"""

from __future__ import annotations

import os
import textwrap
from typing import Any

# ---------------------------------------------------------------------------
# MCP SDK
# ---------------------------------------------------------------------------
try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp import types as mcp_types
    _MCP_AVAILABLE = True
except ImportError:
    _MCP_AVAILABLE = False
    print(
        "[mcp_server] WARNING: 'mcp' package not installed.  "
        "Run `pip install mcp` to enable MCP tool exposure."
    )

# ---------------------------------------------------------------------------
# Kusto client
# ---------------------------------------------------------------------------
try:
    from azure.kusto.data import KustoClient, KustoConnectionStringBuilder
    from azure.kusto.data.exceptions import KustoServiceError
    _KUSTO_AVAILABLE = True
except ImportError:
    _KUSTO_AVAILABLE = False
    print(
        "[mcp_server] WARNING: 'azure-kusto-data' not installed.  "
        "Run `pip install azure-kusto-data` to enable Kusto queries."
    )


# ---------------------------------------------------------------------------
# Kusto connection helpers
# ---------------------------------------------------------------------------

def _build_kusto_client() -> Any | None:
    """Return a KustoClient using environment-configured credentials."""
    if not _KUSTO_AVAILABLE:
        return None

    cluster  = os.environ.get("KUSTO_CLUSTER", "")
    tenant   = os.environ.get("KUSTO_TENANT_ID", "")
    client_id     = os.environ.get("KUSTO_CLIENT_ID", "")
    client_secret = os.environ.get("KUSTO_CLIENT_SECRET", "")

    if not cluster:
        print("[mcp_server] KUSTO_CLUSTER not set — Kusto queries will fail.")
        return None

    if client_id and client_secret and tenant:
        kcsb = KustoConnectionStringBuilder.with_aad_application_key_authentication(
            cluster, client_id, client_secret, tenant
        )
    else:
        # Fall back to interactive / DefaultAzureCredential
        kcsb = KustoConnectionStringBuilder.with_az_cli_authentication(cluster)

    return KustoClient(kcsb)


def run_query(query: str) -> str:
    """
    Execute a KQL query against the configured Kusto cluster and database.

    Returns a plain-text table (tab-separated) or an error description.
    """
    if not _KUSTO_AVAILABLE:
        return "ERROR: azure-kusto-data not installed."

    client = _build_kusto_client()
    if client is None:
        return "ERROR: Kusto client could not be initialised (check KUSTO_CLUSTER env var)."

    database = os.environ.get("KUSTO_DATABASE", "")
    if not database:
        return "ERROR: KUSTO_DATABASE env var not set."

    try:
        response = client.execute(database, query)
        table = response.primary_results[0]
        if not table.rows:
            return "(no rows returned)"

        # Build a readable text table
        headers = [col.column_name for col in table.columns]
        rows    = [
            "\t".join(str(cell) for cell in row)
            for row in table.rows
        ]
        return "\n".join(["\t".join(headers)] + rows)

    except KustoServiceError as exc:
        return f"Kusto error: {exc}"
    except Exception as exc:  # pylint: disable=broad-except
        return f"Unexpected error: {exc}"


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

def compare_job_optimization(job_base_name: str) -> str:
    """
    Compare the original vs optimized variant of a Spark job.

    Finds the most recent run of each variant in ``sparklens_metadata`` and
    returns a side-by-side before/after table of all ``sparklens_metrics``.

    Parameters
    ----------
    job_base_name : str
        The base job name without the ``_optimized`` suffix, e.g. ``pharma_etl``.

    Returns
    -------
    str
        A plain-text table with columns:
        Metric | Before | After | Delta | Improved

    Usage
    -----
    ::

        compare_job_optimization("pharma_etl")
        compare_job_optimization("skew_key_join")
    """
    query = textwrap.dedent(f"""
    let base_ids = sparklens_metadata
        | where applicationName contains "{job_base_name}"
        | where applicationName !contains "_optimized"
        | top 1 by ingestion_time() desc
        | project applicationId;

    let opt_ids = sparklens_metadata
        | where applicationName contains "{job_base_name}_optimized"
        | top 1 by ingestion_time() desc
        | project applicationId;

    let base_metrics = sparklens_metrics
        | where app_id in (base_ids)
        | project metric, before_value = value;

    let opt_metrics = sparklens_metrics
        | where app_id in (opt_ids)
        | project metric, after_value = value;

    base_metrics
    | join kind=leftouter opt_metrics on metric
    | project
        Metric   = metric,
        Before   = round(before_value, 3),
        After    = round(after_value,  3),
        Delta    = round(after_value - before_value, 3),
        Improved = iff(
            metric in (
                "Executor Efficiency",
                "Parallelism Score",
                "Stage Efficiency"
            ),
            after_value > before_value,
            after_value < before_value
        )
    | order by Metric asc
    """).strip()

    return run_query(query)


def search_applications_by_name(name_fragment: str) -> str:
    """
    Search ``sparklens_metadata`` for all applications whose name contains
    ``name_fragment``.  Returns the most recent 20 matches with their IDs and
    timestamps.

    Use this to find both the original and optimized variant of a job so you
    can feed their ``applicationId`` values into further Kusto queries or the
    ``compare_job_optimization`` tool.

    Parameters
    ----------
    name_fragment : str
        A substring of the application name, e.g. ``pharma_etl`` will return
        both ``vasa_pharma_etl_20260302_143022`` and
        ``vasa_pharma_etl_optimized_20260302_143025``.
    """
    query = textwrap.dedent(f"""
    sparklens_metadata
    | where applicationName contains "{name_fragment}"
    | top 20 by ingestion_time() desc
    | project applicationId, applicationName, ingestion_time()
    | order by column3 desc
    """).strip()

    return run_query(query)


def analyze_application(app_id: str) -> str:
    """
    Return all metrics for a specific Spark application ID.

    Parameters
    ----------
    app_id : str
        The ``applicationId`` from ``sparklens_metadata``, e.g.
        ``application_1706789012345_0001``.
    """
    query = textwrap.dedent(f"""
    sparklens_metrics
    | where app_id == "{app_id}"
    | project metric, value = round(value, 3)
    | order by metric asc
    """).strip()

    return run_query(query)


# ---------------------------------------------------------------------------
# MCP server wiring
# ---------------------------------------------------------------------------

TOOLS = [
    (
        "compare_job_optimization",
        compare_job_optimization,
        {
            "name":        "compare_job_optimization",
            "description": (
                "Compare original vs optimized variant of a Spark job. "
                "Finds the most recent run of each in Kusto and returns a "
                "before/after metric table (Metric | Before | After | Delta | Improved). "
                "Usage: compare_job_optimization(job_base_name='pharma_etl')"
            ),
            "inputSchema": {
                "type": "object",
                "properties": {
                    "job_base_name": {
                        "type":        "string",
                        "description": "Base job name without _optimized suffix, e.g. 'pharma_etl'.",
                    }
                },
                "required": ["job_base_name"],
            },
        },
    ),
    (
        "search_applications_by_name",
        search_applications_by_name,
        {
            "name":        "search_applications_by_name",
            "description": (
                "Search sparklens_metadata for applications whose name contains the given fragment. "
                "Returns up to 20 most recent matches with applicationId and timestamp. "
                "Searching 'pharma_etl' returns both original and _optimized variants."
            ),
            "inputSchema": {
                "type": "object",
                "properties": {
                    "name_fragment": {
                        "type":        "string",
                        "description": "Substring to search for in applicationName.",
                    }
                },
                "required": ["name_fragment"],
            },
        },
    ),
    (
        "analyze_application",
        analyze_application,
        {
            "name":        "analyze_application",
            "description": (
                "Return all Spark metrics for a specific applicationId from Kusto. "
                "Use search_applications_by_name first to find the ID."
            ),
            "inputSchema": {
                "type": "object",
                "properties": {
                    "app_id": {
                        "type":        "string",
                        "description": "Spark application ID, e.g. application_1706789012345_0001.",
                    }
                },
                "required": ["app_id"],
            },
        },
    ),
]


def _make_server() -> "Server":
    """Construct and wire the MCP Server instance."""
    server = Server("vasa-spark-advisor")

    tool_defs = [t[2] for t in TOOLS]
    tool_fns  = {t[0]: t[1] for t in TOOLS}

    @server.list_tools()
    async def list_tools() -> list[mcp_types.Tool]:
        return [mcp_types.Tool(**td) for td in tool_defs]

    @server.call_tool()
    async def call_tool(
        name: str, arguments: dict[str, Any]
    ) -> list[mcp_types.TextContent]:
        fn = tool_fns.get(name)
        if fn is None:
            return [mcp_types.TextContent(type="text", text=f"Unknown tool: {name}")]
        try:
            result = fn(**arguments)
            return [mcp_types.TextContent(type="text", text=str(result))]
        except Exception as exc:  # pylint: disable=broad-except
            return [mcp_types.TextContent(type="text", text=f"Tool error: {exc}")]

    return server


async def _run():
    """Async entry point — runs the server over stdio."""
    server = _make_server()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def main():
    """Synchronous entry point."""
    if not _MCP_AVAILABLE:
        print(
            "ERROR: 'mcp' package not installed.  "
            "Run `pip install mcp` and retry."
        )
        raise SystemExit(1)

    import asyncio
    asyncio.run(_run())


if __name__ == "__main__":
    main()
