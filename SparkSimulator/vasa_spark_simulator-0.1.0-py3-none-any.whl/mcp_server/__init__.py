"""Vasa Spark Simulator — MCP Server package."""
