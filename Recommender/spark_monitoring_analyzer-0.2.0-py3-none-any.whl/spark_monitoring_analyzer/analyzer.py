"""spark_monitoring_analyzer.analyzer

Production wrapper around the original Jupyter notebook logic.

CRITICAL:
- The notebook code is embedded verbatim (cell sources are copied line-for-line).
- Execution is performed cell-by-cell via `exec` to preserve notebook semantics,
  including re-definitions (the last definition wins, same as running the notebook).

Entry points:
- Python API: `run(kusto_uri, database)`

This package is intended to run inside Microsoft Fabric / Synapse Spark where
`spark` and `notebookutils` are available.
"""

from __future__ import annotations

import logging
import builtins
import importlib
import json
import re
import time
from collections.abc import Callable
from typing import Any

logger = logging.getLogger(__name__)

# URL template used to install this package on Spark worker nodes.
# Workers need the package importable so that cloudpickle can resolve
# module-level functions (e.g. _format_plaintext_recommendation_block)
# referenced inside applyInPandas UDFs.
_WORKER_BOOTSTRAP_WHL_URL_TEMPLATE = (
    "https://raw.githubusercontent.com/anumicrosoftlab"
    "/fabric-spark-monitoring/main/Recommender"
    "/spark_monitoring_analyzer-{version}-py3-none-any.whl"
)


# ------------------------------
# Recommendation rule registry
# ------------------------------
#
# Requirement: Do NOT modify the existing notebook function
# `generate_enhanced_recommendations()`. Instead, we install a wrapper *at runtime*
# so the original logic runs first, then any registered rules can append extras.
#
# IMPORTANT: Registry is empty by default, so baseline behavior is unchanged.

RecommendationRule = Callable[[dict[str, Any], Any], Any | None]

_RECOMMENDATION_RULES: list[RecommendationRule] = []


def register_recommendation_rule(rule: RecommendationRule) -> None:
    """Register an extra recommendation rule.

    Rules are executed after the notebook's `generate_enhanced_recommendations`.
    The rule receives:
      - `ns`: the shared notebook execution namespace
      - `base`: the base recommendations object produced by the notebook

    Return `None` to add nothing.
    """

    _RECOMMENDATION_RULES.append(rule)


def clear_recommendation_rules() -> None:
    """Remove all registered recommendation rules."""

    _RECOMMENDATION_RULES.clear()


def _combine_recommendations(base: Any, extra: Any) -> Any:
    """Best-effort combine without impacting baseline behavior.

    If combination fails, `base` is returned unchanged.
    """

    if extra is None:
        return base

    # Spark DataFrame: try unionByName then union
    for method_name in ("unionByName", "union"):
        method = getattr(base, method_name, None)
        if callable(method):
            try:
                if method_name == "unionByName":
                    try:
                        return method(extra, allowMissingColumns=True)
                    except TypeError:
                        return method(extra)
                return method(extra)
            except Exception:
                logger.exception("Failed combining recommendations via %s", method_name)
                return base

    # Python list-like
    if isinstance(base, list):
        if isinstance(extra, list):
            return base + extra
        return base + [extra]

    return base


def _install_generate_wrapper(ns: dict[str, Any]) -> None:
    """Install wrapper into the notebook namespace if available."""

    fn = ns.get("generate_enhanced_recommendations")
    if not callable(fn):
        return

    # Idempotent: avoid re-wrapping
    if ns.get("_sma_generate_wrapped") is fn:
        return

    base_fn = fn

    def _wrapped_generate_enhanced_recommendations(*args: Any, **kwargs: Any) -> Any:
        base = base_fn(*args, **kwargs)
        if not _RECOMMENDATION_RULES:
            return base

        combined = base
        for rule in list(_RECOMMENDATION_RULES):
            try:
                extra = rule(ns, base)
                combined = _combine_recommendations(combined, extra)
            except Exception:
                logger.exception("Recommendation rule failed: %r", rule)
        return combined

    ns["generate_enhanced_recommendations"] = _wrapped_generate_enhanced_recommendations
    ns["_sma_generate_wrapped"] = _wrapped_generate_enhanced_recommendations


# ------------------------------
# Plain-text recommendation formatting
# ------------------------------

_SEVERITY_EMOJI: dict[str, str] = {
    "CRITICAL": "🔴",
    "HIGH": "🟡",
    "MEDIUM": "🔵",
    "LOW": "⚫",
}


def _severity_emoji(severity: str) -> str:
    return _SEVERITY_EMOJI.get(str(severity).strip().upper(), "⚫")


def _metric_health_cpu(executor_eff: float) -> str:
    if executor_eff < 0.40:
        return "🔴"
    if executor_eff <= 0.70:
        return "🟡"
    return "✅"


def _metric_health_gc(gc_overhead: float) -> str:
    if gc_overhead > 0.10:
        return "🔴"
    if gc_overhead >= 0.05:
        return "🟡"
    return "✅"


def _metric_health_skew(skew: float) -> str:
    if skew > 3.0:
        return "🔴"
    if skew >= 1.5:
        return "🟡"
    return "✅"


def _metric_health_parallelism(parallelism: float) -> str:
    if parallelism < 0.50:
        return "🔴"
    if parallelism <= 0.80:
        return "🟡"
    return "✅"


def _score_grade(score: int) -> tuple[str, str]:
    """Return (emoji, label) for the performance score."""

    if score >= 80:
        return "✅", "EXCELLENT"
    if score >= 65:
        return "🟡", "GOOD"
    if score >= 50:
        return "🔵", "FAIR"
    return "🔴", "POOR"


# ── Module-level Kusto token cache ────────────────────────────────────────────
# Refreshed 5 minutes before expected expiry to avoid mid-job auth failures.
# Used by any module-level Kusto calls; cell 9 has its own no-arg version that
# captures kustoUri from the exec namespace.

_ml_cached_token: str | None = None
_ml_token_acquired_at: float = 0.0
_TOKEN_TTL_SECONDS: float = 3600.0
_TOKEN_REFRESH_BUFFER: float = 300.0


def get_cached_token(kusto_uri: str) -> str:
    """Return a valid Fabric MSI token, refreshing if within 5 minutes of expiry."""
    global _ml_cached_token, _ml_token_acquired_at
    age = time.time() - _ml_token_acquired_at
    if _ml_cached_token is None or age >= (_TOKEN_TTL_SECONDS - _TOKEN_REFRESH_BUFFER):
        try:
            import notebookutils  # type: ignore  # available on Fabric/Synapse
            _ml_cached_token = notebookutils.credentials.getToken(kusto_uri)
            _ml_token_acquired_at = time.time()
        except Exception as e:
            if _ml_cached_token is None:
                raise
            logger.warning("Token refresh failed (%s); using existing token.", e)
    return _ml_cached_token  # type: ignore[return-value]


# ── Formatting helpers ──────────────────────────────────────────────────────────

def _score_bar(score: int) -> str:
    """Return a 20-char ASCII progress bar for a 0-100 performance score."""
    filled = max(0, min(20, score // 5))
    return "[" + "█" * filled + "░" * (20 - filled) + "]"


def _score_explanation(score: int, grade: str) -> str:
    """Return a one-sentence interpretation of the performance score."""
    if score >= 85:
        return (
            "This job is well-optimised. Focus on the Fabric configuration "
            "best practices in fabric_recommedations to squeeze out additional gains."
        )
    if score >= 70:
        return (
            "This job has room for improvement. Addressing the top recommendation "
            "should yield a meaningful reduction in runtime."
        )
    if score >= 50:
        return (
            "This job has significant performance issues. The recommendations below "
            "are likely to halve runtime or better if fully addressed."
        )
    return (
        "This job has critical performance problems. It may be 3–10x slower "
        "than it could be. Prioritise the top recommendation immediately."
    )


def _health_icon(val: float, good_thresh: float, warn_thresh: float) -> str:
    """Return ✓, ⚠, or ✗ depending on thresholds."""
    if val >= good_thresh:
        return "✓"
    if val >= warn_thresh:
        return "⚠"
    return "✗"


def _append_scaling_outlook(
    output: list,
    cpu_pct: float,
    par_pct: float,
    primary_text: str,
    skew_val: float,
) -> None:
    """Append a scaling verdict line (or two) to *output* in-place."""
    primary_upper = (primary_text or "").upper()
    if "DRIVER" in primary_upper:
        output.append(
            "⚠ Adding more workers will NOT help this job. The bottleneck is on the "
            "driver node (see top recommendation). Fix the driver-side code first, "
            "then re-evaluate whether scaling is needed."
        )
        output.append(
            "ℹ The Scaling Predictions table still shows Amdahl-bounded estimates for "
            "reference, but all Scale Up rows are marked \"driver-limited\" — the driver "
            "serial fraction caps any speedup regardless of executor count."
        )
    elif skew_val > 5:
        output.append(
            f"⚠ Task skew ({skew_val:.1f}x) limits scaling effectiveness. One slow "
            "partition will dominate regardless of how many workers you add. "
            "Resolve the skew first, then scaling will be effective."
        )
    elif par_pct < 30:
        output.append(
            f"⚠ Low parallelism ({par_pct:.0f}%) means your cluster is already "
            "underutilised. Adding workers will not speed up this job. "
            "Increase partition count first (see top recommendation)."
        )
    else:
        output.append(
            "✓ This job's bottleneck is in parallel computation — scaling up executors "
            "should reduce runtime proportionally. Check the Scaling Predictions table "
            "in sparklens_predictions for estimated runtimes at different executor counts."
        )
    output.append("")


def _enrich_fix(fix_text: str, category: str, metrics: dict) -> str:
    """Replace terse internal fix strings with full actionable text."""
    ft = (fix_text or "").lower()

    # Driver-overhead fixes legitimately mention "coalesce" and "shuffle" in their
    # context, but that refers to reducing shuffle *stage count*, not to the
    # repartition-vs-coalesce partitioning mistake.  Skip all pattern matching
    # when the category is driver-related so the original text is preserved.
    if "driver" in (category or "").lower():
        return fix_text

    if "coalesce" in ft and "shuffle" in ft:
        return (
            "Use .repartition(N) to increase partition count before shuffle stages, "
            "not .coalesce(). coalesce() reduces partitions (merging existing ones) "
            "while repartition() creates new evenly-sized partitions. "
            "For groupBy/join operations, target 2-3x your total CPU core count."
        )
    if "salting" in ft or "salt" in ft:
        return (
            "Apply key salting to distribute hot-key data across multiple partitions. "
            "Add a random suffix (0-49) to your join/group key on the large side, "
            "then explode the small side to have one row per suffix value. "
            "This turns 1 overloaded partition into 50 balanced ones."
        )
    if "rocksdb" in ft or ("state" in ft and "store" in ft):
        return (
            "Switch your streaming state store to RocksDB for better memory management: "
            "spark.conf.set('spark.sql.streaming.stateStore.providerClass', "
            "'org.apache.spark.sql.execution.streaming.state.RocksDBStateStoreProvider') "
            "RocksDB stores state on-disk rather than in JVM heap, dramatically "
            "reducing GC pressure for stateful streaming jobs with large state."
        )
    if "broadcast" in ft:
        return (
            "Use broadcast join for lookup tables under 100 MB: "
            "result = large_df.join(F.broadcast(lookup_df), 'key') "
            "Also set: spark.conf.set('spark.sql.autoBroadcastJoinThreshold', '104857600')  # 100 MB"
        )
    if "partition" in ft or "shuffle.partitions" in ft:
        cores = metrics.get("executor_count", 4) * metrics.get("cores_per_executor", 4)
        target = max(200, cores * 3)
        return (
            f"Set shuffle partition count to match your cluster size: "
            f"spark.conf.set('spark.sql.shuffle.partitions', '{target}')  "
            f"# {cores} total cores x 3 = {target} partitions. "
            "Also enable AQE: spark.conf.set('spark.sql.adaptive.enabled', 'true')"
        )
    if "collect" in ft or "topandas" in ft:
        return (
            "Remove .collect() and .toPandas() calls — these pull ALL data to the driver. "
            "Write results to storage instead: df.write.mode('overwrite').parquet('/path/to/output') "
            "or use .limit(1000).toPandas() only for small diagnostic samples."
        )
    if "native" in ft or "nee" in ft:
        return (
            "Enable the Native Execution Engine (NEE) for vectorized query processing: "
            "spark.conf.set('spark.native.enabled', 'true') "
            "NEE can improve CPU-bound query performance by 2-5x using SIMD CPU instructions "
            "instead of row-by-row JVM code."
        )
    # No enrichment matched — return original text unchanged.
    return fix_text


def _format_streaming_recommendation_block(lines: list) -> str:
    """Produce a streaming-specific recommendation block.

    Uses the same visual format as batch output — emoji severity headers,
    structured root-cause / impact / fix sections — but suppresses the
    performance score and scaling outlook, which are not meaningful for
    streaming jobs.  Called by _format_plaintext_recommendation_block when
    job_type == 'STREAMING'.
    """
    cleaned = [_normalize_line(x) for x in (lines or []) if str(x or "").strip()]

    primary_category = ""
    primary_severity = "HIGH"
    root_cause = ""
    impact = ""
    fixes_by_num: dict[int, str] = {}
    secondary: list[dict[str, str]] = []

    # Health indicators parsed from metric-style lines embedded in the stream
    avg_batch_ms: float | None = None
    state_memory_mb: float | None = None

    i = 0
    while i < len(cleaned):
        line = cleaned[i]
        sl = line.lower()

        if line.startswith("PRIMARY ISSUE:"):
            m = re.match(r"^PRIMARY ISSUE:\s*(.*?)\s*\[(CRITICAL|HIGH|MEDIUM|LOW)\]\s*$", line)
            if m:
                primary_category = m.group(1).strip()
                primary_severity = m.group(2).strip().upper()
            else:
                primary_category = line.split(":", 1)[-1].strip()
        elif line.startswith("Root Cause:"):
            root_cause = line.split(":", 1)[-1].strip()
        elif line.startswith("Impact:"):
            impact = line.split(":", 1)[-1].strip()
        elif line.startswith("PERFORMANCE SUMMARY:"):
            pass  # suppress — not applicable to streaming jobs
        else:
            # Health indicator lines (avg batch duration / state memory)
            if "avg batch" in sl or "batch duration" in sl:
                mh = re.search(r"(\d+\.?\d*)\s*(ms|s|sec)", line, re.IGNORECASE)
                if mh:
                    val = float(mh.group(1))
                    if mh.group(2).lower() in ("s", "sec"):
                        val *= 1000
                    avg_batch_ms = val
            if "state" in sl and ("mb" in sl or "memory" in sl):
                mh = re.search(r"(\d+\.?\d*)\s*mb", line, re.IGNORECASE)
                if mh:
                    state_memory_mb = float(mh.group(1))

            m_fix = re.match(r"^Fix\s+(\d+)\s*:\s*(.*)$", line)
            if m_fix:
                try:
                    num = int(m_fix.group(1))
                except Exception:
                    num = len(fixes_by_num) + 1
                fixes_by_num[num] = m_fix.group(2).strip()
            else:
                m_sec = re.match(
                    r"^(\d+)\.\s+(.*?)\s+\[(CRITICAL|HIGH|MEDIUM|LOW)\]\s*:\s*(.*)$",
                    line,
                )
                if m_sec:
                    try:
                        sec_idx = int(m_sec.group(1))
                    except Exception:
                        sec_idx = len(secondary) + 1
                    sec_d: dict[str, str] = {
                        "idx": str(sec_idx),
                        "category": m_sec.group(2).strip(),
                        "severity": m_sec.group(3).strip().upper(),
                        "cause": m_sec.group(4).strip(),
                        "fix": "",
                    }
                    if i + 1 < len(cleaned) and cleaned[i + 1].startswith("Fix:"):
                        sec_d["fix"] = cleaned[i + 1].split(":", 1)[-1].strip()
                        i += 1
                    secondary.append(sec_d)
        i += 1

    if fixes_by_num:
        fixes = [fixes_by_num[k] for k in sorted(fixes_by_num.keys())]
    else:
        fixes = ["Review trigger interval, state store configuration, and source partition count"]

    out: list[str] = []

    # Primary header with severity emoji — same visual style as batch output
    title = primary_category or "Streaming Performance Analysis"
    primary_header = f"{_severity_emoji(primary_severity)} {primary_severity} \u2014 {title} (STREAMING)"
    out.append(primary_header)

    if root_cause:
        out.append(f"\U0001f4cc ROOT CAUSE  {root_cause}")
    if impact:
        out.append(f"\U0001f4ca IMPACT  {impact}")

    # Streaming health indicators (batch latency + state store) when available
    health_items: list[str] = []
    if avg_batch_ms is not None:
        if avg_batch_ms < 5000:
            health_items.append(f"Batch latency \u2705 {avg_batch_ms:.0f}ms avg")
        elif avg_batch_ms < 30000:
            health_items.append(f"Batch latency \u26a0 {avg_batch_ms / 1000:.1f}s avg \u2014 target <5s")
        else:
            health_items.append(f"Batch latency \U0001f534 {avg_batch_ms / 1000:.1f}s avg \u2014 trigger at risk")
    if state_memory_mb is not None:
        if state_memory_mb < 500:
            health_items.append(f"State store \u2705 {state_memory_mb:.0f}MB")
        elif state_memory_mb < 2000:
            health_items.append(f"State store \u26a0 {state_memory_mb:.0f}MB \u2014 monitor growth")
        else:
            health_items.append(f"State store \U0001f534 {state_memory_mb:.0f}MB \u2014 OOM risk")
    if health_items:
        out.append("\U0001f4c8 STREAMING HEALTH  " + " \u2502 ".join(health_items))

    # Fix actions
    out.append("\U0001f527 FIXES")
    for idx, fix in enumerate(fixes, 1):
        fix_norm = _normalize_body_text(fix)
        warn = "WARNING" in fix.upper() or "will not help" in fix.lower()
        prefix = f"    {idx}. " + ("\u26a0\ufe0f  " if warn else "")
        out.append(prefix + fix_norm)

    # Secondary issues
    if secondary:
        out.append(f"\n\U0001f7e1 SECONDARY ISSUES ({len(secondary)})")
        for sec in secondary:
            sev_abbr = sec.get("severity", "")
            icon = (
                "\U0001f534 CRITICAL" if sev_abbr == "CRITICAL"
                else ("\U0001f7e1 HIGH" if sev_abbr == "HIGH" else "\U0001f535 MEDIUM")
            )
            out.append(f"\n[{sec['idx']}] {icon} \u2502  {sec['category']}")
            out.append(f"    {sec.get('cause', '')}")
            if sec.get("fix"):
                fix_norm = _normalize_body_text(sec["fix"])
                out.append(f"    \u2192 Fix: {fix_norm}")

    # Streaming-specific note — replaces the performance score section
    out.append("\n\u26a0 Performance score is not applicable to streaming jobs.")
    out.append("  Evaluate streaming health by batch latency and state store growth,")
    out.append("  not by executor efficiency or task parallelism metrics.")

    return "\n".join(out) + "\n"


def _normalize_line(s: str) -> str:
    s = (s or "").strip("\n")

    # Remove the common " - " bullet artifacts.
    s = s.strip()
    if s.startswith("-"):
        s = s.lstrip("-").strip()

    # Collapse multiple spaces while preserving intentional indentation.
    if s and not s.startswith(" "):
        s = re.sub(r"\s{2,}", " ", s)
    return s


def _fix_executor_pluralization(text: str) -> str:
    """Fix executor/executors pluralization in narrative prose.

    Examples:
        - "across 1 executors" -> "across 1 executor"
        - "across 2 executor"  -> "across 2 executors"
    """
    s = text or ""
    # Fix common incorrect pluralization.
    s = re.sub(r"\b1\s+executors\b", "1 executor", s)
    s = re.sub(r"\b([2-9]\d*)\s+executor\b", r"\1 executors", s)
    s = re.sub(r"\b0\s+executor\b", "0 executors", s)
    return s


def _normalize_body_text(s: str) -> str:
    # Narrative text reads better with an em dash.
    normalized = _normalize_line(s).replace(" - ", " — ")
    return _fix_executor_pluralization(normalized)


def _format_plaintext_recommendation_block(
    lines: list[str],
    job_type: str | None = None,
    metrics: dict | None = None,
) -> str:
    """Format the notebook-generated recommendation lines into a single plain-text block.

    This intentionally uses only Unicode box/line drawing and emoji (no HTML/Markdown).
    """

    is_streaming = (job_type or "").strip().upper() == "STREAMING"
    if is_streaming:
        return _format_streaming_recommendation_block(lines)

    cleaned = [_normalize_line(x) for x in (lines or []) if str(x or "").strip()]

    primary_category = "No critical performance issues detected."
    primary_severity = "LOW"
    root_cause = "No critical performance issues detected."
    impact = "N/A"
    job_type_label = (job_type or "").strip().upper()
    if job_type_label not in {"BATCH", "STREAMING"}:
        job_type_label = ""
    fixes_by_num: dict[int, str] = {}

    secondary: list[dict[str, str]] = []

    score_val: int | None = None
    cpu_pct: float | None = None
    parallel_pct: float | None = None
    gc_pct: float | None = None
    skew_val: float | None = None

    i = 0
    while i < len(cleaned):
        line = cleaned[i]

        if line.startswith("PRIMARY ISSUE:"):
            m = re.match(r"^PRIMARY ISSUE:\s*(.*?)\s*\[(CRITICAL|HIGH|MEDIUM|LOW)\]\s*$", line)
            if m:
                primary_category = m.group(1).strip()
                primary_severity = m.group(2).strip().upper()
            else:
                primary_category = line.split(":", 1)[-1].strip()
        elif line.startswith("Root Cause:"):
            root_cause = line.split(":", 1)[-1].strip()
        elif line.startswith("Impact:"):
            impact = line.split(":", 1)[-1].strip()
        else:
            m_fix = re.match(r"^Fix\s+(\d+)\s*:\s*(.*)$", line)
            if m_fix:
                try:
                    num = int(m_fix.group(1))
                except Exception:
                    num = len(fixes_by_num) + 1
                fixes_by_num[num] = m_fix.group(2).strip()
            else:
                # Secondary issue line format:
                # "1. Category [HIGH]: Root cause..."
                m_sec = re.match(
                    r"^(\d+)\.\s+(.*?)\s+\[(CRITICAL|HIGH|MEDIUM|LOW)\]\s*:\s*(.*)$",
                    line,
                )
                if m_sec:
                    try:
                        sec_idx = int(m_sec.group(1))
                    except Exception:
                        sec_idx = len(secondary) + 1
                    sec: dict[str, str] = {
                        "idx": str(sec_idx),
                        "category": m_sec.group(2).strip(),
                        "severity": m_sec.group(3).strip().upper(),
                        "cause": m_sec.group(4).strip(),
                        "fix": "",
                    }
                    # Next line is typically "Fix: ..."
                    if i + 1 < len(cleaned) and cleaned[i + 1].startswith("Fix:"):
                        sec["fix"] = cleaned[i + 1].split(":", 1)[-1].strip()
                        i += 1
                    secondary.append(sec)
                elif line.startswith("PERFORMANCE SUMMARY:"):
                    # Example:
                    # PERFORMANCE SUMMARY: EXCELLENT (76/100) | CPU: 27.6% | Parallelism: 100.0% | GC: 2.6% | Skew: 1.1x
                    # Grade text is ignored; we recompute based on numeric score thresholds.
                    m_score = re.search(r"\((\d+)\s*/\s*100\)", line)
                    if m_score:
                        try:
                            score_val = int(m_score.group(1))
                        except Exception:
                            score_val = None

                    for part in [p.strip() for p in line.split("|")]:
                        if part.startswith("CPU:"):
                            try:
                                cpu_pct = float(part.split(":", 1)[1].strip().rstrip("%"))
                            except Exception:
                                pass
                        elif part.startswith("Parallelism:"):
                            try:
                                parallel_pct = float(part.split(":", 1)[1].strip().rstrip("%"))
                            except Exception:
                                pass
                        elif part.startswith("GC:"):
                            try:
                                gc_pct = float(part.split(":", 1)[1].strip().rstrip("%"))
                            except Exception:
                                pass
                        elif part.startswith("Skew:"):
                            try:
                                skew_str = part.split(":", 1)[1].strip().rstrip("x")
                                skew_val = float(skew_str)
                            except Exception:
                                pass

        i += 1

    if fixes_by_num:
        fixes = [fixes_by_num[k] for k in sorted(fixes_by_num.keys())]
    else:
        fixes = ["No action required"]

    # Derive score from metrics if missing.
    if score_val is None and all(v is not None for v in (cpu_pct, parallel_pct, gc_pct, skew_val)):
        # executor_eff, parallelism_score, gc_overhead and task_skew mapping.
        executor_eff = float(cpu_pct) / 100.0
        parallelism_score = float(parallel_pct) / 100.0
        gc_overhead = float(gc_pct) / 100.0
        task_skew = float(skew_val)
        perf_score = (
            (executor_eff * 30)
            + (parallelism_score * 30)
            + ((1.0 - min(1.0, gc_overhead)) * 20)
            + ((1.0 / max(1.0, task_skew)) * 20)
        )
        score_val = int(round(perf_score))

    if score_val is None:
        score_val = 0

    # Defaults if any metric is missing.
    cpu_pct = 0.0 if cpu_pct is None else cpu_pct
    parallel_pct = 0.0 if parallel_pct is None else parallel_pct
    gc_pct = 0.0 if gc_pct is None else gc_pct
    skew_val = 1.0 if skew_val is None else skew_val

    # Promote extreme task skew to primary issue.
    # Requirement:
    #   - skew > 5x  -> at minimum HIGH and must not show LOW / "No action required"
    #   - skew > 10x -> CRITICAL as the primary issue, even if driver overhead is present
    # Guard: never override a CRITICAL driver-overhead primary — 93% driver time swamps
    # any skew signal; the real fix is eliminating driver work, not salting keys.
    _skip_skew_promotion = (
        primary_severity == "CRITICAL"
        and "driver" in (primary_category or "").lower()
    )
    if float(skew_val) > 5.0 and not _skip_skew_promotion:
        prev_primary_category = primary_category
        prev_primary_severity = primary_severity
        prev_root_cause = root_cause
        prev_fixes = fixes

        primary_category = "Data Skew"
        primary_severity = "CRITICAL" if float(skew_val) > 10.0 else "HIGH"

        skew_display = f"{float(skew_val):.1f}x"
        root_cause = (
            f"Task skew ratio {skew_display} — some tasks take {skew_display} longer than average"
        )
        impact = "Straggler tasks dominate stage runtime — poor scaling and long-tail latency"
        fixes = [
            "Apply salting to hot join keys",
            "Repartition with df.repartition(N, 'key_col') to redistribute",
            "Use AQE skew join hint: spark.sql.adaptive.skewJoin.enabled=true",
        ]

        # Keep the previous primary issue visible as a secondary issue.
        try:
            prev_cat_norm = (prev_primary_category or "").strip().lower()
            if prev_cat_norm and prev_cat_norm != "data skew":
                already_present = any(
                    (prev_cat_norm == (str(sec.get("category", "")).strip().lower()))
                    for sec in secondary
                )
                if not already_present:
                    prev_sec: dict[str, str] = {
                        "idx": "0",
                        "category": str(prev_primary_category),
                        "severity": str(prev_primary_severity).strip().upper() or "LOW",
                        "cause": str(prev_root_cause),
                        "fix": "",
                    }
                    if isinstance(prev_fixes, list) and prev_fixes:
                        if str(prev_fixes[0]).strip() and str(prev_fixes[0]).strip().lower() != "no action required":
                            prev_sec["fix"] = str(prev_fixes[0]).strip()
                    secondary.insert(0, prev_sec)
        except Exception:
            # Best-effort only; do not fail formatting.
            pass

    grade_emoji, grade_label = _score_grade(int(score_val))

    def _is_primary_driver_overhead(category: str) -> bool:
        c = (category or "").strip().lower()
        return ("driver overhead" in c) or ("driver coordination" in c)

    # Primary header (plain text, no boxes).
    box_inner = 58

    title = primary_category
    if job_type_label:
        title = f"{title} ({job_type_label})"

    # Keep the first line reasonably short for database cells.
    max_title = 72
    if len(title) > max_title:
        title = title[: max(0, max_title - 1)] + "…"

    primary_header = f"{_severity_emoji(primary_severity)} {primary_severity} — {title}"

    # Fix lines with warning emoji based on content.
    fix_lines: list[str] = []
    for idx, fix in enumerate(fixes, 1):
        fix_norm = _normalize_body_text(fix)
        warn = ("will not help" in fix_norm.lower()) or ("avoid" in fix_norm.lower())
        prefix = f"    {idx}. " + ("⚠️  " if warn else "")
        fix_lines.append(prefix + fix_norm)

    # Secondary issues.
    sec_lines: list[str] = []
    secondary_filtered = secondary
    if secondary_filtered and _is_primary_driver_overhead(primary_category):
        secondary_filtered = [
            sec
            for sec in secondary_filtered
            if "cpu" not in str(sec.get("category", "")).lower()
        ]

    if secondary_filtered:
        sec_lines.append("")
        sec_lines.append(f"🟡 SECONDARY ISSUES ({len(secondary_filtered)})")
        sec_lines.append("")
        def _sec_sort_key(x: dict[str, str]) -> int:
            try:
                return int(x.get("idx", "0"))
            except Exception:
                return 0

        secondary_sorted = sorted(secondary_filtered, key=_sec_sort_key)

        for j, sec in enumerate(secondary_sorted, 1):
            sev = sec.get("severity", "LOW").upper()
            cat = sec.get("category", "").strip()
            cause = _normalize_body_text(sec.get("cause", "").strip())
            fx = _normalize_body_text(sec.get("fix", "").strip())
            sec_lines.append(f"    [{j}] {_severity_emoji(sev)} {sev:<5} │  {cat}")
            if cause:
                sec_lines.append(f"        {cause}")
            if fx:
                enriched_fx = _enrich_fix(fx, cat, metrics or {})
                sec_lines.append(f"        → Fix: {enriched_fx}")
            sec_lines.append("")

    # Performance summary always last.
    perf_lines: list[str] = []
    perf_lines.append("")
    perf_lines.append("📈 PERFORMANCE SUMMARY")
    grade_bar = _score_bar(int(score_val))
    perf_lines.append(f"    Score  : {int(score_val)}/100  {grade_emoji} {grade_label}  {grade_bar}")
    perf_lines.append(f"    {_score_explanation(int(score_val), grade_label)}")
    perf_lines.append(
        f"    CPU    : {cpu_pct:.1f}%   {_metric_health_cpu(cpu_pct / 100.0)}"
    )
    perf_lines.append(
        f"    Parallel: {parallel_pct:.1f}% {_metric_health_parallelism(parallel_pct / 100.0)}"
    )
    perf_lines.append(
        f"    GC     : {gc_pct:.1f}%    {_metric_health_gc(gc_pct / 100.0)}"
    )
    perf_lines.append(
        f"    Skew   : {skew_val:.1f}x    {_metric_health_skew(skew_val)}"
    )

    # Assemble.
    scaling_lines: list[str] = []
    _append_scaling_outlook(scaling_lines, cpu_pct, parallel_pct, root_cause, skew_val)

    out: list[str] = [
        primary_header,
        "",
        "📌 ROOT CAUSE",
        f"    {_normalize_body_text(root_cause)}",
        "",
        "📊 IMPACT",
        f"    {_normalize_body_text(impact)}",
        "",
        "🔧 FIXES",
        *fix_lines,
        "",
        *sec_lines,
        *scaling_lines,
        *perf_lines,
    ]

    # Strip trailing whitespace.
    out = [line.rstrip() for line in out]

    # Final cleanup: never emit orphaned " - " artifacts.
    out = [line for line in out if line.strip() != "-" and line.strip() != "-".strip()]
    return "\n".join(out).rstrip() + "\n"


def _install_write_kusto_wrapper(ns: dict[str, Any]) -> None:
    """Wrap write_kusto_df so recommendations are written as a single formatted block per app."""

    fn = ns.get("write_kusto_df")
    if not callable(fn):
        return

    if ns.get("_sma_write_kusto_wrapped") is fn:
        return

    base_fn = fn

    def _wrapped_write_kusto_df(df: Any, table: str, mode: str = "Append", row_count: "int | None" = None) -> Any:
        try:
            if str(table) == "sparklens_recommedations":
                # Expect schema: app_id, recommendation (one row per line today).
                try:
                    import pandas as pd
                    from pyspark.sql.types import StructType, StructField, StringType
                    from pyspark.sql.functions import col, lit

                    out_schema = StructType(
                        [
                            StructField("app_id", StringType(), True),
                            StructField("recommendation", StringType(), True),
                        ]
                    )

                    # Attach job type from metrics_out if available.
                    # Metric is emitted as: ("Job Type", 1.0 if streaming else 0.0)
                    try:
                        metrics_out = ns.get("metrics_out")
                        if metrics_out is not None:
                            job_type_df = (
                                metrics_out
                                .filter(col("metric") == lit("Job Type"))
                                .select(col("app_id"), col("value").alias("_job_type_value"))
                                # Deduplicate to at most one row per app to prevent
                                # a 1:N join from multiplying recommendation rows.
                                .dropDuplicates(["app_id"])
                            )
                            df = df.join(job_type_df, on="app_id", how="left")
                    except Exception:
                        logger.exception("Failed to attach job type for recommendation formatting")

                    # Format recommendations on the driver — avoids shipping the
                    # module-level _format_plaintext_recommendation_block to
                    # worker nodes via cloudpickle (workers lack this package).
                    from pyspark.sql import SparkSession as _SparkSession_local

                    _recs_collected = df.collect()
                    _groups: dict = {}
                    for _row in _recs_collected:
                        _d = _row.asDict()
                        _aid = str(_d.get("app_id") or "")
                        _line = str(_d.get("recommendation") or "")
                        _jt = _d.get("_job_type_value")
                        if _aid not in _groups:
                            _groups[_aid] = {"lines": [], "job_type": _jt}
                        _groups[_aid]["lines"].append(_line)

                    _formatted_rows = []
                    for _aid, _data in _groups.items():
                        _job_type_label = ""
                        try:
                            _v = _data["job_type"]
                            if _v is not None and float(_v) >= 0.5:
                                _job_type_label = "STREAMING"
                            else:
                                _job_type_label = "BATCH"
                        except Exception:
                            _job_type_label = ""
                        # Fallback: if the metric join missed or returned batch, but
                        # the raw recommendation lines contain streaming signal markers,
                        # treat as streaming so the correct formatter branch is used.
                        if _job_type_label != "STREAMING":
                            for _l in _data["lines"]:
                                if str(_l).startswith("[Streaming") or "Streaming:" in str(_l):
                                    _job_type_label = "STREAMING"
                                    break
                        # Deduplicate lines while preserving order.
                        # Duplicate lines arise when the job-type join produces
                        # multiple matching rows (1:N), inflating the line list.
                        # Without deduplication, the secondary-issues list inside
                        # _format_plaintext_recommendation_block accumulates
                        # repeated entries, causing multiple copies of each
                        # section in the formatted output.
                        _seen_lines: set = set()
                        _unique_lines: list = []
                        for _l in _data["lines"]:
                            if _l not in _seen_lines:
                                _seen_lines.add(_l)
                                _unique_lines.append(_l)
                        _app_metrics: dict = {}
                        try:
                            _mo = ns.get("metrics_out")
                            if _mo is not None:
                                from pyspark.sql.functions import col as _col, lit as _lit
                                _m_rows = (
                                    _mo.filter(_col("app_id") == _lit(_aid))
                                       .filter(_col("metric").isin(["Executor Count"]))
                                       .select("metric", "value")
                                       .collect()
                                )
                                for _mr in _m_rows:
                                    if _mr["metric"] == "Executor Count":
                                        _app_metrics["executor_count"] = int(_mr["value"])
                        except Exception:
                            pass
                        _formatted = _format_plaintext_recommendation_block(
                            _unique_lines, job_type=_job_type_label, metrics=_app_metrics
                        )
                        _formatted_rows.append({"app_id": _aid, "recommendation": _formatted})

                    _active_spark = _SparkSession_local.getActiveSession() or ns.get("spark")
                    if _active_spark is not None:
                        df = _active_spark.createDataFrame(
                            _formatted_rows if _formatted_rows else [],
                            schema=out_schema,
                        )

                    # ----------------------------
                    # Fabric-specific recommendations (rule based)
                    # ----------------------------
                    try:
                        metrics_out = ns.get("metrics_out")
                        metadata_out = ns.get("metadata_out")
                        if metrics_out is not None and metadata_out is not None:
                            from pyspark.sql import functions as F

                            # Aggregate required metrics per app.
                            m = (
                                metrics_out
                                .groupBy("app_id")
                                .agg(
                                    F.max(F.when(col("metric") == lit("Executor Time %"), col("value"))).alias("executor_time_pct"),
                                    F.max(F.when(col("metric") == lit("Executor Wall Clock Time (sec)"), col("value"))).alias("executor_wall_clock"),
                                    F.max(F.when(col("metric") == lit("Application Duration (sec)"), col("value"))).alias("app_duration"),
                                    F.max(F.when(col("metric") == lit("Executor Efficiency"), col("value"))).alias("executor_eff"),
                                    F.max(F.when(col("metric") == lit("Job Type"), col("value"))).alias("job_type_value"),
                                    F.max(F.when(col("metric") == lit("Driver Time %"), col("value"))).alias("driver_time_pct"),
                                    F.max(F.when(col("metric") == lit("Driver Overhead %"), col("value"))).alias("driver_overhead_pct"),
                                )
                            )

                            # Derive executor wall clock % if it's missing.
                            m = m.withColumn(
                                "executor_time_pct_final",
                                F.coalesce(
                                    col("executor_time_pct"),
                                    (col("executor_wall_clock") / F.when(col("app_duration") > F.lit(0.0), col("app_duration")).otherwise(F.lit(1.0))) * F.lit(100.0),
                                ),
                            )

                            # Pull the relevant Fabric metadata per app.
                            meta_cols = set(metadata_out.columns)
                            if "app_id" in meta_cols:
                                meta_id = col("app_id")
                            elif "applicationId" in meta_cols:
                                meta_id = col("applicationId")
                            elif "applicationID" in meta_cols:
                                meta_id = col("applicationID")
                            else:
                                meta_id = None

                            # IMPORTANT: `spark.native.enabled` is a literal column name containing dots.
                            # Use backticks so Spark doesn't treat it as nested-field access.
                            nee_col = (
                                col("`spark.native.enabled`")
                                if "spark.native.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("spark_native_enabled")
                            hc_col = (
                                col("isHighConcurrencyEnabled")
                                if "isHighConcurrencyEnabled" in meta_cols
                                else F.lit(None)
                            ).alias("high_concurrency_enabled")

                            pythonauto_compact_col = (
                                col("`spark.databricks.delta.autoCompact.enabled`")
                                if "spark.databricks.delta.autoCompact.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("pythonauto_compact")
                            adaptive_file_size_col = (
                                col("`spark.microsoft.delta.targetFileSize.adaptive.enabled`")
                                if "spark.microsoft.delta.targetFileSize.adaptive.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("adaptive_file_size")
                            fast_optimize_col = (
                                col("`spark.microsoft.delta.optimize.fast.enabled`")
                                if "spark.microsoft.delta.optimize.fast.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("fast_optimize")
                            file_level_compaction_col = (
                                col("`spark.microsoft.delta.optimize.fileLevelTarget.enabled`")
                                if "spark.microsoft.delta.optimize.fileLevelTarget.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("file_level_compaction")
                            extended_stats_col = (
                                col("`spark.microsoft.delta.stats.collect.extended`")
                                if "spark.microsoft.delta.stats.collect.extended" in meta_cols
                                else F.lit(None)
                            ).alias("extended_stats")
                            snapshot_accel_col = (
                                col("`spark.microsoft.delta.snapshot.driverMode.enabled`")
                                if "spark.microsoft.delta.snapshot.driverMode.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("snapshot_accel")
                            vorder_col = (
                                col("`spark.sql.parquet.vorder.default`")
                                if "spark.sql.parquet.vorder.default" in meta_cols
                                else F.lit(None)
                            ).alias("vorder")
                            optimize_write_col = (
                                col("`spark.microsoft.delta.optimizeWrite.enabled`")
                                if "spark.microsoft.delta.optimizeWrite.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("optimize_write")
                            optimize_write_dbx_col = (
                                col("`spark.databricks.delta.optimizeWrite.enabled`")
                                if "spark.databricks.delta.optimizeWrite.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("optimize_write_dbx")
                            optimize_write_dbx_part_col = (
                                col("`spark.databricks.delta.optimizeWrite.partitioned.enabled`")
                                if "spark.databricks.delta.optimizeWrite.partitioned.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("optimize_write_dbx_partitioned")
                            resource_profile_col = (
                                col("`spark.fabric.resourceProfile`")
                                if "spark.fabric.resourceProfile" in meta_cols
                                else F.lit(None)
                            ).alias("resource_profile")

                            if meta_id is not None:
                                meta = metadata_out.select(
                                    meta_id.cast("string").alias("app_id"),
                                    nee_col,
                                    hc_col,
                                    pythonauto_compact_col,
                                    adaptive_file_size_col,
                                    fast_optimize_col,
                                    file_level_compaction_col,
                                    extended_stats_col,
                                    snapshot_accel_col,
                                    vorder_col,
                                    optimize_write_col,
                                    optimize_write_dbx_col,
                                    optimize_write_dbx_part_col,
                                    resource_profile_col,
                                )
                            else:
                                meta = metadata_out.select(
                                    F.lit(None).cast("string").alias("app_id"),
                                    nee_col,
                                    hc_col,
                                    pythonauto_compact_col,
                                    adaptive_file_size_col,
                                    fast_optimize_col,
                                    file_level_compaction_col,
                                    extended_stats_col,
                                    snapshot_accel_col,
                                    vorder_col,
                                    optimize_write_col,
                                    optimize_write_dbx_col,
                                    optimize_write_dbx_part_col,
                                    resource_profile_col,
                                )

                            features = m.join(meta, on="app_id", how="left")

                            fabric_schema = StructType(
                                [
                                    StructField("app_id", StringType(), True),
                                    StructField("recommendation", StringType(), True),
                                ]
                            )

                            def _fabric_rules(pdf: "pd.DataFrame") -> "pd.DataFrame":
                                # Delegate to module-level _fabric_rules if it has been
                                # overridden by analyzer_recs_rewrite (identified by module attr).
                                import sys as _sys
                                _mod = _sys.modules.get("spark_monitoring_analyzer.analyzer")
                                if _mod is not None:
                                    _override = getattr(_mod, "_fabric_rules", None)
                                    if (
                                        _override is not None
                                        and getattr(_override, "__module__", None)
                                        == "spark_monitoring_analyzer.analyzer_recs_rewrite"
                                    ):
                                        return _override(pdf)

                                if pdf is None or pdf.empty:
                                    return pd.DataFrame([], columns=["app_id", "recommendation"])

                                app_id = str(pdf["app_id"].iloc[0])
                                exec_pct = None
                                exec_eff = None
                                job_type_val = None
                                driver_time_pct = None
                                driver_overhead_pct = None
                                nee_raw = None
                                hc_raw = None
                                pythonauto_compact = None
                                adaptive_file_size = None
                                fast_optimize = None
                                file_level_compaction = None
                                extended_stats = None
                                snapshot_accel = None
                                vorder = None
                                optimize_write = None
                                optimize_write_dbx = None
                                optimize_write_dbx_partitioned = None
                                resource_profile = None
                                try:
                                    if "executor_time_pct_final" in pdf.columns:
                                        v = pdf["executor_time_pct_final"].iloc[0]
                                        exec_pct = float(v) if v is not None else None
                                    if "executor_eff" in pdf.columns:
                                        v = pdf["executor_eff"].iloc[0]
                                        exec_eff = float(v) if v is not None else None
                                    if "job_type_value" in pdf.columns:
                                        job_type_val = pdf["job_type_value"].iloc[0]
                                    if "driver_time_pct" in pdf.columns:
                                        v = pdf["driver_time_pct"].iloc[0]
                                        driver_time_pct = float(v) if v is not None else None
                                    if "driver_overhead_pct" in pdf.columns:
                                        v = pdf["driver_overhead_pct"].iloc[0]
                                        driver_overhead_pct = float(v) if v is not None else None
                                    if "spark_native_enabled" in pdf.columns:
                                        nee_raw = pdf["spark_native_enabled"].iloc[0]
                                    if "high_concurrency_enabled" in pdf.columns:
                                        hc_raw = pdf["high_concurrency_enabled"].iloc[0]
                                    if "pythonauto_compact" in pdf.columns:
                                        pythonauto_compact = pdf["pythonauto_compact"].iloc[0]
                                    if "adaptive_file_size" in pdf.columns:
                                        adaptive_file_size = pdf["adaptive_file_size"].iloc[0]
                                    if "fast_optimize" in pdf.columns:
                                        fast_optimize = pdf["fast_optimize"].iloc[0]
                                    if "file_level_compaction" in pdf.columns:
                                        file_level_compaction = pdf["file_level_compaction"].iloc[0]
                                    if "extended_stats" in pdf.columns:
                                        extended_stats = pdf["extended_stats"].iloc[0]
                                    if "snapshot_accel" in pdf.columns:
                                        snapshot_accel = pdf["snapshot_accel"].iloc[0]
                                    if "vorder" in pdf.columns:
                                        vorder = pdf["vorder"].iloc[0]
                                    if "optimize_write" in pdf.columns:
                                        optimize_write = pdf["optimize_write"].iloc[0]
                                    if "optimize_write_dbx" in pdf.columns:
                                        optimize_write_dbx = pdf["optimize_write_dbx"].iloc[0]
                                    if "optimize_write_dbx_partitioned" in pdf.columns:
                                        optimize_write_dbx_partitioned = pdf["optimize_write_dbx_partitioned"].iloc[0]
                                    if "resource_profile" in pdf.columns:
                                        resource_profile = pdf["resource_profile"].iloc[0]
                                except Exception:
                                    pass

                                job_type_label = "STREAMING" if (job_type_val is not None and float(job_type_val) >= 0.5) else "BATCH"

                                def _truthy(x: Any) -> bool:
                                    if x is None:
                                        return False
                                    if isinstance(x, bool):
                                        return bool(x)
                                    s = str(x).strip().lower()
                                    return s in {"true", "1", "yes", "enabled", "on"}

                                def _falsy(x: Any) -> bool:
                                    if x is None:
                                        return False
                                    if isinstance(x, bool):
                                        return not bool(x)
                                    s = str(x).strip().lower()
                                    return s in {"false", "0", "no", "disabled", "off"}

                                nee_disabled = _falsy(nee_raw)
                                hc_disabled = _falsy(hc_raw)

                                # Rules (priority order; exactly one base rule can fire)
                                recs: list[str] = []
                                driver_heavy = False
                                executor_heavy_header = False

                                # Helper: interpret efficiency in either 0-1 or 0-100 scale.
                                exec_eff_pct: float | None = None
                                if exec_eff is not None:
                                    try:
                                        exec_eff_pct = float(exec_eff) * 100.0 if float(exec_eff) <= 1.0 else float(exec_eff)
                                    except Exception:
                                        exec_eff_pct = None

                                # Driver idle % proxy: use driver_time_pct when present, else driver_overhead_pct.
                                driver_idle_pct: float | None = driver_time_pct if driver_time_pct is not None else driver_overhead_pct

                                def _fmt_pct_0_100(v: Any) -> str:
                                    """Format a value that is expected to already be a 0–100 percentage."""

                                    if v is None:
                                        return "N/A"
                                    try:
                                        import math

                                        f = float(v)
                                        if math.isnan(f):
                                            return "N/A"
                                        return f"{f:.1f}%"
                                    except Exception:
                                        return "N/A"

                                def _fmt_pct_float(pct: float | None) -> str:
                                    if pct is None:
                                        return "N/A"
                                    try:
                                        return f"{float(pct):.1f}%"
                                    except Exception:
                                        return "N/A"

                                def _as_float(v: Any) -> float | None:
                                    if v is None:
                                        return None
                                    try:
                                        import math

                                        f = float(v)
                                        if math.isnan(f):
                                            return None
                                        return f
                                    except Exception:
                                        return None

                                def _clamp_pct(v: float | None) -> float | None:
                                    if v is None:
                                        return None
                                    try:
                                        return max(0.0, min(100.0, float(v)))
                                    except Exception:
                                        return None

                                # Wall clock percentages
                                # - Prefer the explicit Driver Time % metric when present.
                                # - If missing, derive it as 100 - Executor Wall Clock % (when available).
                                # - Ensure driver+executor adds up to 100% (normalize) when both are present.
                                driver_wc_raw = _as_float(driver_time_pct)
                                executor_wc_raw = _as_float(exec_pct)

                                if driver_wc_raw is None and executor_wc_raw is not None:
                                    driver_wc_raw = 100.0 - executor_wc_raw
                                if executor_wc_raw is None and driver_wc_raw is not None:
                                    executor_wc_raw = 100.0 - driver_wc_raw

                                driver_wc_raw = _clamp_pct(driver_wc_raw)
                                executor_wc_raw = _clamp_pct(executor_wc_raw)

                                if driver_wc_raw is not None and executor_wc_raw is not None:
                                    s = driver_wc_raw + executor_wc_raw
                                    if s > 0.0:
                                        driver_wc = 100.0 * driver_wc_raw / s
                                        executor_wc = 100.0 * executor_wc_raw / s
                                    else:
                                        driver_wc, executor_wc = driver_wc_raw, executor_wc_raw
                                else:
                                    driver_wc, executor_wc = driver_wc_raw, executor_wc_raw

                                metrics_line = (
                                    "📊 Metrics: Driver Wall Clock="
                                    f"{_fmt_pct_0_100(driver_wc)}, Executor Wall Clock="
                                    f"{_fmt_pct_0_100(executor_wc)}, Executor Efficiency="
                                    f"{_fmt_pct_float(exec_eff_pct)}"
                                )

                                # RULE 1 — Driver-heavy jobs (already working; keep detection, update message)
                                if driver_idle_pct is not None and float(driver_idle_pct) > 90.0:
                                    driver_heavy = True
                                    recs.append(
                                        "💰 Cost Optimization: Job is driver-heavy (>90% driver time).\n"
                                        "   Consider: (1) Run on a single-node pool — set autoscale min/max to 1\n"
                                        "             (2) Refactor to Python and run on a Python kernel instead"
                                    )

                                # RULE 2 — Executor-heavy jobs
                                elif (
                                    exec_eff_pct is not None
                                    and float(exec_eff_pct) > 50.0
                                    and driver_idle_pct is not None
                                    and float(driver_idle_pct) < 60.0
                                ):
                                    executor_heavy_header = True
                                    recs.append(
                                        "⚡ Performance Optimization: Job is executor-heavy — Spark resources are actively used.\n"
                                        "   (1) Enable Native Execution Engine (NEE): set spark.native.enabled=true\n"
                                        "       — vectorized execution can improve CPU-bound stages by 2-5x\n"
                                        "   (2) Enable High Concurrency mode to improve resource sharing"
                                    )

                                # Best practices + resource profile
                                # For driver-heavy jobs we emit ONLY the cost optimization item (Rule 1) to
                                # avoid noisy, non-actionable recommendations.
                                best_practice_items: list[str] = []
                                resource_profile_item: str | None = None

                                if not driver_heavy:
                                    # Best practices
                                    # Always emit all 8 properties with three-way status
                                    # (not configured / recommended change / ✅ validated)
                                    # for every job regardless of executor efficiency or type.

                                    def _norm(x: Any) -> str:
                                        return str(x).strip().lower()

                                    always_emit_bps = True

                                    def _effective_optimize_write() -> tuple[Any, str]:
                                        # Prefer Microsoft key, then Databricks keys when present.
                                        if optimize_write is not None:
                                            return optimize_write, "spark.microsoft.delta.optimizeWrite.enabled"
                                        if optimize_write_dbx is not None:
                                            return optimize_write_dbx, "spark.databricks.delta.optimizeWrite.enabled"
                                        if optimize_write_dbx_partitioned is not None:
                                            return (
                                                optimize_write_dbx_partitioned,
                                                "spark.databricks.delta.optimizeWrite.partitioned.enabled",
                                            )
                                        return None, "spark.microsoft.delta.optimizeWrite.enabled"

                                    def _emit_bp(
                                        prop_value: Any,
                                        prop_key_for_set: str,
                                        display_name: str,
                                        correct_value: str,
                                    ) -> None:
                                        """Emit best-practice lines following executor-heavy vs driver-heavy rules."""

                                        if prop_value is None:
                                            if not always_emit_bps:
                                                return
                                            best_practice_items.append(
                                                f"⚙️  Best Practice: {display_name} — not configured\n"
                                                f"         Recommended: spark.conf.set(\"{prop_key_for_set}\", {correct_value})"
                                            )
                                            return

                                        current = _norm(prop_value)
                                        if current == _norm(correct_value):
                                            if always_emit_bps:
                                                best_practice_items.append(
                                                    f"✅ Validated: {display_name} is correctly set to {current} — no action needed"
                                                )
                                            return

                                        # Present but wrong
                                        best_practice_items.append(
                                            f"⚙️  Best Practice: {display_name} is {current} — recommended: Set to {correct_value}\n"
                                            f"         Set: spark.conf.set(\"{prop_key_for_set}\", {correct_value})"
                                        )

                                    # Property table (8 properties)
                                    _emit_bp(
                                        pythonauto_compact,
                                        "spark.databricks.delta.autoCompact.enabled",
                                        "Auto Compaction",
                                        "true",
                                    )
                                    _emit_bp(
                                        adaptive_file_size,
                                        "spark.microsoft.delta.targetFileSize.adaptive.enabled",
                                        "Adaptive Target File Size",
                                        "true",
                                    )
                                    _emit_bp(
                                        fast_optimize,
                                        "spark.microsoft.delta.optimize.fast.enabled",
                                        "Fast Optimize",
                                        "true",
                                    )
                                    _emit_bp(
                                        file_level_compaction,
                                        "spark.microsoft.delta.optimize.fileLevelTarget.enabled",
                                        "File Level Compaction",
                                        "true",
                                    )
                                    _emit_bp(
                                        extended_stats,
                                        "spark.microsoft.delta.stats.collect.extended",
                                        "Extended Table Statistics",
                                        "true",
                                    )
                                    _emit_bp(
                                        snapshot_accel,
                                        "spark.microsoft.delta.snapshot.driverMode.enabled",
                                        "Snapshot Acceleration",
                                        "true",
                                    )
                                    # VORDER and OptimizeWrite are intentionally validated as DISABLED (correct_value="false").
                                    # Rationale: in write-heavy ETL pipelines these features add significant write overhead.
                                    # For read-heavy or BI workloads, flip correct_value to "true" here.
                                    _emit_bp(
                                        vorder,
                                        "spark.sql.parquet.vorder.default",
                                        "VORDER",
                                        "false",  # intentionally disabled for write-heavy workloads
                                    )
                                    _ow_val, _ow_key = _effective_optimize_write()
                                    _emit_bp(
                                        _ow_val,
                                        _ow_key,
                                        "Optimize Write",
                                        "false",  # intentionally disabled for write-heavy workloads
                                    )

                                    # Resource profile (informational)
                                    if resource_profile is not None:
                                        rp_raw = str(resource_profile).strip()
                                        rp = rp_raw.lower()
                                        if rp == "readheavyforspark":
                                            desc = "Optimized for Spark workloads with frequent reads"
                                        elif rp == "readheavyforpbi":
                                            desc = "Optimized for Power BI queries on Delta tables"
                                        elif rp == "writeheavy":
                                            desc = "Optimized for high-frequency ingestion and writes"
                                        elif rp == "custom":
                                            desc = "Fully user-defined configuration — verify settings manually"
                                        else:
                                            desc = "Unrecognized resource profile — verify this is intentional"
                                        resource_profile_item = (
                                            f"ℹ️  Resource Profile: {rp_raw} — {desc}\n"
                                            "       readHeavyForSpark → Optimized for Spark workloads with frequent reads\n"
                                            "       readHeavyForPBI → Optimized for Power BI queries on Delta tables\n"
                                            "       writeHeavy → Optimized for high-frequency ingestion and writes\n"
                                            "       custom → Fully user-defined configuration — configure after thorough benchmarking"
                                        )

                                # RULE 3 — Default (only when there are no actionable items)
                                if not recs and not best_practice_items:
                                    recs.append(
                                        "✅ No Fabric-level changes recommended — job configuration looks appropriate\n"
                                        "   for the detected workload pattern."
                                    )

                                # Final assembly: always include metrics.
                                final_recs = list(recs)
                                if driver_heavy or executor_heavy_header:
                                    final_recs.insert(1 if final_recs else 0, metrics_line)
                                else:
                                    final_recs.insert(0, metrics_line)

                                # Append best practices and resource profile after base rules + metrics.
                                final_recs.extend(best_practice_items)
                                if resource_profile_item is not None:
                                    final_recs.append(resource_profile_item)

                                # Plain text block similar to sparklens style (no boxes, no dividers).
                                header = f"🧵 FABRIC RECOMMENDATIONS ({job_type_label})"
                                body = "\n".join([f"    {i}. {r}" for i, r in enumerate(final_recs, 1)])
                                out = header + "\n\n" + body + "\n"
                                return pd.DataFrame([{"app_id": app_id, "recommendation": out}])

                            fabric_df = features.groupBy("app_id").applyInPandas(_fabric_rules, schema=fabric_schema)
                            fabric_df = fabric_df.filter(F.length(F.col("recommendation")) > 0)

                            # Write Fabric recommendations to their own table.
                            # Table name matches the user's requested/checked spelling.
                            base_fn(fabric_df, "fabric_recommedations", mode=mode)
                    except Exception:
                        logger.exception("Failed generating/writing Fabric recommendations")
                except Exception:
                    logger.exception("Failed to format recommendations before Kusto write; falling back to raw output")

        except Exception:
            # Never block writes because of formatting.
            logger.exception("Unexpected error in write_kusto_df wrapper")

        # Keep Kusto writes compatible with existing sparklens_metadata schema.
        # We may compute extra columns for Fabric recommendations, but don't force
        # them into the Kusto table unless it already supports them.
        if str(table) == "sparklens_metadata":
            try:
                extra_cols = [
                    "spark.databricks.delta.optimizeWrite.enabled",
                    "spark.databricks.delta.optimizeWrite.partitioned.enabled",
                ]
                if hasattr(df, "columns"):
                    for c in extra_cols:
                        if c in df.columns:
                            df = df.drop(c)
            except Exception:
                logger.exception("Failed to drop extra metadata columns before Kusto write")

        return base_fn(df, table, mode=mode, row_count=row_count)

    ns["write_kusto_df"] = _wrapped_write_kusto_df
    ns["_sma_write_kusto_wrapped"] = _wrapped_write_kusto_df


def _bootstrap_workers(sc: Any) -> None:
    """Install spark_monitoring_analyzer on every Spark worker node.

    In Fabric/Synapse Spark, ``pip install`` on the driver does *not*
    propagate to worker nodes.  ``applyInPandas`` UDFs are serialised by
    cloudpickle; because they reference module-level functions from this
    package, cloudpickle encodes those references by name (module + attr)
    rather than by value.  Workers therefore need the package importable.

    This bootstrap runs a fire-and-forget pip install across all executors
    before any UDF is dispatched.  The install is idempotent and silent so
    it does not block execution if a worker already has the package.
    """
    try:
        import importlib.metadata as _imeta
        _version = _imeta.version("spark_monitoring_analyzer")
    except Exception:
        logger.warning(
            "Could not determine spark_monitoring_analyzer version; "
            "skipping worker bootstrap"
        )
        return

    _whl_url = _WORKER_BOOTSTRAP_WHL_URL_TEMPLATE.format(version=_version)

    # Define the install function as a closure so cloudpickle serialises it
    # *by value* (bytecode + captured string), avoiding any dependency on
    # this module being importable on workers before the install completes.
    def _install(_: Any, url: str = _whl_url) -> None:
        import subprocess  # noqa: PLC0415
        import sys  # noqa: PLC0415
        subprocess.run(
            [
                sys.executable, "-m", "pip", "install",
                "--quiet", "--disable-pip-version-check", url,
            ],
            capture_output=True,
        )

    try:
        n = max(sc.defaultParallelism or 1, 1)
        sc.parallelize(range(n), n).foreach(_install)
        logger.info(
            "Worker bootstrap complete: spark_monitoring_analyzer==%s "
            "installed on %d executor partitions",
            _version,
            n,
        )
    except Exception:
        logger.warning(
            "Worker bootstrap failed (non-fatal); workers may lack "
            "spark_monitoring_analyzer — UDFs could fail",
            exc_info=True,
        )


def run(kusto_uri: str, database: str, chunk_size: int = 20) -> None:
    """Run the notebook pipeline in-order.

    Parameters
    ----------
    kusto_uri:
        Kusto cluster URI.
    database:
        Kusto database name.
    chunk_size:
        Number of Spark applications to process per Kusto round-trip.
        Lower values reduce peak memory pressure; higher values reduce
        Kusto query overhead.  Default: 20.
    """

    # Minimal logging wiring: don't override app logging if already configured.
    root_logger = logging.getLogger()
    if not root_logger.handlers:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s %(levelname)s %(name)s - %(message)s",
        )

    def _resolve_runtime_symbol(name: str) -> Any | None:
        # 1) If this module somehow has it.
        if name in globals():
            return globals()[name]

        # 2) Notebook/session global namespace.
        try:
            main_mod = importlib.import_module("__main__")
            if hasattr(main_mod, name):
                return getattr(main_mod, name)
        except Exception:
            pass

        # 3) Sometimes injected into builtins.
        try:
            if hasattr(builtins, name):
                return getattr(builtins, name)
        except Exception:
            pass

        # 4) Spark: try to discover an already-active session (does not create a new one).
        if name == "spark":
            try:
                from pyspark.sql import SparkSession

                active = SparkSession.getActiveSession()
                if active is not None:
                    return active
            except Exception:
                pass

        return None

    class _NotebookNamespace(dict):
        """Exec namespace that can auto-install wrappers during cell execution.

        This is required because some notebook cells define and *use* functions
        like `write_kusto_df` in the same cell; post-cell wrapping is too late.
        """

        _sma_in_setitem: bool = False

        def __setitem__(self, key: str, value: Any) -> None:  # type: ignore[override]
            super().__setitem__(key, value)

            # Avoid recursion when wrappers assign back into the namespace.
            if getattr(self, "_sma_in_setitem", False):
                return

            if key in {"generate_enhanced_recommendations", "write_kusto_df"}:
                try:
                    self._sma_in_setitem = True
                    _install_generate_wrapper(self)
                    _install_write_kusto_wrapper(self)
                finally:
                    self._sma_in_setitem = False

    ns: dict[str, Any] = _NotebookNamespace(
        {
            "__name__": "__main__",
            "kustoUri": kusto_uri,
            "database": database,
            "CHUNK_SIZE": chunk_size,
        }
    )

    # If running inside Fabric/Synapse notebooks, these are usually already present.
    for sym in ("spark", "notebookutils"):
        resolved = _resolve_runtime_symbol(sym)
        if resolved is not None:
            ns[sym] = resolved

    if "spark" not in ns:
        raise NameError(
            "name 'spark' is not defined. This package must be run inside a Fabric/Synapse "
            "Spark notebook/session where a SparkSession is available as `spark`."
        )

    # Guardrail: ensure we are not accidentally running against a local Spark.
    try:
        master = str(ns["spark"].sparkContext.master)
        logger.info("Using Spark master: %s", master)
        if "local" in master.lower():
            raise RuntimeError(
                f"Spark master is '{master}', which looks like local mode. "
                "This package is expected to run on a cluster (e.g., YARN-backed Synapse/Fabric Spark)."
            )
    except Exception:
        # If we can't introspect master, don't block execution.
        pass

    # Ensure workers have the package installed before any applyInPandas UDF
    # is dispatched.  cloudpickle serialises references to module-level
    # functions by name, so workers must be able to import this module.
    _bootstrap_workers(ns["spark"].sparkContext)

    for cell_number, cell_code in NOTEBOOK_CODE_CELLS:
        try:
            exec(cell_code, ns, ns)
        except Exception:
            logger.exception("Notebook Cell %s failed", cell_number)
            raise

        # Ensure runtime parameters win over the notebook's parameter cell.
        ns["kustoUri"] = kusto_uri
        ns["database"] = database
        ns["CHUNK_SIZE"] = chunk_size

        # Install wrapper as soon as the function exists.
        _install_generate_wrapper(ns)

        # Wrap Kusto writer as soon as it exists (so cell 9 writes are formatted).
        _install_write_kusto_wrapper(ns)


# ------------------------------
# Example stub rule (NOT enabled)
# ------------------------------

def example_stub_rule(ns: dict[str, Any], base_recommendations: Any) -> Any | None:
    """Example: add a custom recommendation.

    This stub returns `None` so it does not change results.

    To enable a rule, register it before calling `run()`:

        from spark_monitoring_analyzer.analyzer import register_recommendation_rule, run
        register_recommendation_rule(example_stub_rule)
        run(kusto_uri=..., database=...)
    """

    return None


# ------------------------------
# Notebook cells (verbatim)
# ------------------------------

NOTEBOOK_CODE_CELLS: list[tuple[int, str]] = [
    # ===== Notebook Cell 1: runtime parameters (injected by run()) =====
    # kustoUri and database are injected into the exec namespace by run() before
    # any cell executes, and re-asserted after every cell.  This cell is a no-op.
    (1, r'''# kustoUri and database are supplied by run(kusto_uri=..., database=...).'''),
    # ===== Notebook Cell 2: runtime parameters (injected by run()) =====
    # Same as cell 1 — run() overwrites any assignment here immediately after exec().
    (2, r'''# kustoUri and database are supplied by run(kusto_uri=..., database=...).'''),
    # ===== Notebook Cell 3: # === Helper Functions for Event Processing === =====
    (3, r'''# === Helper Functions for Event Processing ===

from typing import Dict, Any, List
import json
import numpy as np

def _safe_get(dct: Any, path: List[str], default=None):
    """Safely navigate nested dictionaries"""
    cur = dct
    for p in path:
        if not isinstance(cur, dict) or p not in cur:
            return default
        cur = cur[p]
    return cur

def _parse_record(rec_str: str) -> Dict[str, Any]:
    """Parse JSON record string"""
    try:
        return json.loads(rec_str) if rec_str else {}
    except Exception:
        return {}

def _to_float(x, default=0.0):
    """Convert to float safely"""
    try:
        if x is None:
            return float(default)
        return float(x)
    except Exception:
        return float(default)

def _to_int(x, default=0):
    """Convert to int safely"""
    try:
        if x is None:
            return int(default)
        return int(x)
    except Exception:
        return int(default)

print("✅ Helper functions loaded successfully")'''),
    # ===== Notebook Cell 4: # === ML-Enhanced Imports for Production-Grade Analysis === =====
    (4, r'''# === ML-Enhanced Imports for Production-Grade Analysis ===
from sklearn.cluster import KMeans as SKKMeans
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler as SKScaler
from sklearn.metrics import silhouette_score
import warnings
warnings.filterwarnings('ignore')

print("✅ ML-enhanced imports loaded successfully")'''),
    # ===== Notebook Cell 5: runtime parameters placeholder =====
    # No-op. kustoUri and database are controlled entirely by run().
    (5, r'''# kustoUri and database are supplied by run(kusto_uri=..., database=...).'''),
    # ===== Notebook Cell 6: # === Advanced Spark Performance Recommender with ML Analytics (Helpers + Schemas) === =====
    (6, r'''# === Advanced Spark Performance Recommender with ML Analytics (Helpers + Schemas) ===

from pyspark.sql import SparkSession, Window, Row, DataFrame
from pyspark.sql.functions import (
    col, lit, count, countDistinct, avg, expr, percentile_approx, stddev,
    min as spark_min, max as spark_max, sum as spark_sum,
    when, from_json, get_json_object
)
import pyspark.sql.functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, DoubleType, LongType, BooleanType
)

import pandas as pd
import numpy as np
import math
import traceback
from typing import Dict, Any, Optional, List

from pyspark.ml.feature import VectorAssembler, StandardScaler
from pyspark.ml.clustering import KMeans
from pyspark.ml.stat import Correlation

# Enhanced ML imports for production-grade analysis
from sklearn.cluster import KMeans as SKKMeans
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler as SKScaler
from sklearn.metrics import silhouette_score
import warnings
warnings.filterwarnings('ignore')

# ==============================
# CONSTANTS
# ==============================

# Default executor cores — Fabric standard node is 8 vCores per executor.
# Matches per_app_analyzer default — eliminates chunk-size mismatch between pipeline stages.
DEFAULT_EXECUTOR_CORES = 8

# Driver overhead fractions for heuristic calculations
DRIVER_ACTIVE_TIME_FRACTION = 0.10      # 10% of app duration for driver active time
DRIVER_COORDINATION_TIME_FRACTION = 0.05 # 5% of app duration for coordination overhead

# Workload characterization thresholds
SKEW_THRESHOLD = 0.5           # Coefficient of variation threshold for skewed workloads
IO_BOUND_THRESHOLD = 100.0     # MB/sec threshold for IO-bound workloads  
COMPUTE_BOUND_THRESHOLD = 10.0 # MB/sec threshold for compute-bound workloads

# Performance optimization constants
DEFAULT_PARALLELISM_SCORE = 0.5  # Default when no metrics available
MIN_EXECUTOR_COUNT = 1           # Minimum executor count fallback

# ==============================
# KUSTO DATABASE SCHEMA DEFINITIONS
# ==============================

METADATA_SCHEMA = StructType([
    StructField("applicationId", StringType(), True),
    StructField("applicationName", StringType(), True),
    StructField("artifactId", StringType(), True),
    StructField("artifactType", StringType(), True),
    StructField("capacityId", StringType(), True),
    StructField("executorMax", LongType(), True),
    StructField("executorMin", LongType(), True),
    StructField("fabricEnvId", StringType(), True),
    StructField("fabricLivyId", StringType(), True),
    StructField("fabricTenantId", StringType(), True),
    StructField("fabricWorkspaceId", StringType(), True),
    StructField("isHighConcurrencyEnabled", BooleanType(), True),
    StructField("spark.native.enabled", StringType(), True),
    StructField("spark.databricks.delta.autoCompact.enabled", StringType(), True),
    StructField("spark.microsoft.delta.targetFileSize.adaptive.enabled", StringType(), True),
    StructField("spark.microsoft.delta.optimize.fast.enabled", StringType(), True),
    StructField("spark.microsoft.delta.optimize.fileLevelTarget.enabled", StringType(), True),
    StructField("spark.microsoft.delta.stats.collect.extended", StringType(), True),
    StructField("spark.microsoft.delta.snapshot.driverMode.enabled", StringType(), True),
    StructField("spark.sql.parquet.vorder.default", StringType(), True),
    StructField("spark.microsoft.delta.optimizeWrite.enabled", StringType(), True),
    # Some Fabric/Spark runtimes still emit Delta optimizeWrite under Databricks-namespaced keys.
    # Keep these for recommendation logic, but drop them before writing to the existing Kusto table
    # to avoid schema mismatch in environments where sparklens_metadata doesn't have these columns.
    StructField("spark.databricks.delta.optimizeWrite.enabled", StringType(), True),
    StructField("spark.databricks.delta.optimizeWrite.partitioned.enabled", StringType(), True),
    StructField("spark.fabric.resourceProfile", StringType(), True),
])

METRICS_SCHEMA = StructType([
    StructField("app_id", StringType(), True),
    StructField("metric", StringType(), True),
    StructField("value", DoubleType(), True)
])

# Updated SUMMARY_SCHEMA to match actual sparklens_summary table structure
# Counter fields use LongType to match Kusto System.Int64; Int32 overflows on large event logs.
SUMMARY_SCHEMA = StructType([
    StructField("stage_id", LongType(), True),
    StructField("stage_attempt_id", LongType(), True),
    StructField("num_tasks", LongType(), True),
    StructField("successful_tasks", LongType(), True),
    StructField("failed_tasks", LongType(), True),
    StructField("min_duration_sec", DoubleType(), True),
    StructField("max_duration_sec", DoubleType(), True),
    StructField("avg_duration_sec", DoubleType(), True),
    StructField("p75_duration_sec", DoubleType(), True),
    StructField("avg_shuffle_read_mb", DoubleType(), True),
    StructField("max_shuffle_read_mb", DoubleType(), True),
    StructField("avg_shuffle_read_records", DoubleType(), True),
    StructField("max_shuffle_read_records", LongType(), True),
    StructField("avg_shuffle_write_mb", DoubleType(), True),
    StructField("max_shuffle_write_mb", DoubleType(), True),
    StructField("avg_shuffle_write_records", DoubleType(), True),
    StructField("max_shuffle_write_records", LongType(), True),
    StructField("avg_input_mb", DoubleType(), True),
    StructField("max_input_mb", DoubleType(), True),
    StructField("avg_input_records", DoubleType(), True),
    StructField("max_input_records", LongType(), True),
    StructField("avg_output_mb", DoubleType(), True),
    StructField("max_output_mb", DoubleType(), True),
    StructField("avg_output_records", DoubleType(), True),
    StructField("max_output_records", LongType(), True),
    StructField("min_launch_time", LongType(), True),     # Epoch milliseconds overflow Int32; LongType required.
    StructField("max_finish_time", LongType(), True),
    StructField("num_executors", LongType(), True),
    StructField("stage_execution_time_sec", DoubleType(), True),
    StructField("app_id", StringType(), True)
])

# Updated PREDICTIONS_SCHEMA to match actual sparklens_predictions table (5 columns only)
# Kusto column is System.Int64 — must be LongType, not IntegerType.
# Column names with spaces match the actual table definition exactly.
PREDICTIONS_SCHEMA = StructType([
    StructField("Executor Count", LongType(), True),           # Int64 in Kusto
    StructField("Executor Multiplier", StringType(), True),
    StructField("Estimated Executor WallClock", StringType(), True),
    StructField("Estimated Total Duration", StringType(), True),
    StructField("app_id", StringType(), True)
])

RECOMMENDATIONS_SCHEMA = StructType([
    StructField("app_id", StringType(), True),
    StructField("recommendation", StringType(), True)
])

print("📋 Kusto database schemas loaded successfully!")

# ==============================
# UTILITY FUNCTIONS
# ==============================

def get_executor_cores_config() -> int:
    """
    Get executor cores from Spark configuration with fallback to default.
    
    Returns:
        int: Number of executor cores per executor
    """
    try:
        return int(spark.conf.get("spark.executor.cores", str(DEFAULT_EXECUTOR_CORES)))
    except (ValueError, TypeError, AttributeError):
        return DEFAULT_EXECUTOR_CORES

def safe_unpersist_dataframe(df: Optional[DataFrame], df_name: str = "DataFrame") -> None:
    """
    Safely unpersist a DataFrame with error handling.
    
    Args:
        df: DataFrame to unpersist (can be None)
        df_name: Name for logging purposes
    """
    try:
        if df is not None:
            df.unpersist()
            print(f"🧹 Unpersisted {df_name}")
    except Exception as e:
        print(f"⚠️ Warning: Could not unpersist {df_name}: {e}")

def safe_float_conversion(value: Any, default: float = 0.0) -> float:
    """
    Safely convert value to float with fallback.
    
    Args:
        value: Value to convert
        default: Default value if conversion fails
        
    Returns:
        float: Converted value or default
    """
    try:
        return float(value) if value is not None else default
    except (ValueError, TypeError):
        return default

def safe_int_conversion(value: Any, default: int = 0) -> int:
    """
    Safely convert value to int with fallback.
    
    Args:
        value: Value to convert  
        default: Default value if conversion fails
        
    Returns:
        int: Converted value or default
    """
    try:
        return int(value) if value is not None else default
    except (ValueError, TypeError):
        return default

# ==============================
# CORE ANALYSIS FUNCTIONS
# ==============================

def compute_application_runtime(event_log_df: DataFrame) -> float:
    """
    Compute application runtime from start/end events (seconds).
    
    Args:
        event_log_df: DataFrame containing Spark event logs
        
    Returns:
        float: Application runtime in seconds
    """
    try:
        # Optimized: Get both start and end times in single query
        app_events = (
            event_log_df.filter(
                col("properties.Event").isin(["SparkListenerApplicationStart", "SparkListenerApplicationEnd"])
            )
            .select(
                col("properties.Event").alias("event_type"),
                col("properties.Timestamp").alias("timestamp")
            )
            .collect()
        )
        
        start_time = None
        end_time = None
        
        for row in app_events:
            if row["event_type"] == "SparkListenerApplicationStart":
                start_time = safe_float_conversion(row["timestamp"])
            elif row["event_type"] == "SparkListenerApplicationEnd":
                end_time = safe_float_conversion(row["timestamp"])

        if start_time and end_time and start_time > 0 and end_time > 0:
            return max(0.0, (end_time - start_time) / 1000.0)

        # Fallback: first/last timestamp in events  
        times = (
            event_log_df.select(col("properties.Timestamp").alias("ts"))
            .agg(
                spark_min("ts").alias("min_time"),
                spark_max("ts").alias("max_time")
            )
            .collect()[0]
        )
        
        min_time = safe_float_conversion(times["min_time"])
        max_time = safe_float_conversion(times["max_time"])
        
        if min_time > 0 and max_time > 0:
            return max(0.0, (max_time - min_time) / 1000.0)

        return 0.0

    except Exception as e:
        print(f"⚠️ Error computing application runtime: {e}")
        return 0.0

def compute_accurate_driver_metrics(event_log_df: DataFrame) -> Dict[str, float]:
    """
    Heuristic driver metrics derived from app duration.
    
    Args:
        event_log_df: DataFrame containing Spark event logs
        
    Returns:
        Dict[str, float]: Driver metrics dictionary
    """
    try:
        app_duration = compute_application_runtime(event_log_df)
        if app_duration <= 0:
            return {"driver_active_time_sec": 0.0, "driver_coordination_time_sec": 0.0}

        # Use predefined constants for heuristic calculations
        return {
            "driver_active_time_sec": app_duration * DRIVER_ACTIVE_TIME_FRACTION,
            "driver_coordination_time_sec": app_duration * DRIVER_COORDINATION_TIME_FRACTION
        }
    except Exception as e:
        print(f"⚠️ Error computing driver metrics: {e}")
        return {"driver_active_time_sec": 0.0, "driver_coordination_time_sec": 0.0}

def compute_advanced_executor_metrics(event_log_df: DataFrame) -> Dict[str, float]:
    """
    Compute executor metrics from SparkListenerTaskEnd events with proper cache management.
    
    Args:
        event_log_df: DataFrame containing Spark event logs
        
    Returns:
        Dict[str, float]: Executor metrics dictionary
    """
    task_end_df = None
    task_metrics = None
    
    try:
        task_end_df = event_log_df.filter(col("properties.Event") == "SparkListenerTaskEnd").cache()
        
        if task_end_df.limit(1).count() == 0:
            return {
                "executor_efficiency": 0.0,
                "parallelism_score": 0.0,
                "resource_utilization": 0.0,
                "gc_overhead": 0.0,
                "total_executor_time_sec": 0.0,
                "executor_count": 0
            }

        task_metrics = (
            task_end_df.select(
                (col("properties.Task Metrics.Executor Run Time") / 1000.0).alias("exec_time_sec"),
                (col("properties.Task Metrics.Executor CPU Time") / 1000000.0).alias("cpu_time_sec"), 
                col("properties.Task Metrics.JVM GC Time").alias("gc_time_ms"),
                col("properties.Task Info.Executor ID").alias("executor_id")
            )
            .filter(col("exec_time_sec") > 0)
            .cache()
        )

        if task_metrics.limit(1).count() == 0:
            return {
                "executor_efficiency": 0.0,
                "parallelism_score": DEFAULT_PARALLELISM_SCORE,
                "resource_utilization": 0.0,
                "gc_overhead": 0.0,
                "total_executor_time_sec": 0.0,
                "executor_count": MIN_EXECUTOR_COUNT
            }

        agg = task_metrics.agg(
            spark_sum("exec_time_sec").alias("total_exec_time"),
            spark_sum("cpu_time_sec").alias("total_cpu_time"),
            spark_sum("gc_time_ms").alias("total_gc_time"),
            countDistinct("executor_id").alias("executor_count"),
            count("*").alias("task_count")
        ).collect()[0]

        # Use safe conversion functions
        total_exec_time = safe_float_conversion(agg["total_exec_time"])
        total_cpu_time = safe_float_conversion(agg["total_cpu_time"]) 
        total_gc_time = safe_float_conversion(agg["total_gc_time"])
        executor_count = safe_int_conversion(agg["executor_count"], MIN_EXECUTOR_COUNT)
        task_count = safe_int_conversion(agg["task_count"], 1)

        # Get executor cores with proper fallback
        executor_cores_per_executor = get_executor_cores_config()
        
        # Calculate metrics with safe division
        executor_efficiency = (total_cpu_time / total_exec_time) if total_exec_time > 0 else 0.0
        gc_overhead = ((total_gc_time / 1000.0) / total_exec_time) if total_exec_time > 0 else 0.0
        parallelism_score = min(1.0, task_count / max(1, executor_count * executor_cores_per_executor))
        resource_utilization = min(1.0, executor_efficiency * (1.0 - gc_overhead))

        return {
            "executor_efficiency": max(0.0, min(1.0, executor_efficiency)),
            "parallelism_score": max(0.0, min(1.0, parallelism_score)),
            "resource_utilization": max(0.0, min(1.0, resource_utilization)),
            "gc_overhead": max(0.0, min(1.0, gc_overhead)),
            "total_executor_time_sec": total_exec_time,
            "executor_count": executor_count
        }

    except Exception as e:
        print(f"⚠️ Error computing executor metrics: {e}")
        return {
            "executor_efficiency": 0.0,
            "parallelism_score": DEFAULT_PARALLELISM_SCORE,
            "resource_utilization": 0.0,
            "gc_overhead": 0.0,
            "total_executor_time_sec": 0.0,
            "executor_count": MIN_EXECUTOR_COUNT
        }
    finally:
        # Proper cache cleanup
        safe_unpersist_dataframe(task_end_df, "task_end_df")
        safe_unpersist_dataframe(task_metrics, "task_metrics")

def analyze_workload_characteristics(event_log_df: DataFrame, task_metrics_df: DataFrame) -> Dict[str, Any]:
    """
    Simple workload characterization using skew + IO ratio with proper cache management.
    
    Args:
        event_log_df: DataFrame containing Spark event logs
        task_metrics_df: DataFrame containing task metrics
        
    Returns:
        Dict[str, Any]: Workload characteristics
    """
    try:
        if task_metrics_df.limit(1).count() == 0:
            return {"workload_type": "unknown", "coefficient_of_variation": 0.0, "io_compute_ratio": 0.0}

        stats = task_metrics_df.agg(
            avg("executor_run_time_sec").alias("avg_duration"),
            stddev("executor_run_time_sec").alias("stddev_duration"),
            spark_sum("input_mb").alias("total_input"),
            spark_sum("output_mb").alias("total_output"),
            spark_sum("shuffle_read_mb").alias("total_shuffle_read"),
            spark_sum("shuffle_write_mb").alias("total_shuffle_write")
        ).collect()[0]

        # Use safe conversions
        avg_d = safe_float_conversion(stats["avg_duration"])
        std_d = safe_float_conversion(stats["stddev_duration"])
        total_io = (safe_float_conversion(stats["total_input"]) + 
                   safe_float_conversion(stats["total_output"]) +
                   safe_float_conversion(stats["total_shuffle_read"]) + 
                   safe_float_conversion(stats["total_shuffle_write"]))

        # Calculate coefficients
        cov = (std_d / avg_d) if avg_d > 0 else 0.0
        app_duration = compute_application_runtime(event_log_df)
        io_compute_ratio = (total_io / max(1.0, app_duration)) if app_duration > 0 else 0.0

        # Use predefined thresholds
        if cov > SKEW_THRESHOLD:
            workload_type = "skewed"
        elif io_compute_ratio > IO_BOUND_THRESHOLD:
            workload_type = "io_bound"
        elif io_compute_ratio < COMPUTE_BOUND_THRESHOLD:
            workload_type = "compute_bound"
        else:
            workload_type = "balanced"

        return {
            "workload_type": workload_type, 
            "coefficient_of_variation": cov, 
            "io_compute_ratio": io_compute_ratio
        }

    except Exception as e:
        print(f"⚠️ Error analyzing workload characteristics: {e}")
        return {"workload_type": "unknown", "coefficient_of_variation": 0.0, "io_compute_ratio": 0.0}

# ==============================
# FALLBACK DATAFRAME CREATORS  
# ==============================

def create_fallback_summary(app_id: str) -> DataFrame:
    """Create fallback summary DataFrame with proper schema alignment."""
    rows = [Row(
        stage_id=0,
        stage_attempt_id=0,
        num_tasks=0,
        successful_tasks=0,
        failed_tasks=0,
        min_duration_sec=0.0,
        max_duration_sec=0.0,
        avg_duration_sec=0.0,
        p75_duration_sec=0.0,
        avg_shuffle_read_mb=0.0,
        max_shuffle_read_mb=0.0,
        avg_shuffle_read_records=0.0,
        max_shuffle_read_records=0,
        avg_shuffle_write_mb=0.0,
        max_shuffle_write_mb=0.0,
        avg_shuffle_write_records=0.0,
        max_shuffle_write_records=0,
        avg_input_mb=0.0,
        max_input_mb=0.0,
        avg_input_records=0.0,
        max_input_records=0,
        avg_output_mb=0.0,
        max_output_mb=0.0,
        avg_output_records=0.0,
        max_output_records=0,
        min_launch_time=0,
        max_finish_time=0,
        num_executors=0,
        stage_execution_time_sec=0.0,
        app_id=str(app_id)
    )]
    return spark.createDataFrame(rows, schema=SUMMARY_SCHEMA)

def create_fallback_metrics(app_id: str) -> DataFrame:
    """Create fallback metrics DataFrame."""
    rows = [
        Row(app_id=str(app_id), metric="Application Duration (sec)", value=0.0),
        Row(app_id=str(app_id), metric="Analysis Type", value=0.0),
        Row(app_id=str(app_id), metric="Driver Active Time (sec)", value=0.0),
        Row(app_id=str(app_id), metric="Executor Efficiency", value=0.0),
        Row(app_id=str(app_id), metric="Parallelism Score", value=0.0),
        Row(app_id=str(app_id), metric="Resource Utilization", value=0.0),
        Row(app_id=str(app_id), metric="GC Overhead", value=0.0),
        Row(app_id=str(app_id), metric="Total Executor Time (sec)", value=0.0),
        Row(app_id=str(app_id), metric="Executor Count", value=0.0)
    ]
    return spark.createDataFrame(rows, schema=METRICS_SCHEMA)

def create_fallback_recommendations(app_id: str) -> DataFrame:
    """Create fallback recommendations DataFrame."""
    msgs = [
        "⚠️ ANALYSIS TYPE 0: No SparkListenerApplicationStart event detected.",
        "🔍 LIKELY CAUSES: Spark session created but no jobs executed, or application failed during initialization.",
        "💡 RECOMMENDATIONS: Check application logs for initialization errors or ensure Spark operations are actually executed.",
        "🔧 TROUBLESHOOTING: Verify SparkSession is used for data operations (not just imports/setup code)."
    ]
    rows = [Row(app_id=str(app_id), recommendation=str(msg)) for msg in msgs]
    return spark.createDataFrame(rows, schema=RECOMMENDATIONS_SCHEMA)

print("🔧 All enhanced helper functions loaded successfully with proper cache management!")'''),
    # ===== Notebook Cell 7: # === Cell 2: Enhanced Main Analysis Function (Advanced + Fallback) === =====
    (7, r'''# === Cell 2: Enhanced Main Analysis Function (Advanced + Fallback) ===

from pyspark.sql import Row
from pyspark.sql.functions import col, lit, count, countDistinct, avg, expr, stddev
import pyspark.sql.functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType

def compute_advanced_stage_task_summary(event_log_df, metadata_df, app_id):
    """Advanced Spark performance analysis with ML-based insights.

    .. deprecated::
        This function is NOT the production path.  Cell 9's ``per_app_analyzer``
        (via ``applyInPandas`` in the chunk loop) is the sole production code path.

        This function's ``final_summary_df`` only writes 4 columns
        (``app_id``, ``stage_id``, ``analysis_type``, ``message``) which is
        incompatible with the 30-column ``SUMMARY_SCHEMA``.  Schema enforcement
        will fail if this function is invoked and its output is written to Kusto.
        This function is permanently disabled. Use per_app_analyzer() via the chunk loop instead.

    Returns: (summary_df, metrics_df, predictions_df, recommendations_df)
    """
    logger.warning(
        "compute_advanced_stage_task_summary() is deprecated and schema-incompatible. "
        "Its summary output writes only 4 of 30 SUMMARY_SCHEMA columns and will fail "
        "on schema enforcement. Use Cell 9 per_app_analyzer() via the chunk loop instead."
    )
    raise NotImplementedError(  # Hard-stop: prevents schema-incompatible data from reaching Kusto.
        "compute_advanced_stage_task_summary() is schema-incompatible and permanently disabled. "
        "Use Cell 9 per_app_analyzer() instead."
    )

def generate_enhanced_recommendations(app_id, app_duration_sec, driver_metrics, executor_metrics, workload_analysis, metadata_df, task_df):
    """
    Generate enhanced recommendations. Output schema matches RECOMMENDATIONS_SCHEMA.
    """
    print("🎯 Generating enhanced performance recommendations...")
    recs = []
    try:
        driver_time = float(driver_metrics.get("driver_active_time_sec", 0.0))
        executor_efficiency = float(executor_metrics.get("executor_efficiency", 0.0))
        parallelism_score = float(executor_metrics.get("parallelism_score", 0.0))
        gc_overhead = float(executor_metrics.get("gc_overhead", 0.0))
        driver_ratio = (driver_time / app_duration_sec) if app_duration_sec > 0 else 0.0

        if executor_efficiency < 0.3:
            recs.append(f"🚨 CRITICAL: Very low executor CPU efficiency ({executor_efficiency:.1%}). OPTIMIZE CODE BEFORE SCALING.")
            recs.append("💡 ACTION: Profile code, reduce serialization/object churn, improve algorithms.")
        if gc_overhead > 0.2:
            recs.append(f"🚨 CRITICAL: High GC overhead ({gc_overhead:.1%}). Increase memory / reduce allocation pressure.")
            recs.append("💡 ACTION: Increase spark.executor.memory, tune GC, reduce object lifetime.")
        if driver_ratio > 0.4:
            recs.append(f"🚨 CRITICAL: Driver bottleneck ({driver_ratio:.1%} of runtime). Scaling executors won't help much.")
            recs.append("💡 ACTION: Avoid collect()/take() on large data; reduce driver-side work.")

        if driver_ratio <= 0.4:
            if parallelism_score < 0.4:
                recs.append(f"⚖️ SCALING OPPORTUNITY: Low parallelism ({parallelism_score:.1%}). Increase partitions before adding executors.")
            elif executor_efficiency > 0.6 and parallelism_score > 0.6:
                recs.append(f"🚀 GOOD SCALING CANDIDATE: High efficiency ({executor_efficiency:.1%}) and parallelism ({parallelism_score:.1%}).")

        workload_type = workload_analysis.get("workload_type", "unknown")
        if workload_type == "io_bound":
            recs.append("📁 IO-BOUND: Focus on storage/format/caching; scaling may have limited benefit.")
        elif workload_type == "compute_bound":
            recs.append("💻 COMPUTE-BOUND: Scaling executors/cores likely helps if efficiency remains good.")
        elif workload_type == "skewed":
            recs.append("📊 SKEW: Fix skew (salting/custom partitioning/AQE) before scaling.")

        overall_score = (executor_efficiency + parallelism_score + (1.0 - gc_overhead)) / 3.0
        if overall_score > 0.75:
            recs.append("⭐ EXCELLENT: Well-optimized; scaling is a reasonable lever.")
        elif overall_score > 0.5:
            recs.append("✅ GOOD: Mix of code tuning + careful scaling.")
        else:
            recs.append("⚠️ NEEDS IMPROVEMENT: Optimize code/data layout before scaling.")

        if driver_ratio < 0.3 and parallelism_score > 0.4 and executor_efficiency > 0.5:
            recs.append("🎯 SCALING VERDICT: ✅ Good candidate for executor scaling.")
        else:
            recs.append("🎯 SCALING VERDICT: ❌ Optimize before scaling executors.")

    except Exception as e:
        print(f"⚠️ Enhanced recommendation generation error: {str(e)}")
        recs = ["Unable to generate detailed recommendations due to insufficient event data."]

    rows = [Row(app_id=str(app_id), recommendation=str(r)) for r in (recs or ["No recommendations."])]
    return spark.createDataFrame(rows, schema=RECOMMENDATIONS_SCHEMA)

def detect_application_type(event_log_df):
    """
    Detect application type based on presence of Spark events.
    """
    print("🔍 Detecting application type and analyzing available events...")
    try:
        spark_events = [
            "SparkListenerApplicationStart",
            "SparkListenerApplicationEnd",
            "SparkListenerJobStart",
            "SparkListenerJobEnd",
            "SparkListenerStageSubmitted",
            "SparkListenerStageCompleted",
            "SparkListenerTaskStart",
            "SparkListenerTaskEnd",
            "SparkListenerExecutorAdded",
            "SparkListenerExecutorRemoved",
        ]

        total_events = event_log_df.count()
        event_counts = {}
        for ev in spark_events:
            c = event_log_df.filter(col("properties.Event") == ev).count()
            if c > 0:
                event_counts[ev] = c

        has_app_events = "SparkListenerApplicationStart" in event_counts
        has_job_events = "SparkListenerJobStart" in event_counts
        has_task_events = "SparkListenerTaskEnd" in event_counts

        if not has_app_events:
            return {
                "app_type": "Non-Spark Application",
                "analysis_type": -1,
                "analysis_capability": "No Spark events detected",
                "total_events": total_events,
                "event_counts": event_counts,
                "has_job_execution": has_job_events,
                "has_task_execution": has_task_events
            }
        if not has_job_events:
            return {
                "app_type": "Spark Context Only",
                "analysis_type": 0,
                "analysis_capability": "Spark session created but no jobs executed",
                "total_events": total_events,
                "event_counts": event_counts,
                "has_job_execution": has_job_events,
                "has_task_execution": has_task_events
            }
        if not has_task_events:
            return {
                "app_type": "Spark Jobs Without Tasks",
                "analysis_type": 0,
                "analysis_capability": "Jobs submitted but no task completion events",
                "total_events": total_events,
                "event_counts": event_counts,
                "has_job_execution": has_job_events,
                "has_task_execution": has_task_events
            }

        task_end_count = int(event_counts.get("SparkListenerTaskEnd", 0))
        if task_end_count < 10:
            return {
                "app_type": "Minimal Spark Execution",
                "analysis_type": 1,
                "analysis_capability": f"Only {task_end_count} tasks completed - limited analysis",
                "total_events": total_events,
                "event_counts": event_counts,
                "has_job_execution": has_job_events,
                "has_task_execution": has_task_events
            }

        return {
            "app_type": "Full Spark Application",
            "analysis_type": 2,
            "analysis_capability": f"Complete Spark execution with {task_end_count} tasks - full analysis",
            "total_events": total_events,
            "event_counts": event_counts,
            "has_job_execution": has_job_events,
            "has_task_execution": has_task_events
        }

    except Exception as e:
        print(f"⚠️ Application type detection error: {str(e)}")
        return {
            "app_type": "Unknown",
            "analysis_type": -2,
            "analysis_capability": "Detection error",
            "total_events": 0,
            "event_counts": {},
            "error": str(e)
        }

def compute_enhanced_basic_analysis_fallback(event_log_df, metadata_df, app_id):
    """
    Fallback analysis for missing/limited events.
    Returns: (summary_df, metrics_df, predictions_df, recommendations_df)
    """
    print("📊 Performing enhanced basic analysis with application type detection...")

    app_duration_sec = compute_application_runtime(event_log_df)
    det = detect_application_type(event_log_df)

    analysis_type = float(det.get("analysis_type", 0))
    app_type = det.get("app_type", "Unknown")
    capability = det.get("analysis_capability", "Limited analysis")

    # Zero-value Row matching all 30 SUMMARY_SCHEMA fields (LongType counters
    # must be int, not string).  Mirrors create_fallback_summary() exactly.
    summary_rows = [Row(
        stage_id=0,
        stage_attempt_id=0,
        num_tasks=0,
        successful_tasks=0,
        failed_tasks=0,
        min_duration_sec=0.0,
        max_duration_sec=0.0,
        avg_duration_sec=0.0,
        p75_duration_sec=0.0,
        avg_shuffle_read_mb=0.0,
        max_shuffle_read_mb=0.0,
        avg_shuffle_read_records=0.0,
        max_shuffle_read_records=0,
        avg_shuffle_write_mb=0.0,
        max_shuffle_write_mb=0.0,
        avg_shuffle_write_records=0.0,
        max_shuffle_write_records=0,
        avg_input_mb=0.0,
        max_input_mb=0.0,
        avg_input_records=0.0,
        max_input_records=0,
        avg_output_mb=0.0,
        max_output_mb=0.0,
        avg_output_records=0.0,
        max_output_records=0,
        min_launch_time=0,
        max_finish_time=0,
        num_executors=0,
        stage_execution_time_sec=0.0,
        app_id=str(app_id)
    )]
    summary_df = spark.createDataFrame(summary_rows, schema=SUMMARY_SCHEMA)

    metrics_rows = [
        Row(app_id=str(app_id), metric="Application Duration (sec)", value=float(app_duration_sec)),
        Row(app_id=str(app_id), metric="Analysis Type", value=float(analysis_type)),
        Row(app_id=str(app_id), metric="Total Events", value=float(det.get("total_events", 0))),
        Row(app_id=str(app_id), metric="Task Events", value=float(det.get("event_counts", {}).get("SparkListenerTaskEnd", 0))),
        Row(app_id=str(app_id), metric="Job Events", value=float(det.get("event_counts", {}).get("SparkListenerJobStart", 0))),
        Row(app_id=str(app_id), metric="Stage Events", value=float(det.get("event_counts", {}).get("SparkListenerStageCompleted", 0))),
    ]
    metrics_df = spark.createDataFrame(metrics_rows, schema=METRICS_SCHEMA)

    # Field names match the 5-column PREDICTIONS_SCHEMA exactly.
    predictions_rows = [Row(**{
        "Executor Count": int(1),
        "Executor Multiplier": "Current",
        "Estimated Executor WallClock": f"{int(app_duration_sec // 60)}m {int(app_duration_sec % 60)}s",
        "Estimated Total Duration": f"{int(app_duration_sec // 60)}m {int(app_duration_sec % 60)}s",
        "app_id": str(app_id),
    })]
    predictions_df = spark.createDataFrame(predictions_rows, schema=PREDICTIONS_SCHEMA)

    if analysis_type == -1:
        rec_msgs = [
            "🔍 NON-SPARK APPLICATION: No Spark events detected.",
            "💡 RECOMMENDATION: No Spark performance optimization needed."
        ]
    elif analysis_type == 0 and not det.get("has_job_execution", False):
        rec_msgs = [
            "⚙️ SPARK CONTEXT ONLY: Spark session created but no jobs executed.",
            "💡 RECOMMENDATION: Ensure Spark actions are triggered (e.g., write/count/show) and not only lazy transforms."
        ]
    elif analysis_type == 0:
        rec_msgs = [
            "⚠️ JOBS WITHOUT TASKS: Jobs submitted but no task completion events.",
            "💡 RECOMMENDATION: Check for failures, resource constraints, or premature termination."
        ]
    elif analysis_type == 1:
        tcnt = det.get("event_counts", {}).get("SparkListenerTaskEnd", 0)
        rec_msgs = [
            f"📊 MINIMAL EXECUTION: Only {tcnt} tasks completed - limited performance analysis.",
            "💡 RECOMMENDATION: Run larger workloads to generate richer event logs for analysis."
        ]
    else:
        rec_msgs = ["📊 Basic analysis completed. Enable richer event logging for deeper insights."]

    rec_rows = [Row(app_id=str(app_id), recommendation=str(m)) for m in rec_msgs]
    rec_df = spark.createDataFrame(rec_rows, schema=RECOMMENDATIONS_SCHEMA)

    print("🎯 Enhanced basic analysis completed.")
    return summary_df, metrics_df, predictions_df, rec_df

print("🎯 Enhanced performance analysis functions loaded successfully!")'''),
    # ===== Notebook Cell 8: # === Cell 3: Metadata extraction (safe) === =====
    (8, r'''# === Cell 3: Metadata extraction (safe) ===

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit

# Global variable for executor cores configuration
global_executor_cores = None

def get_executor_cores_config():
    """
    Get executor cores configuration with proper fallback.
    This function works in both regular and distributed execution contexts.
    """
    global global_executor_cores
    return global_executor_cores or DEFAULT_EXECUTOR_CORES

def extract_app_metadata(df: DataFrame) -> DataFrame:
    """
    Extract application metadata with safe native execution engine and executor cores detection
    """
    global global_executor_cores
    
    print("📋 Extracting application metadata...")

    def _first_nonnull(expr: str, alias: str):
        try:
            rows = (
                df.selectExpr(f"{expr} AS {alias}")
                  .filter(col(alias).isNotNull())
                  .distinct()
                  .limit(1)
                  .collect()
            )
            if rows:
                return rows[0][alias]
        except Exception:
            # Best-effort: schema varies by event type.
            pass
        return None

    native_enabled = _first_nonnull("properties.`Spark Properties`.`spark.native.enabled`", "spark_native_enabled")
    if native_enabled is None:
        # Fabric event logs often embed Spark config under a nested `Properties` dict
        # (e.g., SparkListenerJobStart), so fall back to that structure.
        native_enabled = _first_nonnull("properties.`Properties`.`spark.native.enabled`", "spark_native_enabled")

    if native_enabled is not None:
        print(f"✅ Native Execution Engine enabled: {native_enabled}")
    else:
        print("ℹ️ Native Execution Engine setting not found - using default")

    # Extract high concurrency flag from Spark config.
    high_concurrency_val = _first_nonnull(
        "properties.`Spark Properties`.`spark.trident.highconcurrency.enabled`",
        "spark_high_concurrency_enabled",
    )
    if high_concurrency_val is None:
        high_concurrency_val = _first_nonnull(
            "properties.`Properties`.`spark.trident.highconcurrency.enabled`",
            "spark_high_concurrency_enabled",
        )

    high_concurrency_enabled = None
    if high_concurrency_val is not None:
        try:
            if isinstance(high_concurrency_val, bool):
                high_concurrency_enabled = high_concurrency_val
            else:
                high_concurrency_enabled = str(high_concurrency_val).strip().lower() == "true"
        except Exception:
            high_concurrency_enabled = None

    # Extract spark.executor.cores configuration
    executor_cores_val = _first_nonnull("properties.`Spark Properties`.`spark.executor.cores`", "spark_executor_cores")
    if executor_cores_val is None:
        executor_cores_val = _first_nonnull("properties.`Properties`.`spark.executor.cores`", "spark_executor_cores")

    if executor_cores_val is not None:
        try:
            global_executor_cores = int(executor_cores_val)
            print(f"✅ Executor cores extracted from config: {global_executor_cores}")
        except Exception as e:
            print(f"⚠️ Warning: Could not parse executor cores setting: {e}")
            global_executor_cores = 8
    else:
        # Fallback: try to detect from executor info or use reasonable default
        print("ℹ️ spark.executor.cores not found in properties - using fallback logic")
        global_executor_cores = 8  # Default fallback value

    try:
        metadata_df = (
            df.select(
                "applicationId", "applicationName", "artifactId", "artifactType", "capacityId",
                "executorMax", "executorMin", "fabricEnvId", "fabricLivyId", "fabricTenantId",
                "fabricWorkspaceId", "isHighConcurrencyEnabled"
            )
            .distinct()
            .withColumn("spark.native.enabled", lit(native_enabled))
            .withColumn("spark.executor.cores", lit(global_executor_cores))
        )

        if high_concurrency_enabled is not None:
            metadata_df = metadata_df.withColumn("isHighConcurrencyEnabled", lit(bool(high_concurrency_enabled)))

        print("✅ Application metadata extracted successfully")
        return metadata_df

    except Exception as e:
        print(f"❌ Error extracting metadata: {e}")
        return df.select("applicationId").distinct().withColumn("spark.native.enabled", lit(None)).withColumn("spark.executor.cores", lit(global_executor_cores))'''),
    # ===== Notebook Cell 9: Enhanced pipeline =====
    (9, r'''# === Enhanced pipeline ===

import json
from typing import Dict, Any, List

import pandas as pd
import numpy as np

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit, get_json_object, expr
from pyspark.sql.types import (
    StructType, StructField,
    StringType, IntegerType, DoubleType, BooleanType
)

# ----------------------------
# Configuration / Kusto queries
# ----------------------------

# Query: all app IDs that have EventLog data in RawLogs.
# category and applicationId live inside the records JSON field, not as top-level columns.
_ALL_APPS_QUERY = """
RawLogs
| extend _cat = tostring(parse_json(records).category)
| extend _app = tostring(parse_json(records).applicationId)
| where _cat == "EventLog"
| where isnotnull(_app) and _app != ""
| distinct applicationId = _app
"""

# Query: app IDs already written to any output table
_PROCESSED_QUERY = """
union isfuzzy=true
(
    sparklens_errors
    | project applicationID
    | distinct applicationID
),
(
    sparklens_metadata
    | project applicationId
    | distinct applicationID=applicationId
)
"""

# How many apps to pull from Kusto per iteration.
# Tune based on average event-log size per app:
#   < 1 GB/app  → 50  |  1–5 GB/app → 20  |  5–20 GB/app → 5  |  > 20 GB/app → 1-2
# globals() is explicit about scope intent.  In exec(code, ns, ns) both
# globals() and vars() resolve to the same exec-namespace dict, so the behaviour is
# identical.  Using globals() is the idiomatic choice and makes the intent clear when
# the cell is run standalone in a notebook (globals() returns the notebook’s global
# scope where CHUNK_SIZE would be defined if the user set it above).
CHUNK_SIZE = globals().get("CHUNK_SIZE", 20)

# ----------------------------
# NOTE: Schema definitions are imported from Cell 2
# Using METADATA_SCHEMA, SUMMARY_SCHEMA, METRICS_SCHEMA, PREDICTIONS_SCHEMA, RECOMMENDATIONS_SCHEMA
# ----------------------------

# Delegates to the single module-level token cache.
# When both caches approached expiry (e.g. after ~55 min runtime) the driver
# would issue two notebookutils.credentials.getToken() calls in rapid succession.
# Delegating to get_cached_token() in the module namespace eliminates the race.
def get_cached_token():
    """Delegate to the module-level token cache.

    ``kustoUri`` is read from the exec namespace (injected by run(), or defined
    as a module-level variable when the cell is run standalone).
    Delegates to the module-level token cache to avoid duplicate getToken() calls.
    """
    import spark_monitoring_analyzer.analyzer as _sma_mod
    return _sma_mod.get_cached_token(kustoUri)

def read_kusto_df_small(query: str) -> DataFrame:
    """For small/metadata queries: count guards, time-scope, app-ID resolution.
    distributedMode=false forces a direct driver-side REST pull — correct for
    queries returning small result sets (rows of IDs, counts, timestamps).
    """
    return (
        spark.read
        .format("com.microsoft.kusto.spark.synapse.datasource")
        .option("accessToken", get_cached_token())
        .option("kustoCluster", kustoUri)
        .option("kustoDatabase", database)
        .option("kustoQuery", query)
        .option("distributedMode", "false")
        .load()
    )

def read_kusto_df(query: str) -> DataFrame:
    """Pull a KQL query result to the driver via single-thread REST (distributedMode=false).

    Using distributedMode=false on ALL reads avoids the Kusto connector's
    distributed parquet-blob export path (ExecutePluginOperator / 0x80DA0007)
    which fails in Fabric environments.  Raw event rows are collected to the
    driver and immediately re-distributed as a pure in-memory Spark DataFrame
    (no Kusto lineage) before applyInPandas — so per-app analysis still runs
    in parallel on executors.  Driver memory cost is bounded by CHUNK_SIZE
    (normal apps) or 1 app at a time (solo queue).
    """
    return (
        spark.read
        .format("com.microsoft.kusto.spark.synapse.datasource")
        .option("accessToken", get_cached_token())
        .option("kustoCluster", kustoUri)
        .option("kustoDatabase", database)
        .option("kustoQuery", query)
        .option("distributedMode", "false")
        .load()
    )

def write_kusto_df(df: DataFrame, table: str, mode: str = "Append", row_count: int | None = None) -> None:
    if row_count is None:
        row_count = df.count()
    optimized_df = df.coalesce(min(4, max(1, row_count // 1000))) if row_count < 10000 else df
    (
        optimized_df.write
        .format("com.microsoft.kusto.spark.synapse.datasource")
        .option("accessToken", get_cached_token())
        .option("kustoCluster", kustoUri)
        .option("kustoDatabase", database)
        .option("kustoTable", table)
        .option("tableCreateOptions", "CreateIfNotExist")
        .mode(mode)
        .save()
    )

# ----------------------------
# Schema inference with caching
# ----------------------------
_schema_cache = {}

def infer_and_flatten_schema_optimized(event_log_df, schema_key="spark_events"):
    """Optimized schema inference with intelligent caching"""
    global _schema_cache
    if schema_key not in _schema_cache:
        print(f"Inferring schema for {schema_key}...")
        sample_json_df = event_log_df.select("records").limit(100)
        json_rdd = sample_json_df.rdd.map(lambda r: r[0])
        inferred_schema = spark.read.json(json_rdd).schema
        _schema_cache[schema_key] = inferred_schema
        print(f"Schema cached for reuse")
    else:
        print(f"Reusing cached schema for {schema_key}")
    inferred_schema = _schema_cache[schema_key]
    parsed_df = event_log_df.withColumn("records_parsed", F.from_json(F.col("records"), inferred_schema))
    flattened_df = parsed_df.select("*", "records_parsed.*").drop("records_parsed")
    return flattened_df

infer_and_flatten_schema = infer_and_flatten_schema_optimized

# ----------------------------
# Step 1: Resolve unprocessed app IDs — no raw data loaded yet
# ----------------------------
print("="*60)
print("Step 1: Resolving unprocessed application IDs...")
print("="*60)

all_app_ids = [
    str(row["applicationId"])
    for row in read_kusto_df_small(_ALL_APPS_QUERY).collect()
    if row["applicationId"] is not None
]

try:
    _processed_rows = read_kusto_df_small(_PROCESSED_QUERY).collect()
    processed_ids = set(
        str(row["applicationID"])
        for row in _processed_rows
        if row["applicationID"] is not None
    )
except Exception:
    processed_ids = set()

unprocessed_ids = [aid for aid in all_app_ids if aid not in processed_ids]

print(f"  Total apps in RawLogs : {len(all_app_ids)}")
print(f"  Already processed      : {len(processed_ids)}")
print(f"  To process this run    : {len(unprocessed_ids)}")

if not unprocessed_ids:
    print("\nCOMPLETION: No new applications to process in this run.")
    print("TIP: New applications will be analyzed in the next run when data arrives.")
    print("="*60)

# ----------------------------
# Step 2: Chunked processing helpers
# ----------------------------
def _chunked(lst, n):
    """Yield successive n-sized chunks from lst."""
    for i in range(0, len(lst), n):
        yield lst[i : i + n]

def _write_chunk_results(result_df):
    """Write all six output datasets for a single chunk result_df.

    result_df is a pure in-memory DataFrame (no Kusto lineage) — raw event
    rows were collected to the driver and re-created via spark.createDataFrame
    before applyInPandas.  persist() here does NOT walk back to Kusto and
    does NOT trigger exportPartitionToBlob.  We persist once to avoid
    re-executing the applyInPandas UDF for each of the 6 dataset filter/write
    passes.
    """
    import logging as _logging
    _logger = _logging.getLogger(__name__)
    from pyspark import StorageLevel
    result_df = result_df.persist(StorageLevel.MEMORY_AND_DISK)
    errors_schema_local = StructType([
        StructField("applicationID", StringType(), True),
        StructField("error", StringType(), True),
    ])
    datasets = [
        ("metadata",        METADATA_SCHEMA,        "sparklens_metadata"),
        ("summary",         SUMMARY_SCHEMA,         "sparklens_summary"),
        ("metrics",         METRICS_SCHEMA,         "sparklens_metrics"),
        ("predictions",     PREDICTIONS_SCHEMA,     "sparklens_predictions"),
        ("recommendations", RECOMMENDATIONS_SCHEMA, "sparklens_recommedations"),
        ("errors",          errors_schema_local,    "sparklens_errors"),
    ]
    # This function's __globals__ IS the exec-ns dict (same object as ns in the
    # outer run() scope).  Setting globals()["metrics_out"] / ["metadata_out"]
    # makes them visible to the _install_write_kusto_wrapper closure so that
    # fabric_recommedations is populated when the wrapper fires on the
    # sparklens_recommedations write that immediately follows.
    _g = globals()
    try:
        for dataset_name, schema, table_name in datasets:
            subset = (
                result_df.filter(col("dataset") == lit(dataset_name))
                .select(F.from_json(col("payload_json"), schema).alias("j"))
                .select("j.*")
                .persist(StorageLevel.MEMORY_AND_DISK)
            )
            try:
                row_count = subset.count()
                if row_count > 0:
                    if dataset_name == "metrics":
                        try:
                            _logger.info(
                                "Collecting %d rows for metrics materialization", row_count)
                            _rows = subset.collect()
                            _g["metrics_out"] = spark.createDataFrame(_rows, schema)
                        except Exception as _cache_err:
                            _logger.warning("metrics_out materialization failed (%s); Fabric recs may be incomplete", _cache_err)
                            _g["metrics_out"] = None
                    elif dataset_name == "metadata":
                        try:
                            _logger.info(
                                "Collecting %d rows for metadata materialization", row_count)
                            _rows = subset.collect()
                            _g["metadata_out"] = spark.createDataFrame(_rows, schema)
                        except Exception as _cache_err:
                            _logger.warning("metadata_out materialization failed (%s); Fabric recs may be incomplete", _cache_err)
                            _g["metadata_out"] = None
                    write_kusto_df(subset, table_name, mode="Append", row_count=row_count)
                    print(f"    Wrote {row_count:,} rows → {table_name}")
            finally:
                subset.unpersist()
    finally:
        result_df.unpersist()

# Define helper functions at module level
OUTPUT_SCHEMA = StructType([
    StructField("applicationId", StringType(), False),
    StructField("dataset", StringType(), False),
    StructField("payload_json", StringType(), False),
])

def _safe_get(dct: Any, path: List[str], default=None):
    cur = dct
    for p in path:
        if not isinstance(cur, dict) or p not in cur:
            return default
        cur = cur[p]
    return cur

def _parse_record(rec_str: str) -> Dict[str, Any]:
    try:
        return json.loads(rec_str) if rec_str else {}
    except Exception:
        return {}

def _to_float(x, default=0.0):
    try:
        if x is None:
            return float(default)
        return float(x)
    except Exception:
        return float(default)

def _to_int(x, default=0):
    try:
        if x is None:
            return int(default)
        return int(x)
    except Exception:
        return int(default)

def safe_percentile(data, percentile):
    if not data:
        return 0.0
    try:
        return float(np.percentile(data, percentile))
    except Exception:
        sorted_data = sorted(data)
        n = len(sorted_data)
        index = int(percentile / 100.0 * (n - 1))
        return float(sorted_data[min(index, n-1)])

def safe_avg(data):
    return float(sum(data) / len(data)) if data else 0.0

def safe_max(data):
    return float(max(data)) if data else 0.0

def safe_min(data):
    return float(min(data)) if data else 0.0

def safe_max_int(data):
    return int(max(data)) if data else 0

def per_app_analyzer(pdf: pd.DataFrame) -> pd.DataFrame:
    """
    Enhanced groupBy(applicationId).applyInPandas with comprehensive analysis.
    Input:  pd.DataFrame - all rows for one applicationId group.
    Output: pd.DataFrame with columns (applicationId, dataset, payload_json).
    """
    if pdf is None or pdf.empty:
        return pd.DataFrame(columns=["applicationId", "dataset", "payload_json"])

    app_id = str(pdf["applicationId"].iloc[0])
    print(f"Processing {app_id}")

    events = []
    app_start_props = None
    first_record = None

    for r in pdf["records"].astype(str).tolist() if "records" in pdf.columns else []:
        full_obj = _parse_record(r)
        if first_record is None:
            first_record = full_obj
        props = full_obj.get("properties", {}) if isinstance(full_obj, dict) else {}
        ev = props.get("Event")
        ts = props.get("Timestamp")
        events.append((ev, ts, props))
        if ev == "SparkListenerApplicationStart":
            app_start_props = props

    has_start = app_start_props is not None
    out_rows = []

    # spark_props and _first_nonnull_prop are defined at the outer
    # per_app_analyzer scope so the helper is always available even when
    # app_start_props is None AND first_record is None (i.e., the metadata
    # if-block below is skipped entirely).  Python closures are late-binding:
    # when _first_nonnull_prop is called later (e.g., inside the task-metrics
    # block) it reads the CURRENT value of spark_props from this frame,
    # correctly picking up any reassignment made inside the if-block below.
    spark_props: dict = {}  # Initialised before the metadata if-block so the closure is always valid.

    def _first_nonnull_prop(prop_key: str):  # Defined at outer scope so it is accessible regardless of which metadata branch executes.
        """Best-effort property lookup across event shapes.

        NOTE: Best-practice checks are intentionally based on SparkListenerApplicationStart
        Spark Properties, but some Fabric event logs (e.g., SparkListenerJobStart)
        carry cluster Spark configs under a nested `Properties` dict.
        """

        if isinstance(spark_props, dict):
            v = spark_props.get(prop_key)
            if v is not None:
                return v

        for _ev, _ts, _p in events:
            if not isinstance(_p, dict):
                continue
            sp2 = _p.get("Spark Properties")
            if isinstance(sp2, dict):
                v = sp2.get(prop_key)
                if v is not None:
                    return v
            p2 = _p.get("Properties")
            if isinstance(p2, dict):
                v = p2.get(prop_key)
                if v is not None:
                    return v

        return None

    # ---- Metadata extraction ----
    if app_start_props or first_record:
        app_name = "Unknown Application"
        if app_start_props:
            app_name = app_start_props.get("App Name", "Unknown Application")
            spark_props = app_start_props.get("Spark Properties", {})  # Closure-captured by _first_nonnull_prop above.

        outer_metadata = first_record if first_record else {}
        executor_max = outer_metadata.get("executorMax")
        executor_min = outer_metadata.get("executorMin")
        if executor_max is not None:
            try:
                executor_max = int(executor_max)
            except (ValueError, TypeError):
                executor_max = None
        if executor_min is not None:
            try:
                executor_min = int(executor_min)
            except (ValueError, TypeError):
                executor_min = None
        if executor_max is None and spark_props:
            prop_max = spark_props.get("spark.dynamicAllocation.maxExecutors") or spark_props.get("spark.executor.instances")
            if prop_max is not None:
                try:
                    executor_max = int(prop_max)
                except (ValueError, TypeError):
                    pass
        if executor_min is None and spark_props:
            prop_min = spark_props.get("spark.dynamicAllocation.minExecutors") or spark_props.get("spark.dynamicAllocation.initialExecutors")
            if prop_min is not None:
                try:
                    executor_min = int(prop_min)
                except (ValueError, TypeError):
                    pass
        is_high_concurrency = outer_metadata.get("isHighConcurrencyEnabled")
        if is_high_concurrency is not None and isinstance(is_high_concurrency, str):
            is_high_concurrency = is_high_concurrency.lower() == "true"
        elif is_high_concurrency is None:
            is_high_concurrency = False

        # Prefer the Spark config property when present.
        # User requirement: derive high concurrency from spark.trident.highconcurrency.enabled
        # (Fabric logs may carry it on ApplicationStart Spark Properties or JobStart Properties).
        hc_prop = _first_nonnull_prop("spark.trident.highconcurrency.enabled")
        if hc_prop is not None:
            try:
                if isinstance(hc_prop, bool):
                    is_high_concurrency = hc_prop
                else:
                    is_high_concurrency = str(hc_prop).strip().lower() == "true"
            except Exception:
                pass
        metadata_payload = {
            "applicationId": app_id,
            "applicationName": app_name,
            "artifactId": outer_metadata.get("artifactId"),
            "artifactType": outer_metadata.get("artifactType"),
            "capacityId": outer_metadata.get("capacityId"),
            "executorMax": executor_max,
            "executorMin": executor_min,
            "fabricEnvId": outer_metadata.get("fabricEnvId"),
            "fabricLivyId": outer_metadata.get("fabricLivyId"),
            "fabricTenantId": outer_metadata.get("fabricTenantId"),
            "fabricWorkspaceId": outer_metadata.get("fabricWorkspaceId"),
            "isHighConcurrencyEnabled": is_high_concurrency,
            "spark.native.enabled": _first_nonnull_prop("spark.native.enabled"),
            "spark.databricks.delta.autoCompact.enabled": _first_nonnull_prop("spark.databricks.delta.autoCompact.enabled"),
            "spark.microsoft.delta.targetFileSize.adaptive.enabled": _first_nonnull_prop("spark.microsoft.delta.targetFileSize.adaptive.enabled"),
            "spark.microsoft.delta.optimize.fast.enabled": _first_nonnull_prop("spark.microsoft.delta.optimize.fast.enabled"),
            "spark.microsoft.delta.optimize.fileLevelTarget.enabled": _first_nonnull_prop("spark.microsoft.delta.optimize.fileLevelTarget.enabled"),
            "spark.microsoft.delta.stats.collect.extended": _first_nonnull_prop("spark.microsoft.delta.stats.collect.extended"),
            "spark.microsoft.delta.snapshot.driverMode.enabled": _first_nonnull_prop("spark.microsoft.delta.snapshot.driverMode.enabled"),
            "spark.sql.parquet.vorder.default": _first_nonnull_prop("spark.sql.parquet.vorder.default"),
            "spark.microsoft.delta.optimizeWrite.enabled": _first_nonnull_prop("spark.microsoft.delta.optimizeWrite.enabled"),
            "spark.databricks.delta.optimizeWrite.enabled": _first_nonnull_prop("spark.databricks.delta.optimizeWrite.enabled"),
            "spark.databricks.delta.optimizeWrite.partitioned.enabled": _first_nonnull_prop("spark.databricks.delta.optimizeWrite.partitioned.enabled"),
            "spark.fabric.resourceProfile": _first_nonnull_prop("spark.fabric.resourceProfile"),
        }
    else:
        app_name = "Unknown Application"
        spark_props = {}
        metadata_payload = {
            "applicationId": app_id,
            "applicationName": "Unknown Application",
            "artifactId": None, "artifactType": None, "capacityId": None,
            "executorMax": None, "executorMin": None, "fabricEnvId": None,
            "fabricLivyId": None, "fabricTenantId": None, "fabricWorkspaceId": None,
            "isHighConcurrencyEnabled": False, "spark.native.enabled": None,
            "spark.databricks.delta.autoCompact.enabled": None,
            "spark.microsoft.delta.targetFileSize.adaptive.enabled": None,
            "spark.microsoft.delta.optimize.fast.enabled": None,
            "spark.microsoft.delta.optimize.fileLevelTarget.enabled": None,
            "spark.microsoft.delta.stats.collect.extended": None,
            "spark.microsoft.delta.snapshot.driverMode.enabled": None,
            "spark.sql.parquet.vorder.default": None,
            "spark.microsoft.delta.optimizeWrite.enabled": None,
            "spark.databricks.delta.optimizeWrite.enabled": None,
            "spark.databricks.delta.optimizeWrite.partitioned.enabled": None,
            "spark.fabric.resourceProfile": None,
        }

    out_rows.append({"applicationId": app_id, "dataset": "metadata", "payload_json": json.dumps(metadata_payload)})

    # ---- Handle missing start event ----
    if not has_start:
        out_rows.append({"applicationId": app_id, "dataset": "errors", "payload_json": json.dumps({
            "applicationID": app_id,
            "error": "Missing SparkListenerApplicationStart event"
        })})
        task_events = [props for ev, _, props in events if ev == "SparkListenerTaskEnd" and isinstance(props, dict)]
        if task_events:
            task_durations = []
            exec_times = []
            for task in task_events:
                task_info = task.get("Task Info", {})
                task_metrics = task.get("Task Metrics", {})
                launch_time = _to_float(task_info.get("Launch Time", 0))
                finish_time = _to_float(task_info.get("Finish Time", 0))
                if finish_time > launch_time > 0:
                    task_durations.append((finish_time - launch_time) / 1000.0)
                exec_time = _to_float(task_metrics.get("Executor Run Time", 0)) / 1000.0
                if exec_time > 0:
                    exec_times.append(exec_time)
            total_duration = sum(task_durations) if task_durations else 0.0
            total_executor_time = sum(exec_times) if exec_times else 0.0
            duration_min = int(total_duration // 60)
            duration_sec = int(total_duration % 60)
            duration_str = f"{duration_min}m {duration_sec}s"
            wallclock_min = int(total_executor_time // 60)
            wallclock_sec = int(total_executor_time % 60)
            wallclock_str = f"{wallclock_min}m {wallclock_sec}s"
        else:
            duration_str = "0m 0s"
            wallclock_str = "0m 0s"
        default_summary = {
            "stage_id": 0, "stage_attempt_id": 0, "num_tasks": 0, "successful_tasks": 0, "failed_tasks": 0,
            "min_duration_sec": 0.0, "max_duration_sec": 0.0, "avg_duration_sec": 0.0, "p75_duration_sec": 0.0,
            "avg_shuffle_read_mb": 0.0, "max_shuffle_read_mb": 0.0, "avg_shuffle_read_records": 0.0, "max_shuffle_read_records": 0,
            "avg_shuffle_write_mb": 0.0, "max_shuffle_write_mb": 0.0, "avg_shuffle_write_records": 0.0, "max_shuffle_write_records": 0,
            "avg_input_mb": 0.0, "max_input_mb": 0.0, "avg_input_records": 0.0, "max_input_records": 0,
            "avg_output_mb": 0.0, "max_output_mb": 0.0, "avg_output_records": 0.0, "max_output_records": 0,
            "min_launch_time": 0, "max_finish_time": 0, "num_executors": 0, "stage_execution_time_sec": 0.0, "app_id": app_id
        }
        out_rows.append({"applicationId": app_id, "dataset": "summary", "payload_json": json.dumps(default_summary)})
        out_rows.append({"applicationId": app_id, "dataset": "metrics", "payload_json": json.dumps({
            "app_id": app_id, "metric": "Application Duration (sec)", "value": 0.0
        })})
        prediction_record = {
            "Executor Count": 1,
            "Executor Multiplier": "1.0x (Current - Error State)",
            "Estimated Executor WallClock": wallclock_str,
            "Estimated Total Duration": duration_str,
            "app_id": app_id
        }
        out_rows.append({"applicationId": app_id, "dataset": "predictions", "payload_json": json.dumps(prediction_record)})
        out_rows.append({"applicationId": app_id, "dataset": "recommendations", "payload_json": json.dumps({
            "app_id": app_id, "recommendation": "Missing SparkListenerApplicationStart event - limited analysis available"
        })})
        return pd.DataFrame(out_rows)

    # ---- Duration computation ----
    start_ts = next((ts for ev, ts, _ in events if ev == "SparkListenerApplicationStart"), None)
    end_ts = next((ts for ev, ts, _ in events if ev == "SparkListenerApplicationEnd"), None)
    if start_ts is not None and end_ts is not None:
        app_duration_sec = max(0.0, (_to_float(end_ts) - _to_float(start_ts)) / 1000.0)
    else:
        ts_vals = [_to_float(ts) for _, ts, _ in events if ts is not None]
        ts_vals = [t for t in ts_vals if t > 0]
        app_duration_sec = max(0.0, (max(ts_vals) - min(ts_vals)) / 1000.0) if ts_vals else 0.0

    # ---- Event extraction ----
    task_props = [props for ev, _, props in events if ev == "SparkListenerTaskEnd" and isinstance(props, dict)]
    stage_props = [props for ev, _, props in events if ev == "SparkListenerStageCompleted" and isinstance(props, dict)]
    job_props = [props for ev, _, props in events if ev == "SparkListenerJobEnd" and isinstance(props, dict)]
    task_count = len(task_props)
    stage_count = len(stage_props)
    job_count = len(job_props)

    # ---- Streaming detection ----
    streaming_confidence = 0
    streaming_signals = []
    streaming_query_events = [ev for ev, _, _ in events if "StreamingQueryListener" in str(ev) or "streaming.StreamingQuery" in str(ev)]
    if streaming_query_events:
        streaming_confidence += 10
        streaming_signals.append(f"StreamingQueryListener events ({len(streaming_query_events)})")
    streaming_stage_keywords = [
        "statestoresave", "statestorerestore", "statestorerdd",
        "writestream", "readstream", "streaming",
        "microbatch", "microbatchexecution",
        "continuousexecution", "streamingquery", "streamexecution"
    ]
    state_store_stages = []
    for stage in stage_props:
        stage_info = stage.get("Stage Info", {})
        stage_name = str(stage_info.get("Stage Name", "")).lower()
        stage_details = str(stage_info.get("Details", "")).lower()
        if any(keyword in stage_name or keyword in stage_details for keyword in streaming_stage_keywords):
            stage_id = stage_info.get("Stage ID")
            if stage_id not in state_store_stages:
                state_store_stages.append(stage_id)
    if state_store_stages:
        streaming_confidence += 10
        streaming_signals.append(f"Streaming operations in {len(state_store_stages)} stages")
    if app_duration_sec > 0 and job_count > 0:
        jobs_per_minute = (job_count / app_duration_sec) * 60
        if jobs_per_minute > 10:
            streaming_confidence += 3
            streaming_signals.append(f"High job frequency ({jobs_per_minute:.1f}/min)")
        elif jobs_per_minute > 5:
            streaming_confidence += 2
    if app_duration_sec > 0 and stage_count > 0:
        stages_per_second = stage_count / app_duration_sec
        if stages_per_second > 0.5:
            streaming_confidence += 2
    if job_count > 50 and stage_count > 50:
        stage_job_ratio = stage_count / max(1, job_count)
        if 0.8 < stage_job_ratio < 1.5:
            streaming_confidence += 5
            streaming_signals.append(f"Micro-batch pattern ({job_count} jobs, {stage_count} stages)")
        elif job_count > 80:
            streaming_confidence += 3
    app_name_lower = app_name.lower() if app_name else ""
    if any(keyword in app_name_lower for keyword in ["stream", "checkpoint", "readstream", "writestream"]):
        streaming_confidence += 2
    is_streaming_job = streaming_confidence >= 5
    if is_streaming_job and streaming_signals:
        print(f"   Streaming job detected (confidence: {streaming_confidence}): {', '.join(streaming_signals)}")

    # ---- Streaming stats ----
    streaming_stats = []
    _is_wound_down = False  # True when all recorded batches are idle (query stopped before analysis)
    if is_streaming_job:
        for ev, ts, props in events:
            if "QueryProgressEvent" in str(ev) or "streaming" in str(ev).lower():
                try:
                    progress = props.get("progress", {}) if isinstance(props, dict) else {}
                    if progress:
                        batch_id = progress.get("batchId", progress.get("id", -1))
                        run_id = progress.get("runId", "unknown")
                        name = progress.get("name", "unnamed_query")
                        timestamp = progress.get("timestamp", ts)
                        batch_duration = progress.get("batchDuration", 0)
                        num_input_rows = progress.get("numInputRows", 0)
                        input_rows_per_second = progress.get("inputRowsPerSecond", 0.0)
                        process_rows_per_second = progress.get("processedRowsPerSecond", 0.0)
                        state_operators = progress.get("stateOperators", [])
                        total_state_rows = 0
                        total_state_memory = 0
                        for state_op in state_operators:
                            if isinstance(state_op, dict):
                                total_state_rows += _to_int(state_op.get("numRowsTotal", 0))
                                total_state_memory += _to_int(state_op.get("memoryUsedBytes", 0))
                        sink = progress.get("sink", {})
                        sink_description = sink.get("description", "unknown") if isinstance(sink, dict) else "unknown"
                        streaming_stats.append({
                            "app_id": app_id, "batch_id": batch_id, "run_id": run_id,
                            "query_name": name, "timestamp": timestamp,
                            "batch_duration_ms": batch_duration, "num_input_rows": num_input_rows,
                            "input_rows_per_second": input_rows_per_second,
                            "processed_rows_per_second": process_rows_per_second,
                            "state_rows_total": total_state_rows, "state_memory_bytes": total_state_memory,
                            "sink_description": sink_description
                        })
                except Exception:
                    pass
        # Wound-down detection: a wound-down query drains state to 0 and then keeps
        # emitting empty trigger-cycle batches (~1 s each) with no real work.
        # Detect this before writing metrics so idle rows are suppressed.
        _active_batches = [
            s for s in streaming_stats
            if s.get("state_rows_total", 0) > 0 or s.get("num_input_rows", 0) > 0
        ]
        _is_wound_down = len(streaming_stats) > 0 and len(_active_batches) == 0
        if _is_wound_down:
            print(f"   [WARN] Wound-down streaming job: all {len(streaming_stats)} batches have "
                  f"0 input rows and 0 state rows. Idle trigger cycles will be suppressed from metrics.")

        # Filter idle batches (0 input, 0 state, <2 s) before writing to metrics.
        # Idle polling cycles from a wound-down query produce ~1,200 noisy zero-value rows.
        _stats_to_emit = [
            s for s in streaming_stats
            if not (
                s.get("num_input_rows", 0) == 0
                and s.get("state_rows_total", 0) == 0
                and (s.get("batch_duration_ms") or 0) < 2000
            )
        ]
        # If ALL batches were idle, keep a 10-row sample so the metrics table is not empty.
        if not _stats_to_emit and streaming_stats:
            _stats_to_emit = streaming_stats[:5] + streaming_stats[-5:]

        # Convert streaming_stats into sparklens_metrics rows (no new table needed).
        # Each batch produces one metrics row per numeric signal.
        for stat in _stats_to_emit:
            _s_app_id = str(stat.get("app_id", app_id))
            _batch_id = stat.get("batch_id", -1)
            _pfx = f"Streaming Batch {_batch_id}"
            _streaming_metric_pairs = [
                (f"{_pfx}: Duration (ms)",          float(stat.get("batch_duration_ms") or 0)),
                (f"{_pfx}: Input Rows",              float(stat.get("num_input_rows") or 0)),
                (f"{_pfx}: Input Rows/sec",          float(stat.get("input_rows_per_second") or 0)),
                (f"{_pfx}: Processed Rows/sec",      float(stat.get("processed_rows_per_second") or 0)),
                (f"{_pfx}: State Rows Total",        float(stat.get("state_rows_total") or 0)),
                (f"{_pfx}: State Memory (bytes)",    float(stat.get("state_memory_bytes") or 0)),
            ]
            for _sm_key, _sm_val in _streaming_metric_pairs:
                out_rows.append({"applicationId": _s_app_id, "dataset": "metrics", "payload_json": json.dumps({
                    "app_id": _s_app_id, "metric": _sm_key, "value": _sm_val
                })})

    # ---- Task metrics ----
    exec_run_times_sec = []
    cpu_times_sec = []
    gc_times_ms = []
    executor_ids = set()
    for p in task_props:
        tm = p.get("Task Metrics", {}) if isinstance(p.get("Task Metrics"), dict) else {}
        ti = p.get("Task Info", {}) if isinstance(p.get("Task Info"), dict) else {}
        exec_time = _to_float(tm.get("Executor Run Time"), 0.0) / 1000.0
        cpu_time = _to_float(tm.get("Executor CPU Time"), 0.0) / 1000000000.0
        gc_time = _to_float(tm.get("JVM GC Time"), 0.0)
        exec_run_times_sec.append(exec_time)
        cpu_times_sec.append(cpu_time)
        gc_times_ms.append(gc_time)
        executor_ids.add(str(ti.get("Executor ID", "unknown")))

    total_exec = float(sum(exec_run_times_sec)) if exec_run_times_sec else 0.0
    total_cpu = float(sum(cpu_times_sec)) if cpu_times_sec else 0.0
    total_gc_ms = float(sum(gc_times_ms)) if gc_times_ms else 0.0
    executor_count = len([e for e in executor_ids if e != "unknown"])
    if executor_count == 0 and task_count > 0:
        executor_count = 1

    # Extract executor and driver core counts from event log properties.
    # _first_nonnull_prop searches SparkListenerApplicationStart Spark Properties,
    # then JobStart Properties — covering all Fabric event log shapes.
    # Default to 8 when not present (Fabric standard node has 8 cores).
    try:
        _ec_raw = _first_nonnull_prop("spark.executor.cores")
        executor_cores_per_executor = int(_ec_raw) if _ec_raw is not None else 8
    except (ValueError, TypeError):
        executor_cores_per_executor = 8

    try:
        _dc_raw = _first_nonnull_prop("spark.driver.cores")
        driver_cores_per_driver = int(_dc_raw) if _dc_raw is not None else 8
    except (ValueError, TypeError):
        driver_cores_per_driver = 8

    executor_eff = (total_cpu / total_exec) if total_exec > 0 else 0.0
    gc_overhead = ((total_gc_ms / 1000.0) / total_exec) if total_exec > 0 else 0.0
    parallelism_score = min(1.0, (task_count / max(1, executor_count * executor_cores_per_executor))) if executor_count > 0 else 0.0
    if len(exec_run_times_sec) > 1:
        avg_task_time = sum(exec_run_times_sec) / len(exec_run_times_sec)
        max_task_time = max(exec_run_times_sec)
        task_skew = (max_task_time / avg_task_time) if avg_task_time > 0 else 1.0
    else:
        task_skew = 1.0

    # ---- Stage summaries ----
    if stage_count > 0:
        for p in stage_props:
            stage_info = p.get("Stage Info", {})
            stage_id = _to_int(stage_info.get("Stage ID", 0))
            stage_attempt_id = _to_int(stage_info.get("Stage Attempt ID", 0))
            stage_tasks = [props for ev, _, props in events
                           if ev == "SparkListenerTaskEnd" and isinstance(props, dict)
                           and _to_int(props.get("Stage ID", -1)) == stage_id]
            if not stage_tasks:
                continue
            task_durations = []
            shuffle_read_bytes = []
            shuffle_read_records = []
            shuffle_write_bytes = []
            shuffle_write_records = []
            input_bytes = []
            input_records = []
            output_bytes = []
            output_records = []
            launch_times = []
            finish_times = []
            executor_ids_stage = set()
            successful_count = 0
            failed_count = 0
            for task in stage_tasks:
                task_info = task.get("Task Info", {})
                task_metrics = task.get("Task Metrics", {})
                if task_info.get("Failed", False):
                    failed_count += 1
                else:
                    successful_count += 1
                launch_time = _to_float(task_info.get("Launch Time", 0))
                finish_time = _to_float(task_info.get("Finish Time", 0))
                if finish_time > launch_time > 0:
                    task_durations.append((finish_time - launch_time) / 1000.0)
                    launch_times.append(launch_time)
                    finish_times.append(finish_time)
                executor_ids_stage.add(str(task_info.get("Executor ID", "unknown")))
                shuffle_read = task_metrics.get("Shuffle Read Metrics", {})
                if shuffle_read:
                    shuffle_read_bytes.append(_to_float(shuffle_read.get("Total Bytes Read", 0)) / (1024 * 1024))
                    shuffle_read_records.append(_to_float(shuffle_read.get("Total Records Read", 0)))
                shuffle_write = task_metrics.get("Shuffle Write Metrics", {})
                if shuffle_write:
                    shuffle_write_bytes.append(_to_float(shuffle_write.get("Shuffle Bytes Written", 0)) / (1024 * 1024))
                    shuffle_write_records.append(_to_float(shuffle_write.get("Shuffle Records Written", 0)))
                input_m = task_metrics.get("Input Metrics", {})
                if input_m:
                    input_bytes.append(_to_float(input_m.get("Bytes Read", 0)) / (1024 * 1024))
                    input_records.append(_to_float(input_m.get("Records Read", 0)))
                output_m = task_metrics.get("Output Metrics", {})
                if output_m:
                    output_bytes.append(_to_float(output_m.get("Bytes Written", 0)) / (1024 * 1024))
                    output_records.append(_to_float(output_m.get("Records Written", 0)))
            stage_submission = _to_float(stage_info.get("Submission Time", 0))
            stage_completion = _to_float(stage_info.get("Completion Time", 0))
            stage_execution_time = ((stage_completion - stage_submission) / 1000.0) if stage_completion > stage_submission > 0 else 0.0
            stage_summary = {
                "stage_id": stage_id, "stage_attempt_id": stage_attempt_id,
                "num_tasks": len(stage_tasks), "successful_tasks": successful_count, "failed_tasks": failed_count,
                "min_duration_sec": safe_min(task_durations), "max_duration_sec": safe_max(task_durations),
                "avg_duration_sec": safe_avg(task_durations), "p75_duration_sec": safe_percentile(task_durations, 75),
                "avg_shuffle_read_mb": safe_avg(shuffle_read_bytes), "max_shuffle_read_mb": safe_max(shuffle_read_bytes),
                "avg_shuffle_read_records": safe_avg(shuffle_read_records), "max_shuffle_read_records": safe_max_int(shuffle_read_records),
                "avg_shuffle_write_mb": safe_avg(shuffle_write_bytes), "max_shuffle_write_mb": safe_max(shuffle_write_bytes),
                "avg_shuffle_write_records": safe_avg(shuffle_write_records), "max_shuffle_write_records": safe_max_int(shuffle_write_records),
                "avg_input_mb": safe_avg(input_bytes), "max_input_mb": safe_max(input_bytes),
                "avg_input_records": safe_avg(input_records), "max_input_records": safe_max_int(input_records),
                "avg_output_mb": safe_avg(output_bytes), "max_output_mb": safe_max(output_bytes),
                "avg_output_records": safe_avg(output_records), "max_output_records": safe_max_int(output_records),
                "min_launch_time": int(min(launch_times)) if launch_times else 0,
                "max_finish_time": int(max(finish_times)) if finish_times else 0,
                "num_executors": len([e for e in executor_ids_stage if e != "unknown"]),
                "stage_execution_time_sec": stage_execution_time, "app_id": app_id
            }
            out_rows.append({"applicationId": app_id, "dataset": "summary", "payload_json": json.dumps(stage_summary)})
    else:
        default_summary = {
            "stage_id": 0, "stage_attempt_id": 0, "num_tasks": task_count,
            "successful_tasks": task_count, "failed_tasks": 0,
            "min_duration_sec": safe_min(exec_run_times_sec), "max_duration_sec": safe_max(exec_run_times_sec),
            "avg_duration_sec": safe_avg(exec_run_times_sec), "p75_duration_sec": safe_percentile(exec_run_times_sec, 75),
            "avg_shuffle_read_mb": 0.0, "max_shuffle_read_mb": 0.0, "avg_shuffle_read_records": 0.0, "max_shuffle_read_records": 0,
            "avg_shuffle_write_mb": 0.0, "max_shuffle_write_mb": 0.0, "avg_shuffle_write_records": 0.0, "max_shuffle_write_records": 0,
            "avg_input_mb": 0.0, "max_input_mb": 0.0, "avg_input_records": 0.0, "max_input_records": 0,
            "avg_output_mb": 0.0, "max_output_mb": 0.0, "avg_output_records": 0.0, "max_output_records": 0,
            "min_launch_time": 0, "max_finish_time": 0, "num_executors": executor_count,
            "stage_execution_time_sec": app_duration_sec, "app_id": app_id
        }
        out_rows.append({"applicationId": app_id, "dataset": "summary", "payload_json": json.dumps(default_summary)})

    # ---- Wall clock times ----
    executor_wall_clock_time = 0.0
    driver_wall_clock_time = app_duration_sec
    if task_props:
        task_launch_times = []
        task_finish_times = []
        for p in task_props:
            ti = p.get("Task Info", {})
            launch_time = _to_float(ti.get("Launch Time", 0))
            finish_time = _to_float(ti.get("Finish Time", 0))
            if launch_time > 0:
                task_launch_times.append(launch_time)
            if finish_time > 0:
                task_finish_times.append(finish_time)
        if task_launch_times and task_finish_times:
            executor_wall_clock_time = (max(task_finish_times) - min(task_launch_times)) / 1000.0
            if is_streaming_job:
                driver_wall_clock_time = -1.0
            else:
                driver_wall_clock_time = max(0.0, app_duration_sec - executor_wall_clock_time)

    # ---- Metrics ----
    metrics_list = [
        ("Application Duration (sec)", app_duration_sec),
        ("Task Count", float(task_count)),
        ("Stage Count", float(stage_count)),
        ("Job Count", float(job_count)),
        ("Executor Count", float(executor_count)),
        ("Executor Efficiency", float(max(0.0, min(1.0, executor_eff)))),
        ("Parallelism Score", float(max(0.0, min(1.0, parallelism_score)))),
        ("GC Overhead", float(max(0.0, min(1.0, gc_overhead)))),
        ("Task Skew Ratio", float(max(1.0, task_skew))),
        ("Total Executor Time (sec)", total_exec),
        ("Average Task Duration (sec)", float(sum(exec_run_times_sec) / len(exec_run_times_sec)) if exec_run_times_sec else 0.0),
        ("Executor Wall Clock Time (sec)", executor_wall_clock_time),
        ("Job Type", 1.0 if is_streaming_job else 0.0),
    ]
    if not is_streaming_job and driver_wall_clock_time >= 0:
        metrics_list.extend([
            ("Driver Wall Clock Time (sec)", driver_wall_clock_time),
            ("Driver Time %", (driver_wall_clock_time / max(1e-9, app_duration_sec)) * 100.0),
            ("Executor Time %", (executor_wall_clock_time / max(1e-9, app_duration_sec)) * 100.0),
        ])
    if is_streaming_job:
        if stage_count > 0:
            metrics_list.append(("Avg Micro-Batch Duration (sec)", app_duration_sec / stage_count))
        if job_count > 0:
            metrics_list.append(("Jobs Per Minute", (job_count / max(1.0, app_duration_sec)) * 60.0))
        driver_overhead_sec = max(0.0, app_duration_sec - executor_wall_clock_time)
        metrics_list.append(("Driver Wall Clock Time (sec)", driver_overhead_sec))
        metrics_list.append(("Driver Overhead %", (driver_overhead_sec / max(1e-9, app_duration_sec)) * 100.0))

    # Skew diagnostics
    if len(exec_run_times_sec) > 1:
        min_duration = float(min(exec_run_times_sec))
        max_duration = float(max(exec_run_times_sec))
        avg_duration = float(np.mean(exec_run_times_sec))
        median_duration = float(np.median(exec_run_times_sec))
        task_imbalance_ratio = max_duration / max(0.001, avg_duration)
        if task_imbalance_ratio > 10:
            task_msg = f"Some tasks taking {task_imbalance_ratio:.0f}x longer - Investigate task skew"
        elif task_imbalance_ratio > 3:
            task_msg = f"Tasks vary {task_imbalance_ratio:.1f}x in duration - Review data distribution"
        else:
            task_msg = f"Tasks balanced ({task_imbalance_ratio:.1f}x variation)"
        metrics_list.append((task_msg, task_imbalance_ratio))
        metrics_list.append(("Task Duration: Fastest (sec)", min_duration))
        metrics_list.append(("Task Duration: Slowest (sec)", max_duration))
        metrics_list.append(("Task Duration: Typical (median sec)", median_duration))

    shuffle_read_sizes = []
    shuffle_write_sizes = []
    input_data_sizes = []
    output_data_sizes = []
    for p in task_props:
        tm = p.get("Task Metrics", {}) if isinstance(p.get("Task Metrics"), dict) else {}
        shuffle_read = tm.get("Shuffle Read Metrics", {})
        if shuffle_read:
            shuffle_read_sizes.append(_to_float(shuffle_read.get("Total Bytes Read", 0)))
        shuffle_write = tm.get("Shuffle Write Metrics", {})
        if shuffle_write:
            shuffle_write_sizes.append(_to_float(shuffle_write.get("Shuffle Bytes Written", 0)))
        input_metrics = tm.get("Input Metrics", {})
        if input_metrics:
            input_data_sizes.append(_to_float(input_metrics.get("Bytes Read", 0)))
        output_metrics = tm.get("Output Metrics", {})
        if output_metrics:
            output_data_sizes.append(_to_float(output_metrics.get("Bytes Written", 0)))

    if len(shuffle_read_sizes) > 1:
        shuffle_read_avg = np.mean(shuffle_read_sizes)
        shuffle_read_max = max(shuffle_read_sizes)
        shuffle_read_ratio = shuffle_read_max / max(1, shuffle_read_avg)
        if shuffle_read_ratio > 5:
            sr_msg = f"Shuffle read imbalance {shuffle_read_ratio:.1f}x - Consider salting or repartitioning"
        elif shuffle_read_ratio > 2:
            sr_msg = f"Moderate shuffle variation {shuffle_read_ratio:.1f}x - Review join/groupBy keys"
        else:
            sr_msg = f"Shuffle reads balanced ({shuffle_read_ratio:.1f}x)"
        metrics_list.append((sr_msg, shuffle_read_ratio))
        metrics_list.append(("Shuffle Read: Typical Size (MB)", float(shuffle_read_avg / (1024 * 1024))))
        metrics_list.append(("Shuffle Read: Largest Size (MB)", float(shuffle_read_max / (1024 * 1024))))

    if len(shuffle_write_sizes) > 1:
        shuffle_write_avg = np.mean(shuffle_write_sizes)
        shuffle_write_max = max(shuffle_write_sizes)
        shuffle_write_ratio = shuffle_write_max / max(1, shuffle_write_avg)
        if shuffle_write_ratio > 5:
            sw_msg = f"Shuffle write imbalance {shuffle_write_ratio:.1f}x - Review partitioning strategy"
        elif shuffle_write_ratio > 2:
            sw_msg = f"Moderate write variation {shuffle_write_ratio:.1f}x - Some partitions writing more"
        else:
            sw_msg = f"Shuffle writes balanced ({shuffle_write_ratio:.1f}x)"
        metrics_list.append((sw_msg, shuffle_write_ratio))
        metrics_list.append(("Shuffle Write: Typical Size (MB)", float(shuffle_write_avg / (1024 * 1024))))
        metrics_list.append(("Shuffle Write: Largest Size (MB)", float(shuffle_write_max / (1024 * 1024))))

    if len(input_data_sizes) > 1:
        input_avg = np.mean(input_data_sizes)
        input_max = max(input_data_sizes)
        input_ratio = input_max / max(1, input_avg)
        if is_streaming_job:
            if input_ratio > 50:
                input_msg = f"Files varying {input_ratio:.0f}x in size - Fix file sizing in landing zone"
            elif input_ratio > 10:
                input_msg = f"File sizes vary {input_ratio:.0f}x - Use maxFilesPerTrigger"
            else:
                input_msg = f"File sizes consistent ({input_ratio:.1f}x variation)"
        else:
            if input_ratio > 50:
                input_msg = f"Input files vary {input_ratio:.0f}x - Run OPTIMIZE or repartition source"
            elif input_ratio > 10:
                input_msg = f"Moderate file variation {input_ratio:.0f}x - Consider coalescing small files"
            else:
                input_msg = f"Input files balanced ({input_ratio:.1f}x variation)"
        metrics_list.append((input_msg, input_ratio))
        metrics_list.append(("Input File: Typical Size (MB)", float(input_avg / (1024 * 1024))))
        metrics_list.append(("Input File: Largest Size (MB)", float(input_max / (1024 * 1024))))

    if len(output_data_sizes) > 1:
        output_avg = np.mean(output_data_sizes)
        output_max = max(output_data_sizes)
        output_ratio = output_max / max(1, output_avg)
        if output_avg > 1024 * 1024 or (not is_streaming_job and output_ratio > 5):
            if output_ratio > 10:
                output_msg = f"Output write imbalance {output_ratio:.0f}x - Review partitioning before writes"
            elif output_ratio > 3:
                output_msg = f"Some tasks writing {output_ratio:.1f}x more - Check partition distribution"
            else:
                output_msg = f"Output writes balanced ({output_ratio:.1f}x variation)"
            metrics_list.append((output_msg, output_ratio))
            metrics_list.append(("Output Write: Typical Size (MB)", float(output_avg / (1024 * 1024))))
            metrics_list.append(("Output Write: Largest Size (MB)", float(output_max / (1024 * 1024))))

    for k, v in metrics_list:
        out_rows.append({"applicationId": app_id, "dataset": "metrics", "payload_json": json.dumps({
            "app_id": app_id, "metric": k, "value": float(v)
        })})

    # ---- Scaling predictions ----
    # Model: predicted_duration(N) = serial_time + max(parallel_time/N * penalty(N), skew_floor)
    # All inputs are directly measured from the event log — no proxies.

    def _fmt(s):
        return f"{int(s // 60)}m {int(s % 60)}s"

    # --- Streaming: executor scaling cannot be projected; show measured current-state only ---
    # The 1.0x row uses the directly-measured executor wall-clock and app duration.
    # Scale-up/scale-down rows are omitted — streaming throughput is bounded by
    # source arrival rate and state store I/O, not executor count.
    if is_streaming_job:
        _ewc = max(0.0, executor_wall_clock_time)
        out_rows.append({"applicationId": app_id, "dataset": "predictions", "payload_json": json.dumps({
            "Executor Count": max(1, executor_count),
            "Executor Multiplier": "1.0x (Current - Streaming)",
            "Estimated Executor WallClock": _fmt(_ewc),
            "Estimated Total Duration": _fmt(app_duration_sec),
            "app_id": app_id
        })})
    else:
        import math as _math

        # Directly measured components
        _serial_time   = max(0.0, driver_wall_clock_time)
        _parallel_time = max(1e-9, executor_wall_clock_time)
        _base_N        = max(1, executor_count)
        _base_duration = max(1e-9, app_duration_sec)

        # Skew floor: no stage completes faster than its slowest task
        _skew_floor = max(exec_run_times_sec) if exec_run_times_sec else 0.0

        # Safe shuffle_write_ratio — only exists if shuffle data was present
        try:
            _sw_ratio = float(shuffle_write_ratio)
        except NameError:
            _sw_ratio = 1.0

        # AQE is always enabled in Fabric — apply fixed skew mitigation factor
        _aqe_skew_factor = 0.85

        def _efficiency_penalty(N, base_N, skew, gc, sw_ratio):
            """
            Product of four independent, interpretable penalty factors.
            Each factor >= 1.0. Higher total = less benefit from scaling.
            """
            # 1. Communication overhead — log2 growth (all-reduce cost in distributed shuffle)
            _comm  = 1.0 + 0.03 * _math.log2(max(1.0, N / base_N))
            # 2. Skew penalty — slowest task limits stage parallelism; AQE mitigates it
            _skew  = 1.0 + (skew - 1.0) * _aqe_skew_factor / max(1, N)
            # 3. GC penalty — more executors = less heap each = more frequent GC
            _gc    = 1.0 + gc * 0.5 * max(0.0, _math.log2(max(1.0, N / base_N)))
            # 4. Shuffle amplification — more executors = more cross-node shuffle reads
            _shuf  = 1.0 + max(0.0, sw_ratio - 1.0) * 0.02 * max(0.0, (N / base_N) - 1.0)
            return _comm * _skew * _gc * _shuf

        # Fully driver-bound: scaling cannot help — all rows show current duration
        _fully_driver_bound = _serial_time >= 0.95 * _base_duration
        # Partially driver-bound: driver > executor wall-clock (>50%) but < 95%.
        # Predictions still show Amdahl projections, but labels are flagged so users
        # understand the recommendation "scaling won't help" and predictions are consistent.
        _driver_bottleneck = (not _fully_driver_bound) and (_serial_time > _parallel_time)

        _multipliers = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 4.0, 6.0, 8.0]

        for _m in _multipliers:
            _N = max(1, int(_base_N * _m))

            if _fully_driver_bound:
                # All predictions equal current: parallel work is negligible
                _pred_total    = _base_duration
                _pred_parallel = _parallel_time
                _low           = _base_duration
                _high          = _base_duration
            else:
                _penalty = _efficiency_penalty(_N, _base_N, task_skew, gc_overhead, _sw_ratio)

                # Core prediction
                _pred_parallel = max((_parallel_time / _N) * _penalty, _skew_floor)
                _pred_total    = _serial_time + _pred_parallel

                # Amdahl theoretical minimum as additional floor
                _serial_frac    = _serial_time / _base_duration
                _amdahl_speedup = 1.0 / (_serial_frac + (1.0 - _serial_frac) / _m)
                _amdahl_floor   = _base_duration / _amdahl_speedup
                _pred_total     = max(_pred_total, _amdahl_floor)

                # Confidence range: optimistic (penalty*0.85) and pessimistic (penalty*1.3)
                _low  = _serial_time + max((_parallel_time / _N) * (_penalty * 0.85), _skew_floor)
                _high = _serial_time + max((_parallel_time / _N) * (_penalty * 1.30), _skew_floor)
                _low  = max(_low,  _amdahl_floor)
                _high = max(_high, _amdahl_floor)

            _wallclock_str = _fmt(_pred_parallel)

            if _fully_driver_bound and _m != 1.0:
                _duration_str = _fmt(_pred_total)
            elif _m == 1.0:
                _duration_str = _fmt(_pred_total)
            else:
                _duration_str = f"{_fmt(_pred_total)} ({_fmt(_low)} – {_fmt(_high)})"

            # Multiplier label
            if _m == 1.0:
                if _fully_driver_bound:
                    _label = "1.0x (Current - Driver Bound — scaling saves <1s)"
                else:
                    _label = "1.0x (Current)"
            elif _m < 1.0:
                _label = f"{_m:.2f}x (Scale Down)"
            else:
                # Confidence indicator: how wide is the prediction range relative to total
                _pred_range_ratio = (_high - _low) / max(1e-9, _pred_total)
                _conf = "v" if _pred_range_ratio < 0.15 else "~"
                if _driver_bottleneck:
                    # Warn that the driver serial fraction caps actual speedup;
                    # this aligns Scale Up labels with the "won't help" recommendation.
                    _label = f"{_m:.1f}x {_conf} (Scale Up — driver-limited ⚠)"
                else:
                    _label = f"{_m:.1f}x {_conf} (Scale Up)"

            out_rows.append({"applicationId": app_id, "dataset": "predictions", "payload_json": json.dumps({
                "Executor Count": int(_N),
                "Executor Multiplier": _label,
                "Estimated Executor WallClock": _wallclock_str,
                "Estimated Total Duration": _duration_str,
                "app_id": app_id
            })})

    # ---- Recommendations ----
    recommendations = []

    avg_task_duration = sum(exec_run_times_sec) / len(exec_run_times_sec) if exec_run_times_sec else 0.0
    max_task_duration = max(exec_run_times_sec) if exec_run_times_sec else 0.0

    if is_streaming_job:
        driver_time_pct = -1.0
        executor_time_pct = -1.0
        driver_bottleneck = False
    else:
        driver_time_pct = (driver_wall_clock_time / max(1e-9, app_duration_sec)) * 100.0
        executor_time_pct = (executor_wall_clock_time / max(1e-9, app_duration_sec)) * 100.0
        # Driver is the bottleneck when it consumes more wall-clock time than
        # the executors — i.e. the job is driver-dominated, not compute-dominated.
        driver_bottleneck = driver_wall_clock_time > executor_wall_clock_time

    job_type_label = "STREAMING" if is_streaming_job else "BATCH"
    detected_issues = []

    # Issue: Low CPU efficiency (batch only — streaming tasks are micro-batches, not long tasks)
    if not is_streaming_job and executor_eff < 0.4:
        severity = 'CRITICAL' if executor_eff < 0.2 else 'HIGH'
        impact_score = (1 - executor_eff) * (200 if severity == 'CRITICAL' else 100) * min(10.0, app_duration_sec / 60.0) * executor_count
        detected_issues.append({
            'category': 'Resource Efficiency - CPU', 'severity': severity,
            'impact_score': impact_score, 'job_type': job_type_label,
            'root_cause': f"Low CPU utilization ({executor_eff:.1%}) - executors spending time on non-CPU work",
            'impact_metrics': f"Wasting {(1-executor_eff)*100:.0f}% of CPU capacity across {executor_count} executors",
            'fix_actions': [
                "Profile code to identify bottlenecks (serialization, I/O wait, locks)",
                "Reduce shuffle operations - minimize data movement",
                "DO NOT scale executors until CPU efficiency improves"
            ]
        })

    # Issue: Memory pressure (batch only)
    if not is_streaming_job and gc_overhead > 0.25:
        severity = 'CRITICAL' if gc_overhead > 0.4 else 'HIGH'
        impact_score = gc_overhead * (300 if severity == 'CRITICAL' else 150) * min(10.0, app_duration_sec / 60.0) * executor_count
        detected_issues.append({
            'category': 'Resource Efficiency - Memory', 'severity': severity,
            'impact_score': impact_score, 'job_type': job_type_label,
            'root_cause': f"High GC overhead ({gc_overhead:.1%}) indicates memory pressure",
            'impact_metrics': f"Losing {gc_overhead*app_duration_sec:.1f}s to garbage collection",
            'fix_actions': [
                "Increase spark.executor.memory by 50-100%",
                "Review caching strategy - use .cache() only when data is reused multiple times",
                "Call .unpersist() explicitly when cached data no longer needed"
            ]
        })

    # Issue: Driver bottleneck (batch only)
    if driver_bottleneck and not is_streaming_job:
        impact_score = (driver_time_pct / 100.0) * 500 * min(10.0, app_duration_sec / 60.0)
        detected_issues.append({
            'category': 'Architecture - Driver Overhead', 'severity': 'CRITICAL',
            'impact_score': impact_score, 'job_type': 'BATCH',
            'root_cause': f"Driver coordination takes {driver_time_pct:.0f}% of runtime - executors idle",
            'impact_metrics': f"Executors idle for {driver_time_pct:.0f}% of job ({driver_wall_clock_time:.0f}s)",
            'fix_actions': [
                "Reduce shuffle stage count with .coalesce() before actions",
                "Use broadcast joins for small tables",
                "Avoid .collect()/.take() on large datasets - use .write() instead",
                "Scaling executors will NOT help - driver is the bottleneck"
            ]
        })

    # Issue: Low parallelism (batch only)
    if not is_streaming_job and parallelism_score < 0.4:
        severity = 'HIGH' if parallelism_score < 0.2 else 'MEDIUM'
        impact_score = (1 - parallelism_score) * min(10.0, executor_count) * (180 if severity == 'HIGH' else 120)
        detected_issues.append({
            'category': 'Architecture - Parallelism', 'severity': severity,
            'impact_score': impact_score, 'job_type': job_type_label,
            'root_cause': f"Low parallelism ({parallelism_score:.1%}) - only {task_count} tasks for {executor_count} executors",
            'impact_metrics': f"Executors underutilized - need 2-4 tasks per executor core",
            'fix_actions': [
                f"Increase spark.sql.shuffle.partitions to at least {executor_count * 4}",
                f"Use .repartition({executor_count * 4}) to increase parallelism"
            ]
        })

    # ---- Streaming-specific issues ----
    # Executor scaling almost never helps streaming jobs. The bottleneck is
    # nearly always trigger interval, state store size, or source throughput.
    # Surface this prominently so operators do not waste CUs scaling out.
    if is_streaming_job:
        # Compute micro-batch variance from the streaming_stats we already collected.
        _batch_durations_ms = [
            float(s.get("batch_duration_ms") or 0)
            for s in streaming_stats
            if (s.get("batch_duration_ms") or 0) > 0
        ]
        _state_memory_bytes = [
            float(s.get("state_memory_bytes") or 0)
            for s in streaming_stats
            if (s.get("state_memory_bytes") or 0) > 0
        ]
        _input_rows = [
            float(s.get("num_input_rows") or 0)
            for s in streaming_stats
        ]
        import statistics as _stats_mod  # used in multiple detection blocks below

        # --- Driver overhead in foreachBatch ---
        # When foreachBatch calls .collect()/.toPandas(), the driver processes all
        # data serially outside Spark parallelism.  This dominates per-batch latency
        # far more than executor count.  Promote to primary when driver > 50% of runtime.
        _streaming_driver_pct = (
            (driver_wall_clock_time / max(1e-9, app_duration_sec)) * 100.0
            if driver_wall_clock_time >= 0
            else 0.0
        )
        # Minimum app_duration (>60 s) and absolute driver time (>10 s) guards prevent spurious
        # triggers on very short streaming jobs where timestamp noise can make
        # driver_wall_clock_time inflate to >50% of runtime.
        if (_streaming_driver_pct > 50.0
                and app_duration_sec > 60.0        # Ignore sub-minute jobs — timestamp noise inflates driver_wall_clock_time.
                and driver_wall_clock_time > 10.0  # Require meaningful absolute time, not just a high ratio.
        ):
            detected_issues.append({
                'category': 'Streaming - Driver Overhead in foreachBatch',
                'severity': 'CRITICAL',
                'impact_score': 99999.0,  # always beats Executor Scaling (9999)
                'job_type': 'STREAMING',
                'root_cause': (
                    f"Driver takes {_streaming_driver_pct:.0f}% of batch runtime — "
                    "foreachBatch likely calls .collect()/.toPandas(), pulling all data to the driver"
                ),
                'impact_metrics': (
                    f"Driver ({driver_wall_clock_time:.0f}s) >> executors ({executor_wall_clock_time:.0f}s). "
                    "Per-batch latency scales linearly with data volume; scaling executors will not help."
                ),
                'fix_actions': [
                    "Remove .collect() / .toPandas() from foreachBatch — process data as a Spark DataFrame",
                    "Write directly inside foreachBatch: batch_df.write.format('delta').mode('append').saveAsTable('output')",
                    "Replace Python loops over collected rows with Spark transformations (map/filter/withColumn)",
                    "If aggregation is needed: use batch_df.groupBy().agg() — not Python-side aggregation on collected rows",
                ]
            })

        # Scaling verdict — always emit, but as informational/last priority
        detected_issues.append({
            'category': 'Streaming - Executor Scaling',
            'severity': 'LOW',
            'impact_score': 50.0,   # below all real streaming issues; renders last
            'job_type': 'STREAMING',
            'root_cause': (
                "Executor scaling has minimal effect on Structured Streaming jobs. "
                "Throughput is bounded by trigger interval, source read rate, and state store I/O — "
                "not executor count."
            ),
            'impact_metrics': (
                "Adding executors increases CU cost without reducing latency or improving throughput "
                "for most streaming workloads."
            ),
            'fix_actions': [
                "Set trigger interval: .trigger(processingTime='10 seconds') — paces batch rate and reduces empty-batch CU waste",
                "For bounded/backfill sources: .trigger(availableNow=True) — processes all available data then stops",
                "Enable RocksDB state store for stateful queries to reduce state I/O overhead: "
                    "spark.sql.streaming.stateStore.providerClass=org.apache.spark.sql.execution.streaming.state.RocksDBStateStoreProvider",
                "Set spark.sql.shuffle.partitions to match source partition count (not executor count)",
                "Use maxOffsetsPerTrigger / maxFilesPerTrigger to cap per-batch data volume",
                "NOTE: Scaling executors only helps when trigger=availableNow AND batch input volume is large "
                    "enough to saturate all cores. For low-throughput or trigger-less jobs, scaling adds CU cost with no benefit.",
            ]
        })

        # Micro-batch variance (backpressure signal)
        if len(_batch_durations_ms) >= 3:
            _median_ms = _stats_mod.median(_batch_durations_ms)
            _p95_ms = sorted(_batch_durations_ms)[int(len(_batch_durations_ms) * 0.95)]
            _variance_ratio = (_p95_ms / _median_ms) if _median_ms > 0 else 1.0
            if _variance_ratio > 3.0:
                _sev = 'CRITICAL' if _variance_ratio > 6.0 else 'HIGH'
                detected_issues.append({
                    'category': 'Streaming - Batch Duration Variance',
                    'severity': _sev,
                    'impact_score': 800.0 * _variance_ratio,
                    'job_type': 'STREAMING',
                    'root_cause': (
                        f"p95 batch duration is {_variance_ratio:.1f}x the median "
                        f"({_p95_ms/1000:.1f}s vs {_median_ms/1000:.1f}s median) — "
                        "indicates backpressure, GC spikes, or uneven source batches."
                    ),
                    'impact_metrics': (
                        f"Slow batches fall behind real-time; processing lag accumulates."
                    ),
                    'fix_actions': [
                        "Reduce maxOffsetsPerTrigger to even out per-batch data volume",
                        "Check source partition count — skewed source partitions cause long batches",
                        "Increase spark.executor.memory if GC spikes co-occur with long batches",
                    ]
                })
            # No trigger interval: continuous-fire batches (median < 500ms, no wide variance)
            elif _median_ms < 500:
                detected_issues.append({
                    'category': 'Streaming - No Trigger Interval Configured',
                    'severity': 'HIGH',
                    'impact_score': 300.0,
                    'job_type': 'STREAMING',
                    'root_cause': (
                        f"Median batch duration is {_median_ms:.0f}ms — "
                        "suggests no trigger interval is set; Spark fires batches as fast as possible"
                    ),
                    'impact_metrics': (
                        "Continuous-fire mode wastes CUs processing empty or near-empty batches "
                        "between data arrival bursts. A trigger interval paces ingestion cost."
                    ),
                    'fix_actions': [
                        "Set a trigger interval: .trigger(processingTime='10 seconds')",
                        "For end-of-day / bounded sources: .trigger(availableNow=True)",
                        "Avoid default (continuous) trigger unless sub-second latency is required",
                    ]
                })

        # State store growth signal
        # Many streaming jobs emit aggregated progress events rather than
        # per-batch state snapshots, yielding only a single _state_memory_bytes entry.
        # Handle that case: if the single observed value exceeds 1000 MB still emit
        # a HIGH warning (not CRITICAL since growth rate is unconfirmed).
        if len(_state_memory_bytes) >= 2:
            _state_first = _state_memory_bytes[0]
            _state_last = _state_memory_bytes[-1]
            _state_growth_ratio = (_state_last / _state_first) if _state_first > 0 else 1.0
            _state_last_mb = _state_last / (1024 * 1024)
            if _state_growth_ratio > 2.0 or _state_last_mb > 500:
                _sev = 'CRITICAL' if (_state_growth_ratio > 5.0 or _state_last_mb > 2000) else 'HIGH'
                detected_issues.append({
                    'category': 'Streaming - State Store Growth',
                    'severity': _sev,
                    'impact_score': 600.0 * min(_state_growth_ratio, 10.0),
                    'job_type': 'STREAMING',
                    'root_cause': (
                        f"State store grew {_state_growth_ratio:.1f}x during this run "
                        f"(last observed: {_state_last_mb:.0f} MB). "
                        "Unbounded state causes OOM and increasing batch latency over time."
                    ),
                    'impact_metrics': (
                        "State store I/O becomes the dominant latency source as state grows; "
                        "eventual OOM kills the query."
                    ),
                    'fix_actions': [
                        "Add watermark to all stateful operations: withWatermark('event_time', '10 minutes')",
                        "Switch to RocksDB state store to spill state to disk: "
                        "spark.sql.streaming.stateStore.providerClass=...RocksDBStateStoreProvider",
                        "Audit aggregation windows — ensure they are bounded, not unbounded",
                    ]
                })
        elif len(_state_memory_bytes) == 1:  # Single observation — growth rate cannot be confirmed.
            _state_only_mb = _state_memory_bytes[0] / (1024 * 1024)
            if _state_only_mb > 1000:  # 1 GB threshold for the single-observation case.
                detected_issues.append({
                    'category': 'Streaming - State Store Growth',
                    'severity': 'HIGH',  # HIGH not CRITICAL: growth rate is unconfirmed from a single snapshot.
                    'impact_score': 600.0,
                    'job_type': 'STREAMING',
                    'root_cause': (
                        f"State store is large ({_state_only_mb:.0f} MB observed in a single measurement). "
                        "Growth rate cannot be confirmed from one snapshot, but high absolute state "
                        "size risks OOM and increasing batch latency over time."
                    ),
                    'impact_metrics': (
                        "Large state store I/O can become the dominant latency source; "
                        "unbounded state eventually causes OOM."
                    ),
                    'fix_actions': [
                        "Add watermark to all stateful operations: withWatermark('event_time', '10 minutes')",
                        "Switch to RocksDB state store to spill state to disk: "
                        "spark.sql.streaming.stateStore.providerClass=...RocksDBStateStoreProvider",
                        "Audit aggregation windows — ensure they are bounded, not unbounded",
                    ]
                })

    detected_issues.sort(key=lambda x: x['impact_score'], reverse=True)

    # --- Wound-down streaming job: all batch metrics are idle-poll noise ---
    # Suppress every performance recommendation and surface a single diagnostic
    # message so operators know to re-run while the query is active.
    if is_streaming_job and _is_wound_down:
        _wound_down_rec = (
            f"WOUND-DOWN STREAMING JOB — All {len(streaming_stats)} recorded batches have "
            f"0 input rows and 0 state rows. The streaming query had already stopped processing "
            f"before this analysis window. Batch timing reflects idle trigger cycles (~1 s each), "
            f"not active processing. Re-run the analyzer while the streaming query is active "
            f"for meaningful performance analysis."
        )
        out_rows.append({"applicationId": app_id, "dataset": "recommendations", "payload_json": json.dumps({
            "app_id": app_id, "recommendation": _wound_down_rec
        })})
        return pd.DataFrame(out_rows)

    # ---- Streaming completed-job signals ----
    # These fire only when not wound-down (at least some batches had real work).
    # They analyse the historical batch data in streaming_stats and append
    # both metrics rows and recommendation text before the final recommendation
    # assembly below.
    if is_streaming_job and not _is_wound_down:
        _STREAMING_MIN_BATCHES = 5

        # Re-use _active_batches already computed during wound-down detection.
        # Guard: if somehow not defined (non-streaming path), fall back to empty.
        _sig_active = [
            s for s in streaming_stats
            if s.get("state_rows_total", 0) > 0
            or s.get("num_input_rows", 0) > 0
            or (s.get("batch_duration_ms") or 0) > 2000
        ]
        _has_input_history = any(s.get("num_input_rows", 0) > 0 for s in _sig_active)
        _has_state_history  = any(s.get("state_rows_total", 0) > 0 for s in _sig_active)
        _enough_batches    = len(_sig_active) >= _STREAMING_MIN_BATCHES

        # Helper: append a metrics row to out_rows.
        def _sm(key, val):
            out_rows.append({"applicationId": app_id, "dataset": "metrics",
                             "payload_json": json.dumps({"app_id": app_id,
                                                         "metric": key,
                                                         "value": float(val)})})

        # ---- Signal 1: Batch Duration Variance ----
        if _enough_batches:
            _s1_durations = sorted(
                float(s["batch_duration_ms"])
                for s in _sig_active
                if (s.get("batch_duration_ms") or 0) > 0
            )
            if _s1_durations:
                _s1_n      = len(_s1_durations)
                _s1_median = _s1_durations[_s1_n // 2]
                _s1_p95    = _s1_durations[min(int(_s1_n * 0.95), _s1_n - 1)]
                _s1_p99    = _s1_durations[min(int(_s1_n * 0.99), _s1_n - 1)]
                _s1_mean   = sum(_s1_durations) / _s1_n
                _s1_cv     = (sum((d - _s1_mean) ** 2 for d in _s1_durations) / _s1_n) ** 0.5 / _s1_mean if _s1_mean > 0 else 0.0
                _s1_ratio  = _s1_p95 / _s1_median if _s1_median > 0 else 0.0

                _sm("Streaming: Median Batch Duration (ms)", _s1_median)
                _sm("Streaming: P95 Batch Duration (ms)",    _s1_p95)
                _sm("Streaming: P95/Median Ratio",           _s1_ratio)
                _sm("Streaming: Batch Duration CV",          _s1_cv)

                if _s1_ratio > 5.0:
                    recommendations.append(
                        f"[Streaming - Batch Duration Variance] HIGH: "
                        f"Batch duration is highly unstable: median {_s1_median:.0f}ms but p95 is "
                        f"{_s1_p95:.0f}ms ({_s1_ratio:.1f}x higher); p99 is {_s1_p99:.0f}ms. "
                        f"Investigate GC logs for the slowest batches and check for data skew "
                        f"in stateful operations."
                    )
                elif _s1_ratio > 3.0:
                    recommendations.append(
                        f"[Streaming - Batch Duration Variance] MEDIUM: "
                        f"Moderate batch duration variance: median {_s1_median:.0f}ms, "
                        f"p95 {_s1_p95:.0f}ms ({_s1_ratio:.1f}x). "
                        f"Occasional slow batches may cause latency spikes. "
                        f"Review trigger interval and state store checkpoint frequency."
                    )
                elif _s1_cv > 0.5:
                    recommendations.append(
                        f"[Streaming - Batch Duration Variance] LOW: "
                        f"Minor batch duration variance (CV={_s1_cv:.2f}): "
                        f"median {_s1_median:.0f}ms, p95 {_s1_p95:.0f}ms. Processing is mostly stable."
                    )

        # ---- Signal 2: State Growth Trend ----
        if _has_state_history:
            _s2_batches = sorted(
                (s for s in _sig_active if s.get("state_rows_total", 0) > 0),
                key=lambda s: s.get("batch_id", 0)
            )
            if _s2_batches:
                _s2_vals   = [s["state_rows_total"] for s in _s2_batches]
                _s2_mem    = [s.get("state_memory_bytes", 0) for s in _s2_batches]
                _s2_max    = max(_s2_vals)
                _s2_final  = _s2_vals[-1]
                _s2_mem_kb = max(_s2_mem) / 1024 if _s2_mem else 0.0
                _s2_third  = max(1, len(_s2_vals) // 3)
                _s2_early  = sum(_s2_vals[:_s2_third]) / _s2_third
                _s2_late   = sum(_s2_vals[-_s2_third:]) / _s2_third
                _s2_growth = _s2_late / _s2_early if _s2_early > 0 else 1.0
                _s2_peak_i = _s2_vals.index(max(_s2_vals))
                _s2_drained = _s2_peak_i > 0 and _s2_final < _s2_vals[_s2_peak_i] * 0.5

                _sm("Streaming: Max State Rows",        _s2_max)
                _sm("Streaming: Max State Memory (KB)", _s2_mem_kb)
                _sm("Streaming: State Growth Ratio",    _s2_growth)
                _sm("Streaming: State Drained",         1.0 if _s2_drained else 0.0)

                if _s2_drained:
                    pass  # Healthy — state grew then drained (bounded window); metrics only.
                elif _s2_growth > 2.0:
                    recommendations.append(
                        f"[Streaming - State Growth] HIGH: "
                        f"State is growing unbounded: early batches averaged {_s2_early:.0f} rows, "
                        f"late batches averaged {_s2_late:.0f} rows ({_s2_growth:.1f}x growth). "
                        f"Peak: {_s2_max} rows ({_s2_mem_kb:.0f} KB). "
                        f"Without watermarking or TTL this will cause OOM. "
                        f"Add withWatermark() to all stateful operations and verify state cleanup."
                    )
                elif _s2_growth > 1.3:
                    recommendations.append(
                        f"[Streaming - State Growth] MEDIUM: "
                        f"State is slowly growing: {_s2_early:.0f} rows early vs "
                        f"{_s2_late:.0f} rows late ({_s2_growth:.1f}x). "
                        f"Peak: {_s2_max} rows ({_s2_mem_kb:.0f} KB). "
                        f"Monitor over longer runs. "
                        f"Verify watermark is set for all stateful aggregations."
                    )

        # ---- Signal 3: Processing Rate vs Trigger Interval ----
        if _enough_batches:
            # Infer trigger interval from the median duration of idle batches
            # (0 input, 0 state) — these represent the raw polling cadence.
            _s3_idle_durations = sorted(
                float(s["batch_duration_ms"])
                for s in streaming_stats
                if s.get("num_input_rows", 0) == 0
                and s.get("state_rows_total", 0) == 0
                and (s.get("batch_duration_ms") or 0) > 0
            )
            _s3_trigger_ms = (
                _s3_idle_durations[len(_s3_idle_durations) // 2]
                if len(_s3_idle_durations) >= 10
                else None
            )
            if _s3_trigger_ms:
                _s3_active_dur = sorted(
                    float(s["batch_duration_ms"])
                    for s in _sig_active if (s.get("batch_duration_ms") or 0) > 0
                )
                if _s3_active_dur:
                    _s3_median_active = _s3_active_dur[len(_s3_active_dur) // 2]
                    _s3_ratio = _s3_median_active / _s3_trigger_ms

                    _sm("Streaming: Inferred Trigger Interval (ms)",    _s3_trigger_ms)
                    _sm("Streaming: Processing/Trigger Ratio",          _s3_ratio)
                    _sm("Streaming: Median Active Batch Duration (ms)", _s3_median_active)

                    if _s3_ratio > 1.5:
                        recommendations.append(
                            f"[Streaming - Processing vs Trigger] HIGH: "
                            f"Job is falling behind: median processing time {_s3_median_active:.0f}ms "
                            f"exceeds inferred trigger interval ~{_s3_trigger_ms:.0f}ms ({_s3_ratio:.1f}x). "
                            f"Data lag will grow continuously. "
                            f"Options: add executors, reduce stateful operation complexity, "
                            f"increase trigger interval, or repartition input for better parallelism."
                        )
                    elif _s3_ratio > 1.0:
                        recommendations.append(
                            f"[Streaming - Processing vs Trigger] MEDIUM: "
                            f"Job is marginally behind trigger interval: "
                            f"median processing {_s3_median_active:.0f}ms vs "
                            f"trigger ~{_s3_trigger_ms:.0f}ms (ratio {_s3_ratio:.2f}). "
                            f"Under increased load this job will fall behind — consider adding headroom."
                        )

        # ---- Signal 4: Micro-Batch Duration Outliers ----
        if _enough_batches:
            _s4_dur_map = {
                s.get("batch_id"): float(s["batch_duration_ms"])
                for s in _sig_active
                if (s.get("batch_duration_ms") or 0) > 0
                and s.get("batch_id") is not None
            }
            if _s4_dur_map:
                _s4_median = sorted(_s4_dur_map.values())[len(_s4_dur_map) // 2]
                _s4_outliers = sorted(
                    ((bid, dur) for bid, dur in _s4_dur_map.items() if dur > _s4_median * 3.0),
                    key=lambda x: x[1], reverse=True
                )
                if _s4_outliers:
                    _s4_top     = _s4_outliers[:5]
                    _s4_pct     = len(_s4_outliers) / len(_s4_dur_map) * 100
                    _s4_wid, _s4_wdur = _s4_top[0]
                    _s4_sev     = "HIGH" if _s4_pct > 10 else ("MEDIUM" if _s4_pct > 3 else "LOW")
                    _s4_list    = ", ".join(f"batch {bid} ({dur:.0f}ms)" for bid, dur in _s4_top)

                    _sm("Streaming: Outlier Batch Count",         float(len(_s4_outliers)))
                    _sm("Streaming: Outlier Batch Pct",           _s4_pct)
                    _sm("Streaming: Worst Outlier Batch ID",      float(_s4_wid))
                    _sm("Streaming: Worst Outlier Duration (ms)", _s4_wdur)

                    recommendations.append(
                        f"[Streaming - Outlier Batches] {_s4_sev}: "
                        f"{len(_s4_outliers)} of {len(_s4_dur_map)} active batches "
                        f"({_s4_pct:.1f}%) took >3x the median ({_s4_median:.0f}ms). "
                        f"Worst: {_s4_list}. "
                        f"Slow batches indicate GC pauses, state store checkpoint stalls, "
                        f"or task skew. "
                        f"Investigate batch {_s4_wid} in Spark UI event history "
                        f"for long-running tasks or GC events."
                    )

        # ---- Signal 5: Input Rate vs Processing Rate ----
        if _has_input_history and _enough_batches:
            _s5_batches = [
                s for s in _sig_active
                if s.get("num_input_rows", 0) > 0
                and (s.get("input_rows_per_second") or 0) > 0
                and (s.get("processed_rows_per_second") or 0) > 0
            ]
            if len(_s5_batches) >= _STREAMING_MIN_BATCHES:
                _s5_in_rates   = [float(s["input_rows_per_second"]) for s in _s5_batches]
                _s5_proc_rates = [float(s["processed_rows_per_second"]) for s in _s5_batches]
                _s5_avg_in     = sum(_s5_in_rates) / len(_s5_in_rates)
                _s5_avg_proc   = sum(_s5_proc_rates) / len(_s5_proc_rates)
                _s5_total_rows = sum(s.get("num_input_rows", 0) for s in _s5_batches)
                _s5_ratio      = _s5_avg_proc / _s5_avg_in if _s5_avg_in > 0 else 1.0

                _sm("Streaming: Avg Input Rate (rows/sec)",      _s5_avg_in)
                _sm("Streaming: Avg Processing Rate (rows/sec)", _s5_avg_proc)
                _sm("Streaming: Rate Ratio",                     _s5_ratio)
                _sm("Streaming: Total Input Rows",               float(_s5_total_rows))

                if _s5_ratio < 0.8:
                    recommendations.append(
                        f"[Streaming - Input vs Processing Rate] HIGH: "
                        f"Job is processing rows slower than they arrive: "
                        f"avg input {_s5_avg_in:.0f} rows/sec, "
                        f"avg processing {_s5_avg_proc:.0f} rows/sec (ratio {_s5_ratio:.2f}). "
                        f"Lag is accumulating. Total rows processed: {_s5_total_rows:,}. "
                        f"Add executors or optimise processing logic to close the gap."
                    )
                elif _s5_ratio < 0.95:
                    recommendations.append(
                        f"[Streaming - Input vs Processing Rate] MEDIUM: "
                        f"Processing rate is close to input rate "
                        f"({_s5_avg_proc:.0f} vs {_s5_avg_in:.0f} rows/sec, ratio {_s5_ratio:.2f}). "
                        f"Little headroom — spikes in input volume will cause lag."
                    )

    if detected_issues:
        primary = detected_issues[0]
        recommendations.append(f"PRIMARY ISSUE: {primary['category']} [{primary['severity']}]")
        recommendations.append(f"Root Cause: {primary['root_cause']}")
        recommendations.append(f"Impact: {primary['impact_metrics']}")
        for i, action in enumerate(primary['fix_actions'], 1):
            recommendations.append(f"  Fix {i}: {action}")
        if len(detected_issues) > 1:
            recommendations.append(f"\nSECONDARY ISSUES ({len(detected_issues)-1} total):")
            for i, issue in enumerate(detected_issues[1:4], 1):
                recommendations.append(f"  {i}. {issue['category']} [{issue['severity']}]: {issue['root_cause']}")
                recommendations.append(f"     Fix: {issue['fix_actions'][0]}")
    else:
        recommendations.append("No critical performance issues detected.")

    if not is_streaming_job:
        performance_score = (
            (executor_eff * 30) + (parallelism_score * 30) +
            ((1.0 - min(1.0, gc_overhead)) * 20) + ((1.0 / max(1.0, task_skew)) * 20)
        )
        summary_text = "EXCELLENT" if performance_score > 75 else ("GOOD" if performance_score > 50 else "NEEDS OPTIMIZATION")
        recommendations.append(
            f"\nPERFORMANCE SUMMARY: {summary_text} ({performance_score:.0f}/100) | "
            f"CPU: {executor_eff:.1%} | Parallelism: {parallelism_score:.1%} | "
            f"GC: {gc_overhead:.1%} | Skew: {task_skew:.1f}x"
        )

    for recommendation_text in recommendations:
        out_rows.append({"applicationId": app_id, "dataset": "recommendations", "payload_json": json.dumps({
            "app_id": app_id, "recommendation": recommendation_text
        })})

    return pd.DataFrame(out_rows)

# -------------------------------------------
# Step 5: Chunked incremental processing
# -------------------------------------------
# Each chunk reads ONLY the logs for CHUNK_SIZE apps from Kusto,
# processes them, writes results immediately, then releases memory.
# This keeps the Spark memory footprint bounded regardless of total
# dataset size — no full-table .cache() anywhere on raw data.
# -------------------------------------------
if unprocessed_ids:
    total_chunks = (len(unprocessed_ids) + CHUNK_SIZE - 1) // CHUNK_SIZE
    print(f"\nProcessing {len(unprocessed_ids)} apps in {total_chunks} chunk(s) of ≤{CHUNK_SIZE}...")

    solo_queue: list = []  # oversized apps deferred to solo (chunk_size=1) processing
    # Note: spark.rpc.message.maxSize is a static config and cannot be changed at runtime.
    # RPC overflow is avoided by the collect→createDataFrame lineage break instead.

    for chunk_idx, app_id_chunk in enumerate(_chunked(unprocessed_ids, CHUNK_SIZE), start=1):
        print(f"\n{'─'*60}")
        print(f"Chunk {chunk_idx}/{total_chunks}  ({len(app_id_chunk)} apps)")
        print(f"{'─'*60}")

        # Build KQL IN-list for this chunk
        app_list_kql = ", ".join([f'"{aid}"' for aid in app_id_chunk])

        # Base query — scoped to this chunk only.
        # category and applicationId are nested inside the records JSON field.
        chunk_query = f"""
        RawLogs
        | extend _cat = tostring(parse_json(records).category)
        | extend _app = tostring(parse_json(records).applicationId)
        | where _cat == "EventLog"
        | where _app in ({app_list_kql})
        | where isnotnull(_app) and _app != ""
        | project records, applicationId = _app
        """

        # Step A: Row count guard — split oversized apps into solo_queue,
        # trim app_id_chunk to safe apps only, then skip if nothing remains.
        try:
            _count_kql = f"""
            RawLogs
            | extend _cat = tostring(parse_json(records).category)
            | extend _app = tostring(parse_json(records).applicationId)
            | where _cat == "EventLog"
            | where _app in ({app_list_kql})
            | summarize row_count = count() by applicationId = _app
            """
            _normal_apps = list(app_id_chunk)
            _large_apps = []
            for _cr in read_kusto_df_small(_count_kql).collect():
                _cr_count = int(_cr["row_count"] or 0)
                _cr_app = _cr["applicationId"] or "unknown"
                if _cr_count > 5_000_000:
                    print(f"  [WARN] App {_cr_app} has {_cr_count:,} event log rows — deferring to solo queue.")
                    _large_apps.append(_cr_app)
                    _normal_apps = [a for a in _normal_apps if a != _cr_app]

            if _large_apps:
                solo_queue.extend(_large_apps)

            if not _normal_apps:
                print("  All apps in this chunk are oversized — deferred to solo queue, skipping chunk")
                continue

            # Trim chunk to safe apps; rebuild base query
            app_id_chunk = _normal_apps
            app_list_kql = ", ".join([f'"{aid}"' for aid in app_id_chunk])
            chunk_query = f"""
            RawLogs
            | extend _cat = tostring(parse_json(records).category)
            | extend _app = tostring(parse_json(records).applicationId)
            | where _cat == "EventLog"
            | where _app in ({app_list_kql})
            | where isnotnull(_app) and _app != ""
            | project records, applicationId = _app
            """

        except Exception as _cnt_err:
            print(f"  [WARN] Row count guard failed ({_cnt_err}); proceeding without check")

        # Step B: Narrow the Kusto time range scan with ingestion_time() bounds.
        # Runs after the row count guard so it operates on the trimmed app list.
        try:
            ts_query = f"""
            RawLogs
            | extend _cat = tostring(parse_json(records).category)
            | extend _app = tostring(parse_json(records).applicationId)
            | where _cat == "EventLog"
            | where _app in ({app_list_kql})
            | summarize min_ts = min(ingestion_time()), max_ts = max(ingestion_time())
            """
            ts_rows = read_kusto_df_small(ts_query).collect()
            if ts_rows and ts_rows[0]["min_ts"] is not None:
                min_ts = ts_rows[0]["min_ts"]
                max_ts = ts_rows[0]["max_ts"]
                chunk_query = f"""
                RawLogs
                | where ingestion_time() between (datetime({min_ts}) .. datetime({max_ts}))
                | extend _cat = tostring(parse_json(records).category)
                | extend _app = tostring(parse_json(records).applicationId)
                | where _cat == "EventLog"
                | where _app in ({app_list_kql})
                | where isnotnull(_app) and _app != ""
                | project records, applicationId = _app
                """
                print(f"  Time-scoped query: {min_ts} → {max_ts}")
        except Exception as _ts_err:
            print(f"  Time-scope query failed ({_ts_err}), using base query")

        # Collect raw event rows to driver (bounded by CHUNK_SIZE apps, all normal-sized
        # after the row count guard).  This breaks the Kusto connector lineage so that
        # result_df.persist() in _write_chunk_results does NOT walk back to Kusto and
        # does NOT trigger exportPartitionToBlob / 0x80DA0007.
        print(f"  Fetching {len(app_id_chunk)} application(s) from Kusto...")
        _raw_rows = read_kusto_df(chunk_query).collect()
        if not _raw_rows:
            print("  No event rows returned for this chunk — skipping")
            continue
        _chunk_input = [
            {
                "records": str(r["records"] or ""),
                "applicationId": str(r["applicationId"] or ""),
            }
            for r in _raw_rows
        ]
        del _raw_rows
        # Group by applicationId and process each app directly on the driver.
        # Avoids Spark shuffle (applyInPandas) entirely — no task serialization,
        # no RPC task-size limit regardless of per-app event volume.
        _groups: dict = {}
        for _row in _chunk_input:
            _aid = _row["applicationId"]
            if _aid not in _groups:
                _groups[_aid] = []
            _groups[_aid].append(_row)
        del _chunk_input
        print(f"  Processing {len(app_id_chunk)} application(s) on driver...")
        _app_results = []
        for _aid, _app_rows in _groups.items():
            _app_pdf = pd.DataFrame(_app_rows)
            _app_results.append(per_app_analyzer(_app_pdf))
        del _groups
        if not _app_results:
            print("  No analysis results produced — skipping")
            continue
        _result_pdf = pd.concat(_app_results, ignore_index=True)
        result_df = spark.createDataFrame(_result_pdf, schema=OUTPUT_SCHEMA)
        del _app_results, _result_pdf

        # Write all tables for this chunk immediately
        print("  Writing results to Kusto...")
        _write_chunk_results(result_df)

        # Release memory before next chunk
        del result_df
        print(f"  Chunk {chunk_idx}/{total_chunks} complete ✓")

    # --- Solo queue: process each oversized app individually (chunk_size=1) ---
    if solo_queue:
        print(f"\n{'='*60}")
        print(f"Processing {len(solo_queue)} oversized app(s) from solo queue (chunk_size=1)...")
        print(f"{'='*60}")
        for _sq_idx, _sq_app in enumerate(solo_queue, start=1):
            print(f"\n{'─'*60}")
            print(f"Solo {_sq_idx}/{len(solo_queue)}  ({_sq_app})")
            print(f"{'─'*60}")
            _sq_app_kql = f'"{_sq_app}"'
            _sq_query = f"""
            RawLogs
            | extend _cat = tostring(parse_json(records).category)
            | extend _app = tostring(parse_json(records).applicationId)
            | where _cat == "EventLog"
            | where _app in ({_sq_app_kql})
            | where isnotnull(_app) and _app != ""
            | project records, applicationId = _app
            """
            try:
                _sq_ts_query = f"""
                RawLogs
                | extend _cat = tostring(parse_json(records).category)
                | extend _app = tostring(parse_json(records).applicationId)
                | where _cat == "EventLog"
                | where _app in ({_sq_app_kql})
                | summarize min_ts = min(ingestion_time()), max_ts = max(ingestion_time())
                """
                _sq_ts_rows = read_kusto_df_small(_sq_ts_query).collect()
                if _sq_ts_rows and _sq_ts_rows[0]["min_ts"] is not None:
                    _sq_min_ts = _sq_ts_rows[0]["min_ts"]
                    _sq_max_ts = _sq_ts_rows[0]["max_ts"]
                    _sq_query = f"""
                    RawLogs
                    | where ingestion_time() between (datetime({_sq_min_ts}) .. datetime({_sq_max_ts}))
                    | extend _cat = tostring(parse_json(records).category)
                    | extend _app = tostring(parse_json(records).applicationId)
                    | where _cat == "EventLog"
                    | where _app in ({_sq_app_kql})
                    | where isnotnull(_app) and _app != ""
                    | project records, applicationId = _app
                    """
                    print(f"  Time-scoped query: {_sq_min_ts} → {_sq_max_ts}")
            except Exception as _sq_ts_err:
                print(f"  Time-scope query failed ({_sq_ts_err}), using base query")

            print(f"  Fetching {_sq_app} from Kusto...")
            _sq_raw_rows = read_kusto_df(_sq_query).collect()
            if not _sq_raw_rows:
                print(f"  No event rows returned for {_sq_app} — skipping")
                continue
            _sq_input = [
                {
                    "records": str(r["records"] or ""),
                    "applicationId": str(r["applicationId"] or ""),
                }
                for r in _sq_raw_rows
            ]
            del _sq_raw_rows
            # Same driver-side processing as main loop — no Spark shuffle.
            print(f"  Processing {_sq_app} on driver...")
            _sq_pdf = pd.DataFrame(_sq_input)
            del _sq_input
            _sq_result_pdf = per_app_analyzer(_sq_pdf)
            del _sq_pdf
            _sq_result_df = spark.createDataFrame(_sq_result_pdf, schema=OUTPUT_SCHEMA)
            del _sq_result_pdf
            print("  Writing results to Kusto...")
            _write_chunk_results(_sq_result_df)
            del _sq_result_df
            print(f"  Solo {_sq_idx}/{len(solo_queue)} complete ✓")

    print(f"\n{'='*60}")
    print(f"ALL CHUNKS COMPLETE — {len(unprocessed_ids)} applications processed")
    print(f"{'='*60}")
'''),
]


