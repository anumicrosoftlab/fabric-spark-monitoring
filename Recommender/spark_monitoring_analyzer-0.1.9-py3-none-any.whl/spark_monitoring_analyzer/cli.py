import argparse
import logging

from spark_monitoring_analyzer.analyzer import run


def main(argv=None) -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s - %(message)s",
    )

    parser = argparse.ArgumentParser(
        prog="spark-monitoring-analyzer",
        description="Run Spark Monitoring Analyzer against Kusto tables.",
    )
    parser.add_argument("--kusto-uri", required=True, help="Kusto cluster URI")
    parser.add_argument("--database", required=True, help="Kusto database name")
    args = parser.parse_args(argv)

    run(kusto_uri=args.kusto_uri, database=args.database)