"""spark_monitoring_analyzer

Public package surface:
- `run(kusto_uri, database)`

All Spark/Kusto analysis logic is executed from the embedded notebook cells.
"""

from __future__ import annotations

from .analyzer import (
    clear_recommendation_rules,
    register_recommendation_rule,
    run,
)

__all__ = [
    "run",
    "register_recommendation_rule",
    "clear_recommendation_rules",
]
