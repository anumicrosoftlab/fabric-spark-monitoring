"""spark_monitoring_analyzer.analyzer

Production wrapper around the original Jupyter notebook logic.

CRITICAL:
- The notebook code is embedded verbatim (cell sources are copied line-for-line).
- Execution is performed cell-by-cell via `exec` to preserve notebook semantics,
  including re-definitions (the last definition wins, same as running the notebook).

Entry points:
- Python API: `run(kusto_uri, database)`

This package is intended to run inside Microsoft Fabric / Synapse Spark where
`spark` and `mssparkutils` are available.
"""

from __future__ import annotations

import logging
import builtins
import importlib
import json
import re
from collections.abc import Callable
from typing import Any

logger = logging.getLogger(__name__)


# ------------------------------
# Recommendation rule registry
# ------------------------------
#
# Requirement: Do NOT modify the existing notebook function
# `generate_enhanced_recommendations()`. Instead, we install a wrapper *at runtime*
# so the original logic runs first, then any registered rules can append extras.
#
# IMPORTANT: Registry is empty by default, so baseline behavior is unchanged.

RecommendationRule = Callable[[dict[str, Any], Any], Any | None]

_RECOMMENDATION_RULES: list[RecommendationRule] = []


def register_recommendation_rule(rule: RecommendationRule) -> None:
    """Register an extra recommendation rule.

    Rules are executed after the notebook's `generate_enhanced_recommendations`.
    The rule receives:
      - `ns`: the shared notebook execution namespace
      - `base`: the base recommendations object produced by the notebook

    Return `None` to add nothing.
    """

    _RECOMMENDATION_RULES.append(rule)


def clear_recommendation_rules() -> None:
    """Remove all registered recommendation rules."""

    _RECOMMENDATION_RULES.clear()


def _combine_recommendations(base: Any, extra: Any) -> Any:
    """Best-effort combine without impacting baseline behavior.

    If combination fails, `base` is returned unchanged.
    """

    if extra is None:
        return base

    # Spark DataFrame: try unionByName then union
    for method_name in ("unionByName", "union"):
        method = getattr(base, method_name, None)
        if callable(method):
            try:
                if method_name == "unionByName":
                    try:
                        return method(extra, allowMissingColumns=True)
                    except TypeError:
                        return method(extra)
                return method(extra)
            except Exception:
                logger.exception("Failed combining recommendations via %s", method_name)
                return base

    # Python list-like
    if isinstance(base, list):
        if isinstance(extra, list):
            return base + extra
        return base + [extra]

    return base


def _install_generate_wrapper(ns: dict[str, Any]) -> None:
    """Install wrapper into the notebook namespace if available."""

    fn = ns.get("generate_enhanced_recommendations")
    if not callable(fn):
        return

    # Idempotent: avoid re-wrapping
    if ns.get("_sma_generate_wrapped") is fn:
        return

    base_fn = fn

    def _wrapped_generate_enhanced_recommendations(*args: Any, **kwargs: Any) -> Any:
        base = base_fn(*args, **kwargs)
        if not _RECOMMENDATION_RULES:
            return base

        combined = base
        for rule in list(_RECOMMENDATION_RULES):
            try:
                extra = rule(ns, base)
                combined = _combine_recommendations(combined, extra)
            except Exception:
                logger.exception("Recommendation rule failed: %r", rule)
        return combined

    ns["generate_enhanced_recommendations"] = _wrapped_generate_enhanced_recommendations
    ns["_sma_generate_wrapped"] = _wrapped_generate_enhanced_recommendations


# ------------------------------
# Plain-text recommendation formatting
# ------------------------------

_SEVERITY_EMOJI: dict[str, str] = {
    "CRITICAL": "🔴",
    "HIGH": "🟡",
    "MEDIUM": "🔵",
    "LOW": "⚫",
}


def _severity_emoji(severity: str) -> str:
    return _SEVERITY_EMOJI.get(str(severity).strip().upper(), "⚫")


def _metric_health_cpu(executor_eff: float) -> str:
    if executor_eff < 0.40:
        return "🔴"
    if executor_eff <= 0.70:
        return "🟡"
    return "✅"


def _metric_health_gc(gc_overhead: float) -> str:
    if gc_overhead > 0.10:
        return "🔴"
    if gc_overhead >= 0.05:
        return "🟡"
    return "✅"


def _metric_health_skew(skew: float) -> str:
    if skew > 3.0:
        return "🔴"
    if skew >= 1.5:
        return "🟡"
    return "✅"


def _metric_health_parallelism(parallelism: float) -> str:
    if parallelism < 0.50:
        return "🔴"
    if parallelism <= 0.80:
        return "🟡"
    return "✅"


def _score_grade(score: int) -> tuple[str, str]:
    """Return (emoji, label) for the performance score."""

    if score >= 80:
        return "✅", "EXCELLENT"
    if score >= 65:
        return "🟡", "GOOD"
    if score >= 50:
        return "🔵", "FAIR"
    return "🔴", "POOR"


def _skew_penalty_points(task_skew_ratio: float) -> int:
    """Penalty points applied to performance score for extreme skew.

    Spec:
      - Skew < 2x  -> 0
      - Skew 2–5x  -> 5
      - Skew 5–10x -> 15
      - Skew > 10x -> 25

    This is applied after any existing penalties in the notebook-produced score.
    """

    try:
        v = float(task_skew_ratio)
    except Exception:
        return 0

    if v < 2.0:
        return 0
    if v <= 5.0:
        return 5
    if v <= 10.0:
        return 15
    return 25


def _normalize_line(s: str) -> str:
    s = (s or "").strip("\n")

    # Remove the common " - " bullet artifacts.
    s = s.strip()
    if s.startswith("-"):
        s = s.lstrip("-").strip()

    # Collapse multiple spaces while preserving intentional indentation.
    if s and not s.startswith(" "):
        s = re.sub(r"\s{2,}", " ", s)
    return s


def _fix_executor_pluralization(text: str) -> str:
        """Fix executor/executors pluralization in narrative prose.

        Examples:
            - "across 1 executors" -> "across 1 executor"
            - "across 2 executor"  -> "across 2 executors"
        """

        s = text or ""
        # Fix common incorrect pluralization.
        s = re.sub(r"\b1\s+executors\b", "1 executor", s)
        s = re.sub(r"\b([2-9]\d*)\s+executor\b", r"\1 executors", s)
        s = re.sub(r"\b0\s+executor\b", "0 executors", s)
        return s


def _normalize_body_text(s: str) -> str:
    # Narrative text reads better with an em dash.
    normalized = _normalize_line(s).replace(" - ", " — ")
    return _fix_executor_pluralization(normalized)


def _format_plaintext_recommendation_block(lines: list[str], job_type: str | None = None) -> str:
    """Format the notebook-generated recommendation lines into a single plain-text block.

    This intentionally uses only Unicode box/line drawing and emoji (no HTML/Markdown).
    """

    cleaned = [_normalize_line(x) for x in (lines or []) if str(x or "").strip()]

    primary_category = "No critical performance issues detected."
    primary_severity = "LOW"
    root_cause = "No critical performance issues detected."
    impact = "N/A"
    job_type_label = (job_type or "").strip().upper()
    if job_type_label not in {"BATCH", "STREAMING"}:
        job_type_label = ""
    fixes_by_num: dict[int, str] = {}

    secondary: list[dict[str, str]] = []

    score_val: int | None = None
    cpu_pct: float | None = None
    parallel_pct: float | None = None
    gc_pct: float | None = None
    skew_val: float | None = None

    i = 0
    while i < len(cleaned):
        line = cleaned[i]

        if line.startswith("PRIMARY ISSUE:"):
            m = re.match(r"^PRIMARY ISSUE:\s*(.*?)\s*\[(CRITICAL|HIGH|MEDIUM|LOW)\]\s*$", line)
            if m:
                primary_category = m.group(1).strip()
                primary_severity = m.group(2).strip().upper()
            else:
                primary_category = line.split(":", 1)[-1].strip()
        elif line.startswith("Root Cause:"):
            root_cause = line.split(":", 1)[-1].strip()
        elif line.startswith("Impact:"):
            impact = line.split(":", 1)[-1].strip()
        else:
            m_fix = re.match(r"^Fix\s+(\d+)\s*:\s*(.*)$", line)
            if m_fix:
                try:
                    num = int(m_fix.group(1))
                except Exception:
                    num = len(fixes_by_num) + 1
                fixes_by_num[num] = m_fix.group(2).strip()
            else:
                # Secondary issue line format:
                # "1. Category [HIGH]: Root cause..."
                m_sec = re.match(
                    r"^(\d+)\.\s+(.*?)\s+\[(CRITICAL|HIGH|MEDIUM|LOW)\]\s*:\s*(.*)$",
                    line,
                )
                if m_sec:
                    try:
                        sec_idx = int(m_sec.group(1))
                    except Exception:
                        sec_idx = len(secondary) + 1
                    sec: dict[str, str] = {
                        "idx": str(sec_idx),
                        "category": m_sec.group(2).strip(),
                        "severity": m_sec.group(3).strip().upper(),
                        "cause": m_sec.group(4).strip(),
                        "fix": "",
                    }
                    # Next line is typically "Fix: ..."
                    if i + 1 < len(cleaned) and cleaned[i + 1].startswith("Fix:"):
                        sec["fix"] = cleaned[i + 1].split(":", 1)[-1].strip()
                        i += 1
                    secondary.append(sec)
                elif line.startswith("PERFORMANCE SUMMARY:"):
                    # Example:
                    # PERFORMANCE SUMMARY: EXCELLENT (76/100) | CPU: 27.6% | Parallelism: 100.0% | GC: 2.6% | Skew: 1.1x
                    # Grade text is ignored; we recompute based on numeric score thresholds.
                    m_score = re.search(r"\((\d+)\s*/\s*100\)", line)
                    if m_score:
                        try:
                            score_val = int(m_score.group(1))
                        except Exception:
                            score_val = None

                    for part in [p.strip() for p in line.split("|")]:
                        if part.startswith("CPU:"):
                            try:
                                cpu_pct = float(part.split(":", 1)[1].strip().rstrip("%"))
                            except Exception:
                                pass
                        elif part.startswith("Parallelism:"):
                            try:
                                parallel_pct = float(part.split(":", 1)[1].strip().rstrip("%"))
                            except Exception:
                                pass
                        elif part.startswith("GC:"):
                            try:
                                gc_pct = float(part.split(":", 1)[1].strip().rstrip("%"))
                            except Exception:
                                pass
                        elif part.startswith("Skew:"):
                            try:
                                skew_str = part.split(":", 1)[1].strip().rstrip("x")
                                skew_val = float(skew_str)
                            except Exception:
                                pass

        i += 1

    if fixes_by_num:
        fixes = [fixes_by_num[k] for k in sorted(fixes_by_num.keys())]
    else:
        fixes = ["No action required"]

    # Derive score from metrics if missing.
    if score_val is None and all(v is not None for v in (cpu_pct, parallel_pct, gc_pct, skew_val)):
        # executor_eff, parallelism_score, gc_overhead and task_skew mapping.
        executor_eff = float(cpu_pct) / 100.0
        parallelism_score = float(parallel_pct) / 100.0
        gc_overhead = float(gc_pct) / 100.0
        task_skew = float(skew_val)
        perf_score = (
            (executor_eff * 30)
            + (parallelism_score * 30)
            + ((1.0 - min(1.0, gc_overhead)) * 20)
            + ((1.0 / max(1.0, task_skew)) * 20)
        )
        score_val = int(round(perf_score))

    if score_val is None:
        score_val = 0

    # Defaults if any metric is missing.
    cpu_pct = 0.0 if cpu_pct is None else cpu_pct
    parallel_pct = 0.0 if parallel_pct is None else parallel_pct
    gc_pct = 0.0 if gc_pct is None else gc_pct
    skew_val = 1.0 if skew_val is None else skew_val

    # Apply skew penalty to the performance score after any existing penalties.
    score_val = int(max(0, int(score_val) - _skew_penalty_points(float(skew_val))))

    # Promote extreme task skew to primary issue.
    # Requirement:
    #   - skew > 5x  -> at minimum HIGH and must not show LOW / "No action required"
    #   - skew > 10x -> CRITICAL as the primary issue, even if driver overhead is present
    if float(skew_val) > 5.0:
        prev_primary_category = primary_category
        prev_primary_severity = primary_severity
        prev_root_cause = root_cause
        prev_fixes = fixes

        primary_category = "Data Skew"
        primary_severity = "CRITICAL" if float(skew_val) > 10.0 else "HIGH"

        skew_display = f"{float(skew_val):.1f}x"
        root_cause = (
            f"Task skew ratio {skew_display} — some tasks take {skew_display} longer than average"
        )
        impact = "Straggler tasks dominate stage runtime — poor scaling and long-tail latency"
        fixes = [
            "Apply salting to hot join keys",
            "Repartition with df.repartition(N, 'key_col') to redistribute",
            "Use AQE skew join hint: spark.sql.adaptive.skewJoin.enabled=true",
        ]

        # Keep the previous primary issue visible as a secondary issue.
        try:
            prev_cat_norm = (prev_primary_category or "").strip().lower()
            if prev_cat_norm and prev_cat_norm != "data skew":
                already_present = any(
                    (prev_cat_norm == (str(sec.get("category", "")).strip().lower()))
                    for sec in secondary
                )
                if not already_present:
                    prev_sec: dict[str, str] = {
                        "idx": "0",
                        "category": str(prev_primary_category),
                        "severity": str(prev_primary_severity).strip().upper() or "LOW",
                        "cause": str(prev_root_cause),
                        "fix": "",
                    }
                    if isinstance(prev_fixes, list) and prev_fixes:
                        if str(prev_fixes[0]).strip() and str(prev_fixes[0]).strip().lower() != "no action required":
                            prev_sec["fix"] = str(prev_fixes[0]).strip()
                    secondary.insert(0, prev_sec)
        except Exception:
            # Best-effort only; do not fail formatting.
            pass

    grade_emoji, grade_label = _score_grade(int(score_val))

    def _is_primary_driver_overhead(category: str) -> bool:
        c = (category or "").strip().lower()
        return ("driver overhead" in c) or ("driver coordination" in c)

    # Primary header (plain text, no boxes).
    box_inner = 58

    title = primary_category
    if job_type_label:
        title = f"{title} ({job_type_label})"

    # Keep the first line reasonably short for database cells.
    max_title = 72
    if len(title) > max_title:
        title = title[: max(0, max_title - 1)] + "…"

    primary_header = f"{_severity_emoji(primary_severity)} {primary_severity} — {title}"

    # Fix lines with warning emoji based on content.
    fix_lines: list[str] = []
    for idx, fix in enumerate(fixes, 1):
        fix_norm = _normalize_body_text(fix)
        warn = ("will not help" in fix_norm.lower()) or ("avoid" in fix_norm.lower())
        prefix = f"    {idx}. " + ("⚠️  " if warn else "")
        fix_lines.append(prefix + fix_norm)

    # Secondary issues.
    sec_lines: list[str] = []
    secondary_filtered = secondary
    if secondary_filtered and _is_primary_driver_overhead(primary_category):
        secondary_filtered = [
            sec
            for sec in secondary_filtered
            if "cpu" not in str(sec.get("category", "")).lower()
        ]

    if secondary_filtered:
        sec_lines.append("")
        sec_lines.append(f"🟡 SECONDARY ISSUES ({len(secondary_filtered)})")
        sec_lines.append("")
        def _sec_sort_key(x: dict[str, str]) -> int:
            try:
                return int(x.get("idx", "0"))
            except Exception:
                return 0

        secondary_sorted = sorted(secondary_filtered, key=_sec_sort_key)

        for j, sec in enumerate(secondary_sorted, 1):
            sev = sec.get("severity", "LOW").upper()
            cat = sec.get("category", "").strip()
            cause = _normalize_body_text(sec.get("cause", "").strip())
            fx = _normalize_body_text(sec.get("fix", "").strip())
            sec_lines.append(f"    [{j}] {_severity_emoji(sev)} {sev:<5} │  {cat}")
            if cause:
                sec_lines.append(f"        {cause}")
            if fx:
                sec_lines.append(f"        → Fix: {fx}")
            sec_lines.append("")

    # Performance summary always last.
    perf_lines: list[str] = []
    perf_lines.append("")
    perf_lines.append("📈 PERFORMANCE SUMMARY")
    perf_lines.append(f"    Score  : {int(score_val)}/100  {grade_emoji} {grade_label}")
    perf_lines.append(
        f"    CPU    : {cpu_pct:.1f}%   {_metric_health_cpu(cpu_pct / 100.0)}"
    )
    perf_lines.append(
        f"    Parallel: {parallel_pct:.1f}% {_metric_health_parallelism(parallel_pct / 100.0)}"
    )
    perf_lines.append(
        f"    GC     : {gc_pct:.1f}%    {_metric_health_gc(gc_pct / 100.0)}"
    )
    perf_lines.append(
        f"    Skew   : {skew_val:.1f}x    {_metric_health_skew(skew_val)}"
    )

    # Assemble.
    out: list[str] = [
        primary_header,
        "",
        "📌 ROOT CAUSE",
        f"    {_normalize_body_text(root_cause)}",
        "",
        "📊 IMPACT",
        f"    {_normalize_body_text(impact)}",
        "",
        "🔧 FIXES",
        *fix_lines,
        "",
        *sec_lines,
        *perf_lines,
    ]

    # Strip trailing whitespace.
    out = [line.rstrip() for line in out]

    # Final cleanup: never emit orphaned " - " artifacts.
    out = [line for line in out if line.strip() != "-" and line.strip() != "-".strip()]
    return "\n".join(out).rstrip() + "\n"


def _install_write_kusto_wrapper(ns: dict[str, Any]) -> None:
    """Wrap write_kusto_df so recommendations are written as a single formatted block per app."""

    fn = ns.get("write_kusto_df")
    if not callable(fn):
        return

    if ns.get("_sma_write_kusto_wrapped") is fn:
        return

    base_fn = fn

    def _wrapped_write_kusto_df(df: Any, table: str, mode: str = "Append") -> Any:
        try:
            if str(table) == "sparklens_recommedations":
                # Expect schema: app_id, recommendation (one row per line today).
                try:
                    import pandas as pd
                    from pyspark.sql.types import StructType, StructField, StringType
                    from pyspark.sql.functions import col, lit

                    out_schema = StructType(
                        [
                            StructField("app_id", StringType(), True),
                            StructField("recommendation", StringType(), True),
                        ]
                    )

                    # Attach job type from metrics_out if available.
                    # Metric is emitted as: ("Job Type", 1.0 if streaming else 0.0)
                    try:
                        metrics_out = ns.get("metrics_out")
                        if metrics_out is not None:
                            job_type_df = (
                                metrics_out
                                .filter(col("metric") == lit("Job Type"))
                                .select(col("app_id"), col("value").alias("_job_type_value"))
                            )
                            df = df.join(job_type_df, on="app_id", how="left")
                    except Exception:
                        logger.exception("Failed to attach job type for recommendation formatting")

                    def _format_group(pdf: "pd.DataFrame") -> "pd.DataFrame":
                        app_id = str(pdf["app_id"].iloc[0]) if not pdf.empty else ""
                        raw_lines = [str(x) for x in pdf["recommendation"].tolist()]
                        job_type_label = ""
                        try:
                            if "_job_type_value" in pdf.columns and not pdf.empty:
                                v = pdf["_job_type_value"].iloc[0]
                                if v is not None and float(v) >= 0.5:
                                    job_type_label = "STREAMING"
                                else:
                                    job_type_label = "BATCH"
                        except Exception:
                            job_type_label = ""

                        formatted = _format_plaintext_recommendation_block(raw_lines, job_type=job_type_label)
                        return pd.DataFrame([{"app_id": app_id, "recommendation": formatted}])

                    df = df.groupBy("app_id").applyInPandas(_format_group, schema=out_schema)

                    # ----------------------------
                    # Fabric-specific recommendations (rule based)
                    # ----------------------------
                    try:
                        metrics_out = ns.get("metrics_out")
                        metadata_out = ns.get("metadata_out")
                        if metrics_out is not None and metadata_out is not None:
                            from pyspark.sql import functions as F

                            # Aggregate required metrics per app.
                            m = (
                                metrics_out
                                .groupBy("app_id")
                                .agg(
                                    F.max(F.when(col("metric") == lit("Executor Time %"), col("value"))).alias("executor_time_pct"),
                                    F.max(F.when(col("metric") == lit("Executor Wall Clock Time (sec)"), col("value"))).alias("executor_wall_clock"),
                                    F.max(F.when(col("metric") == lit("Application Duration (sec)"), col("value"))).alias("app_duration"),
                                    F.max(F.when(col("metric") == lit("Executor Efficiency"), col("value"))).alias("executor_eff"),
                                    F.max(F.when(col("metric") == lit("Job Type"), col("value"))).alias("job_type_value"),
                                    F.max(F.when(col("metric") == lit("Driver Time %"), col("value"))).alias("driver_time_pct"),
                                    F.max(F.when(col("metric") == lit("Driver Overhead %"), col("value"))).alias("driver_overhead_pct"),
                                )
                            )

                            # Derive executor wall clock % if it's missing.
                            m = m.withColumn(
                                "executor_time_pct_final",
                                F.coalesce(
                                    col("executor_time_pct"),
                                    (col("executor_wall_clock") / F.when(col("app_duration") > F.lit(0.0), col("app_duration")).otherwise(F.lit(1.0))) * F.lit(100.0),
                                ),
                            )

                            # Pull the relevant Fabric metadata per app.
                            meta_cols = set(metadata_out.columns)
                            if "app_id" in meta_cols:
                                meta_id = col("app_id")
                            elif "applicationId" in meta_cols:
                                meta_id = col("applicationId")
                            elif "applicationID" in meta_cols:
                                meta_id = col("applicationID")
                            else:
                                meta_id = None

                            # IMPORTANT: `spark.native.enabled` is a literal column name containing dots.
                            # Use backticks so Spark doesn't treat it as nested-field access.
                            nee_col = (
                                col("`spark.native.enabled`")
                                if "spark.native.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("spark_native_enabled")
                            hc_col = (
                                col("isHighConcurrencyEnabled")
                                if "isHighConcurrencyEnabled" in meta_cols
                                else F.lit(None)
                            ).alias("high_concurrency_enabled")

                            pythonauto_compact_col = (
                                col("`spark.databricks.delta.autoCompact.enabled`")
                                if "spark.databricks.delta.autoCompact.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("pythonauto_compact")
                            adaptive_file_size_col = (
                                col("`spark.microsoft.delta.targetFileSize.adaptive.enabled`")
                                if "spark.microsoft.delta.targetFileSize.adaptive.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("adaptive_file_size")
                            fast_optimize_col = (
                                col("`spark.microsoft.delta.optimize.fast.enabled`")
                                if "spark.microsoft.delta.optimize.fast.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("fast_optimize")
                            file_level_compaction_col = (
                                col("`spark.microsoft.delta.optimize.fileLevelTarget.enabled`")
                                if "spark.microsoft.delta.optimize.fileLevelTarget.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("file_level_compaction")
                            extended_stats_col = (
                                col("`spark.microsoft.delta.stats.collect.extended`")
                                if "spark.microsoft.delta.stats.collect.extended" in meta_cols
                                else F.lit(None)
                            ).alias("extended_stats")
                            snapshot_accel_col = (
                                col("`spark.microsoft.delta.snapshot.driverMode.enabled`")
                                if "spark.microsoft.delta.snapshot.driverMode.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("snapshot_accel")
                            vorder_col = (
                                col("`spark.sql.parquet.vorder.default`")
                                if "spark.sql.parquet.vorder.default" in meta_cols
                                else F.lit(None)
                            ).alias("vorder")
                            optimize_write_col = (
                                col("`spark.microsoft.delta.optimizeWrite.enabled`")
                                if "spark.microsoft.delta.optimizeWrite.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("optimize_write")
                            optimize_write_dbx_col = (
                                col("`spark.databricks.delta.optimizeWrite.enabled`")
                                if "spark.databricks.delta.optimizeWrite.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("optimize_write_dbx")
                            optimize_write_dbx_part_col = (
                                col("`spark.databricks.delta.optimizeWrite.partitioned.enabled`")
                                if "spark.databricks.delta.optimizeWrite.partitioned.enabled" in meta_cols
                                else F.lit(None)
                            ).alias("optimize_write_dbx_partitioned")
                            resource_profile_col = (
                                col("`spark.fabric.resourceProfile`")
                                if "spark.fabric.resourceProfile" in meta_cols
                                else F.lit(None)
                            ).alias("resource_profile")

                            if meta_id is not None:
                                meta = metadata_out.select(
                                    meta_id.cast("string").alias("app_id"),
                                    nee_col,
                                    hc_col,
                                    pythonauto_compact_col,
                                    adaptive_file_size_col,
                                    fast_optimize_col,
                                    file_level_compaction_col,
                                    extended_stats_col,
                                    snapshot_accel_col,
                                    vorder_col,
                                    optimize_write_col,
                                    optimize_write_dbx_col,
                                    optimize_write_dbx_part_col,
                                    resource_profile_col,
                                )
                            else:
                                meta = metadata_out.select(
                                    F.lit(None).cast("string").alias("app_id"),
                                    nee_col,
                                    hc_col,
                                    pythonauto_compact_col,
                                    adaptive_file_size_col,
                                    fast_optimize_col,
                                    file_level_compaction_col,
                                    extended_stats_col,
                                    snapshot_accel_col,
                                    vorder_col,
                                    optimize_write_col,
                                    optimize_write_dbx_col,
                                    optimize_write_dbx_part_col,
                                    resource_profile_col,
                                )

                            features = m.join(meta, on="app_id", how="left")

                            fabric_schema = StructType(
                                [
                                    StructField("app_id", StringType(), True),
                                    StructField("recommendation", StringType(), True),
                                ]
                            )

                            def _fabric_rules(pdf: "pd.DataFrame") -> "pd.DataFrame":
                                if pdf is None or pdf.empty:
                                    return pd.DataFrame([], columns=["app_id", "recommendation"])

                                app_id = str(pdf["app_id"].iloc[0])
                                exec_pct = None
                                exec_eff = None
                                job_type_val = None
                                driver_time_pct = None
                                driver_overhead_pct = None
                                nee_raw = None
                                hc_raw = None
                                pythonauto_compact = None
                                adaptive_file_size = None
                                fast_optimize = None
                                file_level_compaction = None
                                extended_stats = None
                                snapshot_accel = None
                                vorder = None
                                optimize_write = None
                                optimize_write_dbx = None
                                optimize_write_dbx_partitioned = None
                                resource_profile = None
                                try:
                                    if "executor_time_pct_final" in pdf.columns:
                                        v = pdf["executor_time_pct_final"].iloc[0]
                                        exec_pct = float(v) if v is not None else None
                                    if "executor_eff" in pdf.columns:
                                        v = pdf["executor_eff"].iloc[0]
                                        exec_eff = float(v) if v is not None else None
                                    if "job_type_value" in pdf.columns:
                                        job_type_val = pdf["job_type_value"].iloc[0]
                                    if "driver_time_pct" in pdf.columns:
                                        v = pdf["driver_time_pct"].iloc[0]
                                        driver_time_pct = float(v) if v is not None else None
                                    if "driver_overhead_pct" in pdf.columns:
                                        v = pdf["driver_overhead_pct"].iloc[0]
                                        driver_overhead_pct = float(v) if v is not None else None
                                    if "spark_native_enabled" in pdf.columns:
                                        nee_raw = pdf["spark_native_enabled"].iloc[0]
                                    if "high_concurrency_enabled" in pdf.columns:
                                        hc_raw = pdf["high_concurrency_enabled"].iloc[0]
                                    if "pythonauto_compact" in pdf.columns:
                                        pythonauto_compact = pdf["pythonauto_compact"].iloc[0]
                                    if "adaptive_file_size" in pdf.columns:
                                        adaptive_file_size = pdf["adaptive_file_size"].iloc[0]
                                    if "fast_optimize" in pdf.columns:
                                        fast_optimize = pdf["fast_optimize"].iloc[0]
                                    if "file_level_compaction" in pdf.columns:
                                        file_level_compaction = pdf["file_level_compaction"].iloc[0]
                                    if "extended_stats" in pdf.columns:
                                        extended_stats = pdf["extended_stats"].iloc[0]
                                    if "snapshot_accel" in pdf.columns:
                                        snapshot_accel = pdf["snapshot_accel"].iloc[0]
                                    if "vorder" in pdf.columns:
                                        vorder = pdf["vorder"].iloc[0]
                                    if "optimize_write" in pdf.columns:
                                        optimize_write = pdf["optimize_write"].iloc[0]
                                    if "optimize_write_dbx" in pdf.columns:
                                        optimize_write_dbx = pdf["optimize_write_dbx"].iloc[0]
                                    if "optimize_write_dbx_partitioned" in pdf.columns:
                                        optimize_write_dbx_partitioned = pdf["optimize_write_dbx_partitioned"].iloc[0]
                                    if "resource_profile" in pdf.columns:
                                        resource_profile = pdf["resource_profile"].iloc[0]
                                except Exception:
                                    pass

                                job_type_label = "STREAMING" if (job_type_val is not None and float(job_type_val) >= 0.5) else "BATCH"

                                def _truthy(x: Any) -> bool:
                                    if x is None:
                                        return False
                                    if isinstance(x, bool):
                                        return bool(x)
                                    s = str(x).strip().lower()
                                    return s in {"true", "1", "yes", "enabled", "on"}

                                def _falsy(x: Any) -> bool:
                                    if x is None:
                                        return False
                                    if isinstance(x, bool):
                                        return not bool(x)
                                    s = str(x).strip().lower()
                                    return s in {"false", "0", "no", "disabled", "off"}

                                nee_disabled = _falsy(nee_raw)
                                hc_disabled = _falsy(hc_raw)

                                # Rules (priority order; exactly one base rule can fire)
                                recs: list[str] = []
                                driver_heavy = False
                                executor_heavy_header = False

                                # Helper: interpret efficiency in either 0-1 or 0-100 scale.
                                exec_eff_pct: float | None = None
                                if exec_eff is not None:
                                    try:
                                        exec_eff_pct = float(exec_eff) * 100.0 if float(exec_eff) <= 1.0 else float(exec_eff)
                                    except Exception:
                                        exec_eff_pct = None

                                # Driver idle % proxy: use driver_time_pct when present, else driver_overhead_pct.
                                driver_idle_pct: float | None = driver_time_pct if driver_time_pct is not None else driver_overhead_pct

                                def _fmt_pct_0_100(v: Any) -> str:
                                    """Format a value that is expected to already be a 0–100 percentage."""

                                    if v is None:
                                        return "N/A"
                                    try:
                                        import math

                                        f = float(v)
                                        if math.isnan(f):
                                            return "N/A"
                                        return f"{f:.1f}%"
                                    except Exception:
                                        return "N/A"

                                def _fmt_pct_float(pct: float | None) -> str:
                                    if pct is None:
                                        return "N/A"
                                    try:
                                        return f"{float(pct):.1f}%"
                                    except Exception:
                                        return "N/A"

                                def _as_float(v: Any) -> float | None:
                                    if v is None:
                                        return None
                                    try:
                                        import math

                                        f = float(v)
                                        if math.isnan(f):
                                            return None
                                        return f
                                    except Exception:
                                        return None

                                def _clamp_pct(v: float | None) -> float | None:
                                    if v is None:
                                        return None
                                    try:
                                        return max(0.0, min(100.0, float(v)))
                                    except Exception:
                                        return None

                                # Wall clock percentages
                                # - Prefer the explicit Driver Time % metric when present.
                                # - If missing, derive it as 100 - Executor Wall Clock % (when available).
                                # - Ensure driver+executor adds up to 100% (normalize) when both are present.
                                driver_wc_raw = _as_float(driver_time_pct)
                                executor_wc_raw = _as_float(exec_pct)

                                if driver_wc_raw is None and executor_wc_raw is not None:
                                    driver_wc_raw = 100.0 - executor_wc_raw
                                if executor_wc_raw is None and driver_wc_raw is not None:
                                    executor_wc_raw = 100.0 - driver_wc_raw

                                driver_wc_raw = _clamp_pct(driver_wc_raw)
                                executor_wc_raw = _clamp_pct(executor_wc_raw)

                                if driver_wc_raw is not None and executor_wc_raw is not None:
                                    s = driver_wc_raw + executor_wc_raw
                                    if s > 0.0:
                                        driver_wc = 100.0 * driver_wc_raw / s
                                        executor_wc = 100.0 * executor_wc_raw / s
                                    else:
                                        driver_wc, executor_wc = driver_wc_raw, executor_wc_raw
                                else:
                                    driver_wc, executor_wc = driver_wc_raw, executor_wc_raw

                                metrics_line = (
                                    "📊 Metrics: Driver Wall Clock="
                                    f"{_fmt_pct_0_100(driver_wc)}, Executor Wall Clock="
                                    f"{_fmt_pct_0_100(executor_wc)}, Executor Efficiency="
                                    f"{_fmt_pct_float(exec_eff_pct)}"
                                )

                                # RULE 1 — Driver-heavy jobs (already working; keep detection, update message)
                                if driver_idle_pct is not None and float(driver_idle_pct) > 90.0:
                                    driver_heavy = True
                                    recs.append(
                                        "💰 Cost Optimization: Job is driver-heavy (>90% driver time).\n"
                                        "   Consider: (1) Run on a single-node pool — set autoscale min/max to 1\n"
                                        "             (2) Refactor to Python and run on a Python kernel instead"
                                    )

                                # RULE 2 — Executor-heavy jobs
                                elif (
                                    exec_eff_pct is not None
                                    and float(exec_eff_pct) > 50.0
                                    and driver_idle_pct is not None
                                    and float(driver_idle_pct) < 60.0
                                ):
                                    executor_heavy_header = True
                                    recs.append(
                                        "⚡ Performance Optimization: Job is executor-heavy — Spark resources are actively used.\n"
                                        "   (1) Enable Native Execution Engine (NEE): set spark.native.enabled=true\n"
                                        "       — vectorized execution can improve CPU-bound stages by 2-5x\n"
                                        "   (2) Enable High Concurrency mode to improve resource sharing"
                                    )

                                # Best practices + resource profile
                                # For driver-heavy jobs we emit ONLY the cost optimization item (Rule 1) to
                                # avoid noisy, non-actionable recommendations.
                                best_practice_items: list[str] = []
                                resource_profile_item: str | None = None

                                if not driver_heavy:
                                    # Best practices
                                    # - For executor-heavy jobs (executor efficiency > 50%): ALWAYS emit all 8 properties
                                    #   with three-way status (not configured / recommended change / ✅ validated).
                                    # - Otherwise: old behavior — skip missing/correct; only emit when present and wrong.

                                    def _norm(x: Any) -> str:
                                        return str(x).strip().lower()

                                    always_emit_bps = exec_eff_pct is not None and float(exec_eff_pct) > 50.0

                                    def _effective_optimize_write() -> tuple[Any, str]:
                                        # Prefer Microsoft key, then Databricks keys when present.
                                        if optimize_write is not None:
                                            return optimize_write, "spark.microsoft.delta.optimizeWrite.enabled"
                                        if optimize_write_dbx is not None:
                                            return optimize_write_dbx, "spark.databricks.delta.optimizeWrite.enabled"
                                        if optimize_write_dbx_partitioned is not None:
                                            return (
                                                optimize_write_dbx_partitioned,
                                                "spark.databricks.delta.optimizeWrite.partitioned.enabled",
                                            )
                                        return None, "spark.microsoft.delta.optimizeWrite.enabled"

                                    def _emit_bp(
                                        prop_value: Any,
                                        prop_key_for_set: str,
                                        display_name: str,
                                        correct_value: str,
                                    ) -> None:
                                        """Emit best-practice lines following executor-heavy vs driver-heavy rules."""

                                        if prop_value is None:
                                            if not always_emit_bps:
                                                return
                                            best_practice_items.append(
                                                f"⚙️  Best Practice: {display_name} — not configured\n"
                                                f"         Recommended: spark.conf.set(\"{prop_key_for_set}\", {correct_value})"
                                            )
                                            return

                                        current = _norm(prop_value)
                                        if current == _norm(correct_value):
                                            if always_emit_bps:
                                                best_practice_items.append(
                                                    f"✅ Validated: {display_name} is correctly set to {current} — no action needed"
                                                )
                                            return

                                        # Present but wrong
                                        best_practice_items.append(
                                            f"⚙️  Best Practice: {display_name} is {current} — recommended: Set to {correct_value}\n"
                                            f"         Set: spark.conf.set(\"{prop_key_for_set}\", {correct_value})"
                                        )

                                    # Property table (8 properties)
                                    _emit_bp(
                                        pythonauto_compact,
                                        "spark.databricks.delta.autoCompact.enabled",
                                        "Auto Compaction",
                                        "true",
                                    )
                                    _emit_bp(
                                        adaptive_file_size,
                                        "spark.microsoft.delta.targetFileSize.adaptive.enabled",
                                        "Adaptive Target File Size",
                                        "true",
                                    )
                                    _emit_bp(
                                        fast_optimize,
                                        "spark.microsoft.delta.optimize.fast.enabled",
                                        "Fast Optimize",
                                        "true",
                                    )
                                    _emit_bp(
                                        file_level_compaction,
                                        "spark.microsoft.delta.optimize.fileLevelTarget.enabled",
                                        "File Level Compaction",
                                        "true",
                                    )
                                    _emit_bp(
                                        extended_stats,
                                        "spark.microsoft.delta.stats.collect.extended",
                                        "Extended Table Statistics",
                                        "true",
                                    )
                                    _emit_bp(
                                        snapshot_accel,
                                        "spark.microsoft.delta.snapshot.driverMode.enabled",
                                        "Snapshot Acceleration",
                                        "true",
                                    )
                                    _emit_bp(
                                        vorder,
                                        "spark.sql.parquet.vorder.default",
                                        "VORDER",
                                        "false",
                                    )
                                    _ow_val, _ow_key = _effective_optimize_write()
                                    _emit_bp(
                                        _ow_val,
                                        _ow_key,
                                        "Optimize Write",
                                        "false",
                                    )

                                    # Resource profile (informational)
                                    if resource_profile is not None:
                                        rp_raw = str(resource_profile).strip()
                                        rp = rp_raw.lower()
                                        if rp == "readheavyforspark":
                                            desc = "Optimized for Spark workloads with frequent reads"
                                        elif rp == "readheavyforpbi":
                                            desc = "Optimized for Power BI queries on Delta tables"
                                        elif rp == "writeheavy":
                                            desc = "Optimized for high-frequency ingestion and writes"
                                        elif rp == "custom":
                                            desc = "Fully user-defined configuration — verify settings manually"
                                        else:
                                            desc = "Unrecognized resource profile — verify this is intentional"
                                        resource_profile_item = (
                                            f"ℹ️  Resource Profile: {rp_raw} — {desc}\n"
                                            "       readHeavyForSpark → Optimized for Spark workloads with frequent reads\n"
                                            "       readHeavyForPBI → Optimized for Power BI queries on Delta tables\n"
                                            "       writeHeavy → Optimized for high-frequency ingestion and writes\n"
                                            "       custom → Fully user-defined configuration — configure after thorough benchmarking"
                                        )

                                # RULE 3 — Default (only when there are no actionable items)
                                if not recs and not best_practice_items:
                                    recs.append(
                                        "✅ No Fabric-level changes recommended — job configuration looks appropriate\n"
                                        "   for the detected workload pattern."
                                    )

                                # Final assembly: always include metrics.
                                final_recs = list(recs)
                                if driver_heavy or executor_heavy_header:
                                    final_recs.insert(1 if final_recs else 0, metrics_line)
                                else:
                                    final_recs.insert(0, metrics_line)

                                # Append best practices and resource profile after base rules + metrics.
                                final_recs.extend(best_practice_items)
                                if resource_profile_item is not None:
                                    final_recs.append(resource_profile_item)

                                # Plain text block similar to sparklens style (no boxes, no dividers).
                                header = f"🧵 FABRIC RECOMMENDATIONS ({job_type_label})"
                                body = "\n".join([f"    {i}. {r}" for i, r in enumerate(final_recs, 1)])
                                out = header + "\n\n" + body + "\n"
                                return pd.DataFrame([{"app_id": app_id, "recommendation": out}])

                            fabric_df = features.groupBy("app_id").applyInPandas(_fabric_rules, schema=fabric_schema)
                            fabric_df = fabric_df.filter(F.length(F.col("recommendation")) > 0)

                            # Write Fabric recommendations to their own table.
                            # Table name matches the user's requested/checked spelling.
                            base_fn(fabric_df, "fabric_recommedations", mode=mode)
                    except Exception:
                        logger.exception("Failed generating/writing Fabric recommendations")
                except Exception:
                    logger.exception("Failed to format recommendations before Kusto write; falling back to raw output")

        except Exception:
            # Never block writes because of formatting.
            logger.exception("Unexpected error in write_kusto_df wrapper")

        # Keep Kusto writes compatible with existing sparklens_metadata schema.
        # We may compute extra columns for Fabric recommendations, but don't force
        # them into the Kusto table unless it already supports them.
        if str(table) == "sparklens_metadata":
            try:
                extra_cols = [
                    "spark.databricks.delta.optimizeWrite.enabled",
                    "spark.databricks.delta.optimizeWrite.partitioned.enabled",
                ]
                if hasattr(df, "columns"):
                    for c in extra_cols:
                        if c in df.columns:
                            df = df.drop(c)
            except Exception:
                logger.exception("Failed to drop extra metadata columns before Kusto write")

        return base_fn(df, table, mode=mode)

    ns["write_kusto_df"] = _wrapped_write_kusto_df
    ns["_sma_write_kusto_wrapped"] = _wrapped_write_kusto_df


def run(kusto_uri: str, database: str) -> None:
    """Run the notebook pipeline in-order.

    Parameters
    ----------
    kusto_uri:
        Kusto cluster URI.
    database:
        Kusto database name.
    """

    # Minimal logging wiring: don't override app logging if already configured.
    root_logger = logging.getLogger()
    if not root_logger.handlers:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s %(levelname)s %(name)s - %(message)s",
        )

    def _resolve_runtime_symbol(name: str) -> Any | None:
        # 1) If this module somehow has it.
        if name in globals():
            return globals()[name]

        # 2) Notebook/session global namespace.
        try:
            main_mod = importlib.import_module("__main__")
            if hasattr(main_mod, name):
                return getattr(main_mod, name)
        except Exception:
            pass

        # 3) Sometimes injected into builtins.
        try:
            if hasattr(builtins, name):
                return getattr(builtins, name)
        except Exception:
            pass

        # 4) Spark: try to discover an already-active session (does not create a new one).
        if name == "spark":
            try:
                from pyspark.sql import SparkSession

                active = SparkSession.getActiveSession()
                if active is not None:
                    return active
            except Exception:
                pass

        return None

    class _NotebookNamespace(dict):
        """Exec namespace that can auto-install wrappers during cell execution.

        This is required because some notebook cells define and *use* functions
        like `write_kusto_df` in the same cell; post-cell wrapping is too late.
        """

        _sma_in_setitem: bool = False

        def __setitem__(self, key: str, value: Any) -> None:  # type: ignore[override]
            super().__setitem__(key, value)

            # Avoid recursion when wrappers assign back into the namespace.
            if getattr(self, "_sma_in_setitem", False):
                return

            if key in {"generate_enhanced_recommendations", "write_kusto_df"}:
                try:
                    self._sma_in_setitem = True
                    _install_generate_wrapper(self)
                    _install_write_kusto_wrapper(self)
                finally:
                    self._sma_in_setitem = False

    ns: dict[str, Any] = _NotebookNamespace(
        {
            "__name__": "__main__",
            "kustoUri": kusto_uri,
            "database": database,
        }
    )

    # If running inside Fabric/Synapse notebooks, these are usually already present.
    for sym in ("spark", "mssparkutils"):
        resolved = _resolve_runtime_symbol(sym)
        if resolved is not None:
            ns[sym] = resolved

    if "spark" not in ns:
        raise NameError(
            "name 'spark' is not defined. This package must be run inside a Fabric/Synapse "
            "Spark notebook/session where a SparkSession is available as `spark`."
        )

    # Guardrail: ensure we are not accidentally running against a local Spark.
    try:
        master = str(ns["spark"].sparkContext.master)
        logger.info("Using Spark master: %s", master)
        if "local" in master.lower():
            raise RuntimeError(
                f"Spark master is '{master}', which looks like local mode. "
                "This package is expected to run on a cluster (e.g., YARN-backed Synapse/Fabric Spark)."
            )
    except Exception:
        # If we can't introspect master, don't block execution.
        pass

    for cell_number, cell_code in NOTEBOOK_CODE_CELLS:
        try:
            exec(cell_code, ns, ns)
        except Exception:
            logger.exception("Notebook Cell %s failed", cell_number)
            raise

        # Ensure runtime parameters win over the notebook's parameter cell.
        ns["kustoUri"] = kusto_uri
        ns["database"] = database

        # Install wrapper as soon as the function exists.
        _install_generate_wrapper(ns)

        # Wrap Kusto writer as soon as it exists (so cell 9 writes are formatted).
        _install_write_kusto_wrapper(ns)


# ------------------------------
# Example stub rule (NOT enabled)
# ------------------------------

def example_stub_rule(ns: dict[str, Any], base_recommendations: Any) -> Any | None:
    """Example: add a custom recommendation.

    This stub returns `None` so it does not change results.

    To enable a rule, register it before calling `run()`:

        from spark_monitoring_analyzer.analyzer import register_recommendation_rule, run
        register_recommendation_rule(example_stub_rule)
        run(kusto_uri=..., database=...)
    """

    return None


# ------------------------------
# Notebook cells (verbatim)
# ------------------------------

NOTEBOOK_CODE_CELLS: list[tuple[int, str]] = [
    # ===== Notebook Cell 1: # # This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?lin =====
    (1, r'''# # This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
# kustoUri = "https://trd-xrsqqb21ypfs70cr0d.z9.kusto.fabric.microsoft.com"
# database = "Spark Monitoring"'''),
    # ===== Notebook Cell 2: # This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linki =====
    (2, r'''# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
kustoUri = "https://trd-kx2zn2dzkdksr5r4dj.z0.kusto.fabric.microsoft.com"
database = "Spark Monitoring"'''),
    # ===== Notebook Cell 3: # === Helper Functions for Event Processing === =====
    (3, r'''# === Helper Functions for Event Processing ===

from typing import Dict, Any, List
import json
import numpy as np

def _safe_get(dct: Any, path: List[str], default=None):
    """Safely navigate nested dictionaries"""
    cur = dct
    for p in path:
        if not isinstance(cur, dict) or p not in cur:
            return default
        cur = cur[p]
    return cur

def _parse_record(rec_str: str) -> Dict[str, Any]:
    """Parse JSON record string"""
    try:
        return json.loads(rec_str) if rec_str else {}
    except Exception:
        return {}

def _to_float(x, default=0.0):
    """Convert to float safely"""
    try:
        if x is None:
            return float(default)
        return float(x)
    except Exception:
        return float(default)

def _to_int(x, default=0):
    """Convert to int safely"""
    try:
        if x is None:
            return int(default)
        return int(x)
    except Exception:
        return int(default)

print("✅ Helper functions loaded successfully")'''),
    # ===== Notebook Cell 4: # === ML-Enhanced Imports for Production-Grade Analysis === =====
    (4, r'''# === ML-Enhanced Imports for Production-Grade Analysis ===
from sklearn.cluster import KMeans as SKKMeans
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler as SKScaler
from sklearn.metrics import silhouette_score
import warnings
warnings.filterwarnings('ignore')

print("✅ ML-enhanced imports loaded successfully")'''),
    # ===== Notebook Cell 5: # kustoUri = "https://trd-79rc3tdwe85wcms46k.z9.kusto.fabric.microsoft.com" =====
    (5, r'''# kustoUri = "https://trd-79rc3tdwe85wcms46k.z9.kusto.fabric.microsoft.com"
# database = "Spark Monitoring"'''),
    # ===== Notebook Cell 6: # === Advanced Spark Performance Recommender with ML Analytics (Helpers + Schemas) === =====
    (6, r'''# === Advanced Spark Performance Recommender with ML Analytics (Helpers + Schemas) ===

from pyspark.sql import SparkSession, Window, Row, DataFrame
from pyspark.sql.functions import (
    col, lit, count, countDistinct, avg, expr, percentile_approx, stddev,
    min as spark_min, max as spark_max, sum as spark_sum,
    when, from_json, get_json_object
)
import pyspark.sql.functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, DoubleType, LongType, BooleanType
)

import pandas as pd
import numpy as np
import math
import traceback
from typing import Dict, Any, Optional, List

from pyspark.ml.feature import VectorAssembler, StandardScaler
from pyspark.ml.clustering import KMeans
from pyspark.ml.stat import Correlation

# Enhanced ML imports for production-grade analysis
from sklearn.cluster import KMeans as SKKMeans
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler as SKScaler
from sklearn.metrics import silhouette_score
import warnings
warnings.filterwarnings('ignore')

# ==============================
# CONSTANTS
# ==============================

# Default executor cores - can be overridden by reading spark.executor.cores from configuration
DEFAULT_EXECUTOR_CORES = 4

# Driver overhead fractions for heuristic calculations
DRIVER_ACTIVE_TIME_FRACTION = 0.10      # 10% of app duration for driver active time
DRIVER_COORDINATION_TIME_FRACTION = 0.05 # 5% of app duration for coordination overhead

# Workload characterization thresholds
SKEW_THRESHOLD = 0.5           # Coefficient of variation threshold for skewed workloads
IO_BOUND_THRESHOLD = 100.0     # MB/sec threshold for IO-bound workloads  
COMPUTE_BOUND_THRESHOLD = 10.0 # MB/sec threshold for compute-bound workloads

# Performance optimization constants
DEFAULT_PARALLELISM_SCORE = 0.5  # Default when no metrics available
MIN_EXECUTOR_COUNT = 1           # Minimum executor count fallback

# ==============================
# KUSTO DATABASE SCHEMA DEFINITIONS
# ==============================

METADATA_SCHEMA = StructType([
    StructField("applicationId", StringType(), True),
    StructField("applicationName", StringType(), True),
    StructField("artifactId", StringType(), True),
    StructField("artifactType", StringType(), True),
    StructField("capacityId", StringType(), True),
    StructField("executorMax", LongType(), True),
    StructField("executorMin", LongType(), True),
    StructField("fabricEnvId", StringType(), True),
    StructField("fabricLivyId", StringType(), True),
    StructField("fabricTenantId", StringType(), True),
    StructField("fabricWorkspaceId", StringType(), True),
    StructField("isHighConcurrencyEnabled", BooleanType(), True),
    StructField("spark.native.enabled", StringType(), True),
    StructField("spark.databricks.delta.autoCompact.enabled", StringType(), True),
    StructField("spark.microsoft.delta.targetFileSize.adaptive.enabled", StringType(), True),
    StructField("spark.microsoft.delta.optimize.fast.enabled", StringType(), True),
    StructField("spark.microsoft.delta.optimize.fileLevelTarget.enabled", StringType(), True),
    StructField("spark.microsoft.delta.stats.collect.extended", StringType(), True),
    StructField("spark.microsoft.delta.snapshot.driverMode.enabled", StringType(), True),
    StructField("spark.sql.parquet.vorder.default", StringType(), True),
    StructField("spark.microsoft.delta.optimizeWrite.enabled", StringType(), True),
    # Some Fabric/Spark runtimes still emit Delta optimizeWrite under Databricks-namespaced keys.
    # Keep these for recommendation logic, but drop them before writing to the existing Kusto table
    # to avoid schema mismatch in environments where sparklens_metadata doesn't have these columns.
    StructField("spark.databricks.delta.optimizeWrite.enabled", StringType(), True),
    StructField("spark.databricks.delta.optimizeWrite.partitioned.enabled", StringType(), True),
    StructField("spark.fabric.resourceProfile", StringType(), True),
])

METRICS_SCHEMA = StructType([
    StructField("app_id", StringType(), True),
    StructField("metric", StringType(), True),
    StructField("value", DoubleType(), True)
])

# Updated SUMMARY_SCHEMA to match actual sparklens_summary table structure
SUMMARY_SCHEMA = StructType([
    StructField("stage_id", IntegerType(), True),
    StructField("stage_attempt_id", IntegerType(), True),
    StructField("num_tasks", IntegerType(), True),
    StructField("successful_tasks", IntegerType(), True),
    StructField("failed_tasks", IntegerType(), True),
    StructField("min_duration_sec", DoubleType(), True),
    StructField("max_duration_sec", DoubleType(), True),
    StructField("avg_duration_sec", DoubleType(), True),
    StructField("p75_duration_sec", DoubleType(), True),
    StructField("avg_shuffle_read_mb", DoubleType(), True),
    StructField("max_shuffle_read_mb", DoubleType(), True),
    StructField("avg_shuffle_read_records", DoubleType(), True),
    StructField("max_shuffle_read_records", IntegerType(), True),
    StructField("avg_shuffle_write_mb", DoubleType(), True),
    StructField("max_shuffle_write_mb", DoubleType(), True),
    StructField("avg_shuffle_write_records", DoubleType(), True),
    StructField("max_shuffle_write_records", IntegerType(), True),
    StructField("avg_input_mb", DoubleType(), True),
    StructField("max_input_mb", DoubleType(), True),
    StructField("avg_input_records", DoubleType(), True),
    StructField("max_input_records", IntegerType(), True),
    StructField("avg_output_mb", DoubleType(), True),
    StructField("max_output_mb", DoubleType(), True),
    StructField("avg_output_records", DoubleType(), True),
    StructField("max_output_records", IntegerType(), True),
    StructField("min_launch_time", IntegerType(), True),
    StructField("max_finish_time", IntegerType(), True),
    StructField("num_executors", IntegerType(), True),
    StructField("stage_execution_time_sec", DoubleType(), True),
    StructField("app_id", StringType(), True)
])

# Updated PREDICTIONS_SCHEMA to match actual sparklens_predictions table (5 columns only)
PREDICTIONS_SCHEMA = StructType([
    StructField("Executor Count", IntegerType(), True),        # Note: Column names with spaces
    StructField("Executor Multiplier", StringType(), True),   # match the actual table
    StructField("Estimated Executor WallClock", StringType(), True),
    StructField("Estimated Total Duration", StringType(), True),
    StructField("app_id", StringType(), True)
])

RECOMMENDATIONS_SCHEMA = StructType([
    StructField("app_id", StringType(), True),
    StructField("recommendation", StringType(), True)
])

print("📋 Kusto database schemas loaded successfully!")

# ==============================
# UTILITY FUNCTIONS
# ==============================

def get_executor_cores_config() -> int:
    """
    Get executor cores from Spark configuration with fallback to default.
    
    Returns:
        int: Number of executor cores per executor
    """
    try:
        return int(spark.conf.get("spark.executor.cores", str(DEFAULT_EXECUTOR_CORES)))
    except (ValueError, TypeError, AttributeError):
        return DEFAULT_EXECUTOR_CORES

def safe_unpersist_dataframe(df: Optional[DataFrame], df_name: str = "DataFrame") -> None:
    """
    Safely unpersist a DataFrame with error handling.
    
    Args:
        df: DataFrame to unpersist (can be None)
        df_name: Name for logging purposes
    """
    try:
        if df is not None:
            df.unpersist()
            print(f"🧹 Unpersisted {df_name}")
    except Exception as e:
        print(f"⚠️ Warning: Could not unpersist {df_name}: {e}")

def safe_float_conversion(value: Any, default: float = 0.0) -> float:
    """
    Safely convert value to float with fallback.
    
    Args:
        value: Value to convert
        default: Default value if conversion fails
        
    Returns:
        float: Converted value or default
    """
    try:
        return float(value) if value is not None else default
    except (ValueError, TypeError):
        return default

def safe_int_conversion(value: Any, default: int = 0) -> int:
    """
    Safely convert value to int with fallback.
    
    Args:
        value: Value to convert  
        default: Default value if conversion fails
        
    Returns:
        int: Converted value or default
    """
    try:
        return int(value) if value is not None else default
    except (ValueError, TypeError):
        return default

# ==============================
# CORE ANALYSIS FUNCTIONS
# ==============================

def compute_application_runtime(event_log_df: DataFrame) -> float:
    """
    Compute application runtime from start/end events (seconds).
    
    Args:
        event_log_df: DataFrame containing Spark event logs
        
    Returns:
        float: Application runtime in seconds
    """
    try:
        # Optimized: Get both start and end times in single query
        app_events = (
            event_log_df.filter(
                col("properties.Event").isin(["SparkListenerApplicationStart", "SparkListenerApplicationEnd"])
            )
            .select(
                col("properties.Event").alias("event_type"),
                col("properties.Timestamp").alias("timestamp")
            )
            .collect()
        )
        
        start_time = None
        end_time = None
        
        for row in app_events:
            if row["event_type"] == "SparkListenerApplicationStart":
                start_time = safe_float_conversion(row["timestamp"])
            elif row["event_type"] == "SparkListenerApplicationEnd":
                end_time = safe_float_conversion(row["timestamp"])

        if start_time and end_time and start_time > 0 and end_time > 0:
            return max(0.0, (end_time - start_time) / 1000.0)

        # Fallback: first/last timestamp in events  
        times = (
            event_log_df.select(col("properties.Timestamp").alias("ts"))
            .agg(
                spark_min("ts").alias("min_time"),
                spark_max("ts").alias("max_time")
            )
            .collect()[0]
        )
        
        min_time = safe_float_conversion(times["min_time"])
        max_time = safe_float_conversion(times["max_time"])
        
        if min_time > 0 and max_time > 0:
            return max(0.0, (max_time - min_time) / 1000.0)

        return 0.0

    except Exception as e:
        print(f"⚠️ Error computing application runtime: {e}")
        return 0.0

def compute_accurate_driver_metrics(event_log_df: DataFrame) -> Dict[str, float]:
    """
    Heuristic driver metrics derived from app duration.
    
    Args:
        event_log_df: DataFrame containing Spark event logs
        
    Returns:
        Dict[str, float]: Driver metrics dictionary
    """
    try:
        app_duration = compute_application_runtime(event_log_df)
        if app_duration <= 0:
            return {"driver_active_time_sec": 0.0, "driver_coordination_time_sec": 0.0}

        # Use predefined constants for heuristic calculations
        return {
            "driver_active_time_sec": app_duration * DRIVER_ACTIVE_TIME_FRACTION,
            "driver_coordination_time_sec": app_duration * DRIVER_COORDINATION_TIME_FRACTION
        }
    except Exception as e:
        print(f"⚠️ Error computing driver metrics: {e}")
        return {"driver_active_time_sec": 0.0, "driver_coordination_time_sec": 0.0}

def compute_advanced_executor_metrics(event_log_df: DataFrame) -> Dict[str, float]:
    """
    Compute executor metrics from SparkListenerTaskEnd events with proper cache management.
    
    Args:
        event_log_df: DataFrame containing Spark event logs
        
    Returns:
        Dict[str, float]: Executor metrics dictionary
    """
    task_end_df = None
    task_metrics = None
    
    try:
        task_end_df = event_log_df.filter(col("properties.Event") == "SparkListenerTaskEnd").cache()
        
        if task_end_df.limit(1).count() == 0:
            return {
                "executor_efficiency": 0.0,
                "parallelism_score": 0.0,
                "resource_utilization": 0.0,
                "gc_overhead": 0.0,
                "total_executor_time_sec": 0.0,
                "executor_count": 0
            }

        task_metrics = (
            task_end_df.select(
                (col("properties.Task Metrics.Executor Run Time") / 1000.0).alias("exec_time_sec"),
                (col("properties.Task Metrics.Executor CPU Time") / 1000000.0).alias("cpu_time_sec"), 
                col("properties.Task Metrics.JVM GC Time").alias("gc_time_ms"),
                col("properties.Task Info.Executor ID").alias("executor_id")
            )
            .filter(col("exec_time_sec") > 0)
            .cache()
        )

        if task_metrics.limit(1).count() == 0:
            return {
                "executor_efficiency": 0.0,
                "parallelism_score": DEFAULT_PARALLELISM_SCORE,
                "resource_utilization": 0.0,
                "gc_overhead": 0.0,
                "total_executor_time_sec": 0.0,
                "executor_count": MIN_EXECUTOR_COUNT
            }

        agg = task_metrics.agg(
            spark_sum("exec_time_sec").alias("total_exec_time"),
            spark_sum("cpu_time_sec").alias("total_cpu_time"),
            spark_sum("gc_time_ms").alias("total_gc_time"),
            countDistinct("executor_id").alias("executor_count"),
            count("*").alias("task_count")
        ).collect()[0]

        # Use safe conversion functions
        total_exec_time = safe_float_conversion(agg["total_exec_time"])
        total_cpu_time = safe_float_conversion(agg["total_cpu_time"]) 
        total_gc_time = safe_float_conversion(agg["total_gc_time"])
        executor_count = safe_int_conversion(agg["executor_count"], MIN_EXECUTOR_COUNT)
        task_count = safe_int_conversion(agg["task_count"], 1)

        # Get executor cores with proper fallback
        executor_cores_per_executor = get_executor_cores_config()
        
        # Calculate metrics with safe division
        executor_efficiency = (total_cpu_time / total_exec_time) if total_exec_time > 0 else 0.0
        gc_overhead = ((total_gc_time / 1000.0) / total_exec_time) if total_exec_time > 0 else 0.0
        parallelism_score = min(1.0, task_count / max(1, executor_count * executor_cores_per_executor))
        resource_utilization = min(1.0, executor_efficiency * (1.0 - gc_overhead))

        return {
            "executor_efficiency": max(0.0, min(1.0, executor_efficiency)),
            "parallelism_score": max(0.0, min(1.0, parallelism_score)),
            "resource_utilization": max(0.0, min(1.0, resource_utilization)),
            "gc_overhead": max(0.0, min(1.0, gc_overhead)),
            "total_executor_time_sec": total_exec_time,
            "executor_count": executor_count
        }

    except Exception as e:
        print(f"⚠️ Error computing executor metrics: {e}")
        return {
            "executor_efficiency": 0.0,
            "parallelism_score": DEFAULT_PARALLELISM_SCORE,
            "resource_utilization": 0.0,
            "gc_overhead": 0.0,
            "total_executor_time_sec": 0.0,
            "executor_count": MIN_EXECUTOR_COUNT
        }
    finally:
        # Proper cache cleanup
        safe_unpersist_dataframe(task_end_df, "task_end_df")
        safe_unpersist_dataframe(task_metrics, "task_metrics")

def analyze_workload_characteristics(event_log_df: DataFrame, task_metrics_df: DataFrame) -> Dict[str, Any]:
    """
    Simple workload characterization using skew + IO ratio with proper cache management.
    
    Args:
        event_log_df: DataFrame containing Spark event logs
        task_metrics_df: DataFrame containing task metrics
        
    Returns:
        Dict[str, Any]: Workload characteristics
    """
    try:
        if task_metrics_df.limit(1).count() == 0:
            return {"workload_type": "unknown", "coefficient_of_variation": 0.0, "io_compute_ratio": 0.0}

        stats = task_metrics_df.agg(
            avg("executor_run_time_sec").alias("avg_duration"),
            stddev("executor_run_time_sec").alias("stddev_duration"),
            spark_sum("input_mb").alias("total_input"),
            spark_sum("output_mb").alias("total_output"),
            spark_sum("shuffle_read_mb").alias("total_shuffle_read"),
            spark_sum("shuffle_write_mb").alias("total_shuffle_write")
        ).collect()[0]

        # Use safe conversions
        avg_d = safe_float_conversion(stats["avg_duration"])
        std_d = safe_float_conversion(stats["stddev_duration"])
        total_io = (safe_float_conversion(stats["total_input"]) + 
                   safe_float_conversion(stats["total_output"]) +
                   safe_float_conversion(stats["total_shuffle_read"]) + 
                   safe_float_conversion(stats["total_shuffle_write"]))

        # Calculate coefficients
        cov = (std_d / avg_d) if avg_d > 0 else 0.0
        app_duration = compute_application_runtime(event_log_df)
        io_compute_ratio = (total_io / max(1.0, app_duration)) if app_duration > 0 else 0.0

        # Use predefined thresholds
        if cov > SKEW_THRESHOLD:
            workload_type = "skewed"
        elif io_compute_ratio > IO_BOUND_THRESHOLD:
            workload_type = "io_bound"
        elif io_compute_ratio < COMPUTE_BOUND_THRESHOLD:
            workload_type = "compute_bound"
        else:
            workload_type = "balanced"

        return {
            "workload_type": workload_type, 
            "coefficient_of_variation": cov, 
            "io_compute_ratio": io_compute_ratio
        }

    except Exception as e:
        print(f"⚠️ Error analyzing workload characteristics: {e}")
        return {"workload_type": "unknown", "coefficient_of_variation": 0.0, "io_compute_ratio": 0.0}

# ==============================
# FALLBACK DATAFRAME CREATORS  
# ==============================

def create_fallback_summary(app_id: str) -> DataFrame:
    """Create fallback summary DataFrame with proper schema alignment."""
    rows = [Row(
        stage_id=0,
        stage_attempt_id=0,
        num_tasks=0,
        successful_tasks=0,
        failed_tasks=0,
        min_duration_sec=0.0,
        max_duration_sec=0.0,
        avg_duration_sec=0.0,
        p75_duration_sec=0.0,
        avg_shuffle_read_mb=0.0,
        max_shuffle_read_mb=0.0,
        avg_shuffle_read_records=0.0,
        max_shuffle_read_records=0,
        avg_shuffle_write_mb=0.0,
        max_shuffle_write_mb=0.0,
        avg_shuffle_write_records=0.0,
        max_shuffle_write_records=0,
        avg_input_mb=0.0,
        max_input_mb=0.0,
        avg_input_records=0.0,
        max_input_records=0,
        avg_output_mb=0.0,
        max_output_mb=0.0,
        avg_output_records=0.0,
        max_output_records=0,
        min_launch_time=0,
        max_finish_time=0,
        num_executors=0,
        stage_execution_time_sec=0.0,
        app_id=str(app_id)
    )]
    return spark.createDataFrame(rows, schema=SUMMARY_SCHEMA)

def create_fallback_metrics(app_id: str) -> DataFrame:
    """Create fallback metrics DataFrame."""
    rows = [
        Row(app_id=str(app_id), metric="Application Duration (sec)", value=0.0),
        Row(app_id=str(app_id), metric="Analysis Type", value=0.0),
        Row(app_id=str(app_id), metric="Driver Active Time (sec)", value=0.0),
        Row(app_id=str(app_id), metric="Executor Efficiency", value=0.0),
        Row(app_id=str(app_id), metric="Parallelism Score", value=0.0),
        Row(app_id=str(app_id), metric="Resource Utilization", value=0.0),
        Row(app_id=str(app_id), metric="GC Overhead", value=0.0),
        Row(app_id=str(app_id), metric="Total Executor Time (sec)", value=0.0),
        Row(app_id=str(app_id), metric="Executor Count", value=0.0)
    ]
    return spark.createDataFrame(rows, schema=METRICS_SCHEMA)

def create_fallback_predictions(app_id: str) -> DataFrame:
    """Create fallback predictions DataFrame with schema-aligned fields."""
    rows = [Row(**{
        "Executor Count": 0,                               # Match schema field names exactly
        "Executor Multiplier": "N/A",
        "Estimated Executor WallClock": "0m 0s", 
        "Estimated Total Duration": "0m 0s",
        "app_id": str(app_id)
    })]
    return spark.createDataFrame(rows, schema=PREDICTIONS_SCHEMA)

def create_fallback_recommendations(app_id: str) -> DataFrame:
    """Create fallback recommendations DataFrame."""
    msgs = [
        "⚠️ ANALYSIS TYPE 0: No SparkListenerApplicationStart event detected.",
        "🔍 LIKELY CAUSES: Spark session created but no jobs executed, or application failed during initialization.",
        "💡 RECOMMENDATIONS: Check application logs for initialization errors or ensure Spark operations are actually executed.",
        "🔧 TROUBLESHOOTING: Verify SparkSession is used for data operations (not just imports/setup code)."
    ]
    rows = [Row(app_id=str(app_id), recommendation=str(msg)) for msg in msgs]
    return spark.createDataFrame(rows, schema=RECOMMENDATIONS_SCHEMA)

print("🔧 All enhanced helper functions loaded successfully with proper cache management!")'''),
    # ===== Notebook Cell 7: # === Cell 2: Enhanced Main Analysis Function (Advanced + Fallback) === =====
    (7, r'''# === Cell 2: Enhanced Main Analysis Function (Advanced + Fallback) ===

from pyspark.sql import Row
from pyspark.sql.functions import col, lit, count, countDistinct, avg, expr, stddev
import pyspark.sql.functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType

def compute_advanced_stage_task_summary(event_log_df, metadata_df, app_id):
    """
    Advanced Spark performance analysis with ML-based insights.
    Returns: (summary_df, metrics_df, predictions_df, recommendations_df)
    """
    print(f"🚀 Starting advanced analysis for application: {app_id}")
    try:
        task_end_df = event_log_df.filter(col("properties.Event") == "SparkListenerTaskEnd")

        if task_end_df.limit(1).count() == 0:
            print("⚠️ No task completion events found - performing enhanced basic analysis")
            return compute_enhanced_basic_analysis_fallback(event_log_df, metadata_df, app_id)

        task_metrics_df = task_end_df.select(
            col("properties.Stage ID").cast("string").alias("stage_id"),
            col("properties.Stage Attempt ID").cast("string").alias("stage_attempt_id"),
            col("properties.Task Info.Task ID").cast("long").alias("task_id"),
            col("properties.Task Info.Executor ID").cast("string").alias("executor_id"),
            col("properties.Task Info.Launch Time").cast("long").alias("launch_time"),
            col("properties.Task Info.Finish Time").cast("long").alias("finish_time"),
            col("properties.Task Info.Failed").cast("boolean").alias("failed"),
            (col("properties.Task Metrics.Executor Run Time") / 1000.0).alias("executor_run_time_sec"),
            (col("properties.Task Metrics.Executor CPU Time") / 1000000.0).alias("cpu_time_sec"),
            col("properties.Task Metrics.JVM GC Time").cast("double").alias("gc_time_ms"),
            (col("properties.Task Metrics.Input Metrics.Bytes Read") / 1024.0 / 1024.0).alias("input_mb"),
            col("properties.Task Metrics.Input Metrics.Records Read").cast("long").alias("input_records"),
            (col("properties.Task Metrics.Shuffle Read Metrics.Remote Bytes Read") / 1024.0 / 1024.0).alias("shuffle_read_mb"),
            col("properties.Task Metrics.Shuffle Read Metrics.Total Records Read").cast("long").alias("shuffle_read_records"),
            (col("properties.Task Metrics.Shuffle Write Metrics.Shuffle Bytes Written") / 1024.0 / 1024.0).alias("shuffle_write_mb"),
            col("properties.Task Metrics.Shuffle Write Metrics.Shuffle Records Written").cast("long").alias("shuffle_write_records"),
            (col("properties.Task Metrics.Output Metrics.Bytes Written") / 1024.0 / 1024.0).alias("output_mb"),
            col("properties.Task Metrics.Output Metrics.Records Written").cast("long").alias("output_records"),
        ).filter(col("failed") == F.lit(False))

        app_duration_sec = compute_application_runtime(event_log_df)
        driver_metrics = compute_accurate_driver_metrics(event_log_df)
        executor_metrics = compute_advanced_executor_metrics(event_log_df)
        workload_analysis = analyze_workload_characteristics(event_log_df, task_metrics_df)

        stage_summary_df = task_metrics_df.groupBy("stage_id", "stage_attempt_id").agg(
            count("task_id").alias("num_tasks"),
            count(expr("CASE WHEN failed = false THEN 1 END")).alias("successful_tasks"),
            count(expr("CASE WHEN failed = true THEN 1 END")).alias("failed_tasks"),
            F.min("executor_run_time_sec").alias("min_duration_sec"),
            F.max("executor_run_time_sec").alias("max_duration_sec"),
            avg("executor_run_time_sec").alias("avg_duration_sec"),
            stddev("executor_run_time_sec").alias("stddev_duration_sec"),
            expr("percentile_approx(executor_run_time_sec, 0.75)").alias("p75_duration_sec"),
            expr("percentile_approx(executor_run_time_sec, 0.95)").alias("p95_duration_sec"),
            avg("cpu_time_sec").alias("avg_cpu_time_sec"),
            avg("gc_time_ms").alias("avg_gc_time_ms"),
            F.sum("input_mb").alias("total_input_mb"),
            F.sum("shuffle_read_mb").alias("total_shuffle_read_mb"),
            F.sum("shuffle_write_mb").alias("total_shuffle_write_mb"),
            F.sum("output_mb").alias("total_output_mb"),
            countDistinct("executor_id").alias("num_executors_used"),
        )

        stage_duration_df = task_metrics_df.groupBy("stage_id", "stage_attempt_id").agg(
            F.min("launch_time").alias("min_launch_time"),
            F.max("finish_time").alias("max_finish_time"),
        ).withColumn("stage_wall_clock_time_sec", expr("(max_finish_time - min_launch_time) / 1000.0"))

        # Keep output schema consistent with sparklens_summary (4 cols)
        final_summary_df = (
            stage_summary_df.join(stage_duration_df, ["stage_id", "stage_attempt_id"], "left")
            .withColumn("app_id", lit(str(app_id)))
            .withColumn("analysis_type", lit("Analysis Type 2"))
            .withColumn("message", lit("Advanced ML Analysis with full task data"))
            .select("app_id", "stage_id", "analysis_type", "message")
            .orderBy(col("stage_id"))
            .limit(10)
        )

        enhanced_metrics = [
            ("Application Duration (sec)", app_duration_sec),
            ("Driver Active Time (sec)", driver_metrics.get("driver_active_time_sec", 0.0)),
            ("Driver Coordination Time (sec)", driver_metrics.get("driver_coordination_time_sec", 0.0)),
            ("Executor Efficiency", executor_metrics.get("executor_efficiency", 0.0)),
            ("Parallelism Score", executor_metrics.get("parallelism_score", 0.0)),
            ("Resource Utilization", executor_metrics.get("resource_utilization", 0.0)),
            ("GC Overhead", executor_metrics.get("gc_overhead", 0.0)),
            ("Total Executor Time (sec)", executor_metrics.get("total_executor_time_sec", 0.0)),
            ("Executor Count", float(executor_metrics.get("executor_count", 0))),
            ("Workload Skew (CoV)", workload_analysis.get("coefficient_of_variation", 0.0)),
            ("IO/Compute Ratio", workload_analysis.get("io_compute_ratio", 0.0)),
            ("Analysis Type", 2.0),
        ]
        metrics_rows = [Row(app_id=str(app_id), metric=k, value=float(v)) for k, v in enhanced_metrics]
        metrics_df = spark.createDataFrame(metrics_rows, schema=METRICS_SCHEMA)

        predictions_df = estimate_enhanced_runtime_scaling(
            app_id=str(app_id),
            task_df=task_metrics_df,
            driver_metrics=driver_metrics,
            executor_metrics=executor_metrics,
            app_duration_sec=app_duration_sec
        )

        recommendations_df = generate_enhanced_recommendations(
            app_id=str(app_id),
            app_duration_sec=app_duration_sec,
            driver_metrics=driver_metrics,
            executor_metrics=executor_metrics,
            workload_analysis=workload_analysis,
            metadata_df=metadata_df,
            task_df=task_metrics_df
        )

        return final_summary_df, metrics_df, predictions_df, recommendations_df

    except Exception as e:
        print(f"⚠️ Advanced analysis failed, falling back to enhanced basic analysis: {str(e)}")
        return compute_enhanced_basic_analysis_fallback(event_log_df, metadata_df, app_id)

def estimate_enhanced_runtime_scaling(app_id, task_df, driver_metrics, executor_metrics, app_duration_sec):
    """
    Enhanced runtime scaling estimation.
    Output schema matches PREDICTIONS_SCHEMA.
    """
    print("📈 Computing enhanced runtime scaling predictions...")
    try:
        total_executor_time = float(executor_metrics.get("total_executor_time_sec", 0.0))
        parallelism_score = float(executor_metrics.get("parallelism_score", 0.0))
        executor_count = int(executor_metrics.get("executor_count", 1) or 1)
        driver_time = float(driver_metrics.get("driver_active_time_sec", 0.0))
        executor_efficiency = float(executor_metrics.get("executor_efficiency", 0.0))

        if total_executor_time < 1 or executor_count < 1 or app_duration_sec < 1:
            rows = [Row(
                app_id=str(app_id),
                executor_multiplier="Current",
                executor_count=max(1, executor_count),
                estimated_executor_wallclock_sec=float(total_executor_time),
                estimated_total_duration_sec=float(app_duration_sec),
                estimated_total_duration_min=f"{int(app_duration_sec // 60)}m {int(app_duration_sec % 60)}s",
                speedup_factor=1.0,
                efficiency_rating="No Analysis",
                scaling_recommendation="Insufficient data for scaling predictions",
                bottleneck_analysis="Data Quality Issue"
            )]
            return spark.createDataFrame(rows, schema=PREDICTIONS_SCHEMA)

        predictions = []
        driver_ratio = (driver_time / app_duration_sec) if app_duration_sec > 0 else 0.0
        is_driver_bound = driver_ratio > 0.3
        is_low_parallelism = parallelism_score < 0.4
        is_inefficient = executor_efficiency < 0.5

        for multiplier in [0.5, 1.0, 1.5, 2.0, 4.0]:
            new_executor_count = max(1, int(executor_count * multiplier))

            if is_driver_bound:
                efficiency_degradation = 0.95 if multiplier <= 1.0 else max(0.7, 1.0 - (multiplier - 1.0) * 0.1)
                scaling_benefit = min(1.2, 1.0 + (multiplier - 1.0) * 0.1)
                recommendation = "Driver-bound: Scaling executors provides limited benefit. Focus on reducing driver operations."
            elif is_low_parallelism:
                efficiency_degradation = 0.9 if multiplier <= 1.5 else max(0.6, 1.0 - (multiplier - 1.0) * 0.15)
                scaling_benefit = min(1.5, multiplier * 0.6)
                recommendation = "Low parallelism: Increase data partitions before scaling executors for better results."
            elif is_inefficient:
                efficiency_degradation = 0.85 if multiplier <= 1.0 else max(0.5, 0.85 - (multiplier - 1.0) * 0.15)
                scaling_benefit = min(1.8, multiplier * 0.7)
                recommendation = "Low task efficiency: Code optimization will provide better gains than scaling."
            else:
                efficiency_degradation = min(1.0, 1.0 - (multiplier - 1.0) * 0.03)
                scaling_benefit = min(multiplier * 0.95, multiplier * parallelism_score + 0.2)
                recommendation = "Well-optimized: Good scaling potential with executor increase."

            new_parallel_work = total_executor_time * parallelism_score / max(1e-9, scaling_benefit)
            sequential_work = total_executor_time * (1.0 - parallelism_score)
            new_executor_time = new_parallel_work + sequential_work

            coordination_overhead = driver_time * (0.05 + multiplier * 0.02)
            new_total_time = max(driver_time + coordination_overhead, new_executor_time * efficiency_degradation)

            speedup = (app_duration_sec / new_total_time) if new_total_time > 0 else 1.0
            efficiency_score = (speedup / multiplier) if multiplier > 0 else 0.0

            if efficiency_score > 0.8:
                efficiency_rating = "Excellent"
            elif efficiency_score > 0.6:
                efficiency_rating = "Good"
            elif efficiency_score > 0.4:
                efficiency_rating = "Fair"
            else:
                efficiency_rating = "Poor"

            if driver_ratio > 0.3:
                bottleneck = "Driver Coordination"
            elif parallelism_score < 0.4:
                bottleneck = "Low Parallelism"
            elif executor_efficiency < 0.5:
                bottleneck = "Task Inefficiency"
            else:
                bottleneck = "Well Balanced"

            predictions.append(Row(
                app_id=str(app_id),
                executor_multiplier=f"{multiplier:.1f}x" if multiplier != 1.0 else "Current",
                executor_count=int(new_executor_count),
                estimated_executor_wallclock_sec=float(new_executor_time),
                estimated_total_duration_sec=float(new_total_time),
                estimated_total_duration_min=f"{int(new_total_time // 60)}m {int(new_total_time % 60)}s",
                speedup_factor=float(speedup),
                efficiency_rating=str(efficiency_rating),
                scaling_recommendation=str(recommendation),
                bottleneck_analysis=str(bottleneck),
            ))

        return spark.createDataFrame(predictions, schema=PREDICTIONS_SCHEMA)

    except Exception as e:
        print(f"⚠️ Scaling prediction error: {str(e)}")
        rows = [Row(
            app_id=str(app_id),
            executor_multiplier="Error",
            executor_count=0,
            estimated_executor_wallclock_sec=0.0,
            estimated_total_duration_sec=0.0,
            estimated_total_duration_min="N/A",
            speedup_factor=0.0,
            efficiency_rating="Error",
            scaling_recommendation="Unable to calculate scaling predictions due to data issues",
            bottleneck_analysis="Analysis Error"
        )]
        return spark.createDataFrame(rows, schema=PREDICTIONS_SCHEMA)

def generate_enhanced_recommendations(app_id, app_duration_sec, driver_metrics, executor_metrics, workload_analysis, metadata_df, task_df):
    """
    Generate enhanced recommendations. Output schema matches RECOMMENDATIONS_SCHEMA.
    """
    print("🎯 Generating enhanced performance recommendations...")
    recs = []
    try:
        driver_time = float(driver_metrics.get("driver_active_time_sec", 0.0))
        executor_efficiency = float(executor_metrics.get("executor_efficiency", 0.0))
        parallelism_score = float(executor_metrics.get("parallelism_score", 0.0))
        gc_overhead = float(executor_metrics.get("gc_overhead", 0.0))
        driver_ratio = (driver_time / app_duration_sec) if app_duration_sec > 0 else 0.0

        if executor_efficiency < 0.3:
            recs.append(f"🚨 CRITICAL: Very low executor CPU efficiency ({executor_efficiency:.1%}). OPTIMIZE CODE BEFORE SCALING.")
            recs.append("💡 ACTION: Profile code, reduce serialization/object churn, improve algorithms.")
        if gc_overhead > 0.2:
            recs.append(f"🚨 CRITICAL: High GC overhead ({gc_overhead:.1%}). Increase memory / reduce allocation pressure.")
            recs.append("💡 ACTION: Increase spark.executor.memory, tune GC, reduce object lifetime.")
        if driver_ratio > 0.4:
            recs.append(f"🚨 CRITICAL: Driver bottleneck ({driver_ratio:.1%} of runtime). Scaling executors won't help much.")
            recs.append("💡 ACTION: Avoid collect()/take() on large data; reduce driver-side work.")

        if driver_ratio <= 0.4:
            if parallelism_score < 0.4:
                recs.append(f"⚖️ SCALING OPPORTUNITY: Low parallelism ({parallelism_score:.1%}). Increase partitions before adding executors.")
            elif executor_efficiency > 0.6 and parallelism_score > 0.6:
                recs.append(f"🚀 GOOD SCALING CANDIDATE: High efficiency ({executor_efficiency:.1%}) and parallelism ({parallelism_score:.1%}).")

        workload_type = workload_analysis.get("workload_type", "unknown")
        if workload_type == "io_bound":
            recs.append("📁 IO-BOUND: Focus on storage/format/caching; scaling may have limited benefit.")
        elif workload_type == "compute_bound":
            recs.append("💻 COMPUTE-BOUND: Scaling executors/cores likely helps if efficiency remains good.")
        elif workload_type == "skewed":
            recs.append("📊 SKEW: Fix skew (salting/custom partitioning/AQE) before scaling.")

        overall_score = (executor_efficiency + parallelism_score + (1.0 - gc_overhead)) / 3.0
        if overall_score > 0.75:
            recs.append("⭐ EXCELLENT: Well-optimized; scaling is a reasonable lever.")
        elif overall_score > 0.5:
            recs.append("✅ GOOD: Mix of code tuning + careful scaling.")
        else:
            recs.append("⚠️ NEEDS IMPROVEMENT: Optimize code/data layout before scaling.")

        if driver_ratio < 0.3 and parallelism_score > 0.4 and executor_efficiency > 0.5:
            recs.append("🎯 SCALING VERDICT: ✅ Good candidate for executor scaling.")
        else:
            recs.append("🎯 SCALING VERDICT: ❌ Optimize before scaling executors.")

    except Exception as e:
        print(f"⚠️ Enhanced recommendation generation error: {str(e)}")
        recs = ["Unable to generate detailed recommendations due to insufficient event data."]

    rows = [Row(app_id=str(app_id), recommendation=str(r)) for r in (recs or ["No recommendations."])]
    return spark.createDataFrame(rows, schema=RECOMMENDATIONS_SCHEMA)

def detect_application_type(event_log_df):
    """
    Detect application type based on presence of Spark events.
    """
    print("🔍 Detecting application type and analyzing available events...")
    try:
        spark_events = [
            "SparkListenerApplicationStart",
            "SparkListenerApplicationEnd",
            "SparkListenerJobStart",
            "SparkListenerJobEnd",
            "SparkListenerStageSubmitted",
            "SparkListenerStageCompleted",
            "SparkListenerTaskStart",
            "SparkListenerTaskEnd",
            "SparkListenerExecutorAdded",
            "SparkListenerExecutorRemoved",
        ]

        total_events = event_log_df.count()
        event_counts = {}
        for ev in spark_events:
            c = event_log_df.filter(col("properties.Event") == ev).count()
            if c > 0:
                event_counts[ev] = c

        has_app_events = "SparkListenerApplicationStart" in event_counts
        has_job_events = "SparkListenerJobStart" in event_counts
        has_task_events = "SparkListenerTaskEnd" in event_counts

        if not has_app_events:
            return {
                "app_type": "Non-Spark Application",
                "analysis_type": -1,
                "analysis_capability": "No Spark events detected",
                "total_events": total_events,
                "event_counts": event_counts,
                "has_job_execution": has_job_events,
                "has_task_execution": has_task_events
            }
        if not has_job_events:
            return {
                "app_type": "Spark Context Only",
                "analysis_type": 0,
                "analysis_capability": "Spark session created but no jobs executed",
                "total_events": total_events,
                "event_counts": event_counts,
                "has_job_execution": has_job_events,
                "has_task_execution": has_task_events
            }
        if not has_task_events:
            return {
                "app_type": "Spark Jobs Without Tasks",
                "analysis_type": 0,
                "analysis_capability": "Jobs submitted but no task completion events",
                "total_events": total_events,
                "event_counts": event_counts,
                "has_job_execution": has_job_events,
                "has_task_execution": has_task_events
            }

        task_end_count = int(event_counts.get("SparkListenerTaskEnd", 0))
        if task_end_count < 10:
            return {
                "app_type": "Minimal Spark Execution",
                "analysis_type": 1,
                "analysis_capability": f"Only {task_end_count} tasks completed - limited analysis",
                "total_events": total_events,
                "event_counts": event_counts,
                "has_job_execution": has_job_events,
                "has_task_execution": has_task_events
            }

        return {
            "app_type": "Full Spark Application",
            "analysis_type": 2,
            "analysis_capability": f"Complete Spark execution with {task_end_count} tasks - full analysis",
            "total_events": total_events,
            "event_counts": event_counts,
            "has_job_execution": has_job_events,
            "has_task_execution": has_task_events
        }

    except Exception as e:
        print(f"⚠️ Application type detection error: {str(e)}")
        return {
            "app_type": "Unknown",
            "analysis_type": -2,
            "analysis_capability": "Detection error",
            "total_events": 0,
            "event_counts": {},
            "error": str(e)
        }

def compute_enhanced_basic_analysis_fallback(event_log_df, metadata_df, app_id):
    """
    Fallback analysis for missing/limited events.
    Returns: (summary_df, metrics_df, predictions_df, recommendations_df)
    """
    print("📊 Performing enhanced basic analysis with application type detection...")

    app_duration_sec = compute_application_runtime(event_log_df)
    det = detect_application_type(event_log_df)

    analysis_type = float(det.get("analysis_type", 0))
    app_type = det.get("app_type", "Unknown")
    capability = det.get("analysis_capability", "Limited analysis")

    summary_rows = [Row(
        app_id=str(app_id),
        stage_id="analysis_summary",
        analysis_type=str(app_type),
        message=f"Application Type: {app_type} | Duration: {app_duration_sec:.2f}s | {capability}"
    )]
    summary_df = spark.createDataFrame(summary_rows, schema=SUMMARY_SCHEMA)

    metrics_rows = [
        Row(app_id=str(app_id), metric="Application Duration (sec)", value=float(app_duration_sec)),
        Row(app_id=str(app_id), metric="Analysis Type", value=float(analysis_type)),
        Row(app_id=str(app_id), metric="Total Events", value=float(det.get("total_events", 0))),
        Row(app_id=str(app_id), metric="Task Events", value=float(det.get("event_counts", {}).get("SparkListenerTaskEnd", 0))),
        Row(app_id=str(app_id), metric="Job Events", value=float(det.get("event_counts", {}).get("SparkListenerJobStart", 0))),
        Row(app_id=str(app_id), metric="Stage Events", value=float(det.get("event_counts", {}).get("SparkListenerStageCompleted", 0))),
    ]
    metrics_df = spark.createDataFrame(metrics_rows, schema=METRICS_SCHEMA)

    predictions_rows = [Row(
        app_id=str(app_id),
        executor_multiplier="Current",
        executor_count=1,
        estimated_executor_wallclock_sec=float(app_duration_sec),
        estimated_total_duration_sec=float(app_duration_sec),
        estimated_total_duration_min=f"{int(app_duration_sec // 60)}m {int(app_duration_sec % 60)}s",
        speedup_factor=1.0,
        efficiency_rating="No Analysis",
        scaling_recommendation=f"Application Type: {app_type} - {capability}",
        bottleneck_analysis=str(app_type)
    )]
    predictions_df = spark.createDataFrame(predictions_rows, schema=PREDICTIONS_SCHEMA)

    if analysis_type == -1:
        rec_msgs = [
            "🔍 NON-SPARK APPLICATION: No Spark events detected.",
            "💡 RECOMMENDATION: No Spark performance optimization needed."
        ]
    elif analysis_type == 0 and not det.get("has_job_execution", False):
        rec_msgs = [
            "⚙️ SPARK CONTEXT ONLY: Spark session created but no jobs executed.",
            "💡 RECOMMENDATION: Ensure Spark actions are triggered (e.g., write/count/show) and not only lazy transforms."
        ]
    elif analysis_type == 0:
        rec_msgs = [
            "⚠️ JOBS WITHOUT TASKS: Jobs submitted but no task completion events.",
            "💡 RECOMMENDATION: Check for failures, resource constraints, or premature termination."
        ]
    elif analysis_type == 1:
        tcnt = det.get("event_counts", {}).get("SparkListenerTaskEnd", 0)
        rec_msgs = [
            f"📊 MINIMAL EXECUTION: Only {tcnt} tasks completed - limited performance analysis.",
            "💡 RECOMMENDATION: Run larger workloads to generate richer event logs for analysis."
        ]
    else:
        rec_msgs = ["📊 Basic analysis completed. Enable richer event logging for deeper insights."]

    rec_rows = [Row(app_id=str(app_id), recommendation=str(m)) for m in rec_msgs]
    rec_df = spark.createDataFrame(rec_rows, schema=RECOMMENDATIONS_SCHEMA)

    print("🎯 Enhanced basic analysis completed.")
    return summary_df, metrics_df, predictions_df, rec_df

print("🎯 Enhanced performance analysis functions loaded successfully!")'''),
    # ===== Notebook Cell 8: # === Cell 3: Metadata extraction (safe) === =====
    (8, r'''# === Cell 3: Metadata extraction (safe) ===

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit

# Global variable for executor cores configuration
global_executor_cores = None

def get_executor_cores_config():
    """
    Get executor cores configuration with proper fallback.
    This function works in both regular and distributed execution contexts.
    """
    global global_executor_cores
    return global_executor_cores or DEFAULT_EXECUTOR_CORES

def extract_app_metadata(df: DataFrame) -> DataFrame:
    """
    Extract application metadata with safe native execution engine and executor cores detection
    """
    global global_executor_cores
    
    print("📋 Extracting application metadata...")

    def _first_nonnull(expr: str, alias: str):
        try:
            rows = (
                df.selectExpr(f"{expr} AS {alias}")
                  .filter(col(alias).isNotNull())
                  .distinct()
                  .limit(1)
                  .collect()
            )
            if rows:
                return rows[0][alias]
        except Exception:
            # Best-effort: schema varies by event type.
            pass
        return None

    native_enabled = _first_nonnull("properties.`Spark Properties`.`spark.native.enabled`", "spark_native_enabled")
    if native_enabled is None:
        # Fabric event logs often embed Spark config under a nested `Properties` dict
        # (e.g., SparkListenerJobStart), so fall back to that structure.
        native_enabled = _first_nonnull("properties.`Properties`.`spark.native.enabled`", "spark_native_enabled")

    if native_enabled is not None:
        print(f"✅ Native Execution Engine enabled: {native_enabled}")
    else:
        print("ℹ️ Native Execution Engine setting not found - using default")

    # Extract high concurrency flag from Spark config.
    high_concurrency_val = _first_nonnull(
        "properties.`Spark Properties`.`spark.trident.highconcurrency.enabled`",
        "spark_high_concurrency_enabled",
    )
    if high_concurrency_val is None:
        high_concurrency_val = _first_nonnull(
            "properties.`Properties`.`spark.trident.highconcurrency.enabled`",
            "spark_high_concurrency_enabled",
        )

    high_concurrency_enabled = None
    if high_concurrency_val is not None:
        try:
            if isinstance(high_concurrency_val, bool):
                high_concurrency_enabled = high_concurrency_val
            else:
                high_concurrency_enabled = str(high_concurrency_val).strip().lower() == "true"
        except Exception:
            high_concurrency_enabled = None

    # Extract spark.executor.cores configuration
    executor_cores_val = _first_nonnull("properties.`Spark Properties`.`spark.executor.cores`", "spark_executor_cores")
    if executor_cores_val is None:
        executor_cores_val = _first_nonnull("properties.`Properties`.`spark.executor.cores`", "spark_executor_cores")

    if executor_cores_val is not None:
        try:
            global_executor_cores = int(executor_cores_val)
            print(f"✅ Executor cores extracted from config: {global_executor_cores}")
        except Exception as e:
            print(f"⚠️ Warning: Could not parse executor cores setting: {e}")
            global_executor_cores = 8
    else:
        # Fallback: try to detect from executor info or use reasonable default
        print("ℹ️ spark.executor.cores not found in properties - using fallback logic")
        global_executor_cores = 8  # Default fallback value

    try:
        metadata_df = (
            df.select(
                "applicationId", "applicationName", "artifactId", "artifactType", "capacityId",
                "executorMax", "executorMin", "fabricEnvId", "fabricLivyId", "fabricTenantId",
                "fabricWorkspaceId", "isHighConcurrencyEnabled"
            )
            .distinct()
            .withColumn("spark.native.enabled", lit(native_enabled))
            .withColumn("spark.executor.cores", lit(global_executor_cores))
        )

        if high_concurrency_enabled is not None:
            metadata_df = metadata_df.withColumn("isHighConcurrencyEnabled", lit(bool(high_concurrency_enabled)))

        print("✅ Application metadata extracted successfully")
        return metadata_df

    except Exception as e:
        print(f"❌ Error extracting metadata: {e}")
        return df.select("applicationId").distinct().withColumn("spark.native.enabled", lit(None)).withColumn("spark.executor.cores", lit(global_executor_cores))'''),
    # ===== Notebook Cell 9: # === Enhanced pipeline - Using proven schema inference from old code === =====
    (9, r'''# === Enhanced pipeline - Using proven schema inference from old code ===

import json
from typing import Dict, Any, List

import pandas as pd
import numpy as np

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit, get_json_object, expr
from pyspark.sql.types import (
    StructType, StructField,
    StringType, IntegerType, DoubleType, BooleanType
)

# ----------------------------
# Configuration / Kusto queries
# ----------------------------
kustoQuery = """
RawLogs
"""

applicationIDsQuery = """
union isfuzzy=true
(
    sparklens_errors
    | project applicationID
    | distinct applicationID
),
(
    sparklens_metadata
    | project applicationId
    | distinct applicationID=applicationId
)
"""

# ----------------------------
# NOTE: Schema definitions are imported from Cell 2
# Using METADATA_SCHEMA, SUMMARY_SCHEMA, METRICS_SCHEMA, PREDICTIONS_SCHEMA, RECOMMENDATIONS_SCHEMA
# ----------------------------

# ----------------------------
# Optimized Kusto IO with token caching
# ----------------------------
_cached_token = None

def get_cached_token():
    global _cached_token
    if _cached_token is None:
        _cached_token = mssparkutils.credentials.getToken(kustoUri)
    return _cached_token

def read_kusto_df(query: str) -> DataFrame:
    return (
        spark.read
        .format("com.microsoft.kusto.spark.synapse.datasource")
        .option("accessToken", get_cached_token())
        .option("kustoCluster", kustoUri)
        .option("kustoDatabase", database)
        .option("kustoQuery", query)
        .load()
    )

def write_kusto_df(df: DataFrame, table: str, mode: str = "Append") -> None:
    row_count = df.count()
    optimized_df = df.coalesce(min(4, max(1, row_count // 1000))) if row_count < 10000 else df
    (
        optimized_df.write
        .format("com.microsoft.kusto.spark.synapse.datasource")
        .option("accessToken", get_cached_token())
        .option("kustoCluster", kustoUri)
        .option("kustoDatabase", database)
        .option("kustoTable", table)
        .option("tableCreateOptions", "CreateIfNotExist")
        .mode(mode)
        .save()
    )

# ----------------------------
# Optimized schema inference with caching
# ----------------------------
_schema_cache = {}

def infer_and_flatten_schema_optimized(event_log_df, schema_key="spark_events"):
    """Optimized schema inference with intelligent caching"""
    global _schema_cache
    if schema_key not in _schema_cache:
        print(f"Inferring schema for {schema_key}...")
        sample_json_df = event_log_df.select("records").limit(100)
        json_rdd = sample_json_df.rdd.map(lambda r: r[0])
        inferred_schema = spark.read.json(json_rdd).schema
        _schema_cache[schema_key] = inferred_schema
        print(f"Schema cached for reuse")
    else:
        print(f"Reusing cached schema for {schema_key}")
    inferred_schema = _schema_cache[schema_key]
    parsed_df = event_log_df.withColumn("records_parsed", F.from_json(F.col("records"), inferred_schema))
    flattened_df = parsed_df.select("*", "records_parsed.*").drop("records_parsed")
    return flattened_df

infer_and_flatten_schema = infer_and_flatten_schema_optimized

# ----------------------------
# Step 1: Read raw logs + previously processed app IDs
# ----------------------------
raw_df = read_kusto_df(kustoQuery).cache()
processed_ids_df_raw = read_kusto_df(applicationIDsQuery)

print("Data loaded successfully")

# ----------------------------
# Step 2: EventLog filtering
# ----------------------------
event_log_df = (
    raw_df
    .filter(get_json_object(col("records"), "$.category") == lit("EventLog"))
    .withColumn("applicationId_raw", get_json_object(col("records"), "$.applicationId"))
    .filter(col("applicationId_raw").isNotNull())
    .repartition(10, col("applicationId_raw"))
    .cache()
)

processed_ids_df = (
    processed_ids_df_raw
    .select(
        F.coalesce(
            col("applicationId").cast("string"),
            col("applicationID").cast("string")
        ).alias("applicationId")
    )
    .filter(col("applicationId").isNotNull())
    .distinct()
)

before_count = event_log_df.count()
processed_ids_count = processed_ids_df.count()
unique_app_ids = event_log_df.select("applicationId_raw").distinct().count()

print(f"Before filtering: {before_count} event records")
print(f"Unique application IDs in event logs: {unique_app_ids}")
print(f"Previously processed application IDs: {processed_ids_count}")

if before_count > 0:
    print("Sample application IDs from event logs:")
    event_log_df.select("applicationId_raw").distinct().limit(5).show(truncate=False)

if processed_ids_count > 0:
    print("Sample processed application IDs:")
    processed_ids_df.limit(5).show(truncate=False)

if processed_ids_count > 0:
    print(f"Applying anti-join to exclude {processed_ids_count} already processed applications...")
    event_log_df = event_log_df.join(
        processed_ids_df,
        event_log_df["applicationId_raw"] == processed_ids_df["applicationId"],
        how="left_anti"
    ).cache()
    after_count = event_log_df.count()
    filtered_out = before_count - after_count
    print(f"After anti-join filtering: {after_count} event records ({filtered_out} filtered out)")
else:
    print("No processed IDs found - proceeding with all event records")
    after_count = before_count

if after_count == 0:
    if before_count == 0:
        print("No event log records found at all. Check your raw data source.")
    elif processed_ids_count > 0 and before_count > 0:
        print("All records have already been processed - no new applications to analyze.")
        print("   Total applications previously processed: " + str(processed_ids_count))
        print("   This is normal when running incrementally on the same dataset.")
    else:
        print("No records to process for unknown reasons.")
    print("\nCOMPLETION: No new records to process in this run.")
    print("TIP: New applications will be analyzed in the next run when data arrives.")
    print("="*80)

# Define helper functions at module level
OUTPUT_SCHEMA = StructType([
    StructField("applicationId", StringType(), False),
    StructField("dataset", StringType(), False),
    StructField("payload_json", StringType(), False),
])

def _safe_get(dct: Any, path: List[str], default=None):
    cur = dct
    for p in path:
        if not isinstance(cur, dict) or p not in cur:
            return default
        cur = cur[p]
    return cur

def _parse_record(rec_str: str) -> Dict[str, Any]:
    try:
        return json.loads(rec_str) if rec_str else {}
    except Exception:
        return {}

def _to_float(x, default=0.0):
    try:
        if x is None:
            return float(default)
        return float(x)
    except Exception:
        return float(default)

def _to_int(x, default=0):
    try:
        if x is None:
            return int(default)
        return int(x)
    except Exception:
        return int(default)

def safe_percentile(data, percentile):
    if not data:
        return 0.0
    try:
        return float(np.percentile(data, percentile))
    except Exception:
        sorted_data = sorted(data)
        n = len(sorted_data)
        index = int(percentile / 100.0 * (n - 1))
        return float(sorted_data[min(index, n-1)])

def safe_avg(data):
    return float(sum(data) / len(data)) if data else 0.0

def safe_max(data):
    return float(max(data)) if data else 0.0

def safe_min(data):
    return float(min(data)) if data else 0.0

def safe_max_int(data):
    return int(max(data)) if data else 0

def per_app_analyzer(pdf: pd.DataFrame) -> pd.DataFrame:
    """
    Enhanced groupBy(applicationId).applyInPandas with comprehensive analysis.
    Input:  pd.DataFrame - all rows for one applicationId group.
    Output: pd.DataFrame with columns (applicationId, dataset, payload_json).
    """
    if pdf is None or pdf.empty:
        return pd.DataFrame(columns=["applicationId", "dataset", "payload_json"])

    app_id = str(pdf["applicationId"].iloc[0])
    print(f"Processing {app_id}")

    events = []
    app_start_props = None
    first_record = None

    for r in pdf["records"].astype(str).tolist() if "records" in pdf.columns else []:
        full_obj = _parse_record(r)
        if first_record is None:
            first_record = full_obj
        props = full_obj.get("properties", {}) if isinstance(full_obj, dict) else {}
        ev = props.get("Event")
        ts = props.get("Timestamp")
        events.append((ev, ts, props))
        if ev == "SparkListenerApplicationStart":
            app_start_props = props

    has_start = app_start_props is not None
    out_rows = []

    # ---- Metadata extraction ----
    if app_start_props or first_record:
        app_name = "Unknown Application"
        spark_props = {}
        if app_start_props:
            app_name = app_start_props.get("App Name", "Unknown Application")
            spark_props = app_start_props.get("Spark Properties", {})

        def _first_nonnull_prop(prop_key: str):
            """Best-effort property lookup across event shapes.

            NOTE: Best-practice checks are intentionally based on SparkListenerApplicationStart
            Spark Properties, but some Fabric event logs (e.g., SparkListenerJobStart)
            carry cluster Spark configs under a nested `Properties` dict.
            """

            if isinstance(spark_props, dict):
                v = spark_props.get(prop_key)
                if v is not None:
                    return v

            for _ev, _ts, _p in events:
                if not isinstance(_p, dict):
                    continue
                sp2 = _p.get("Spark Properties")
                if isinstance(sp2, dict):
                    v = sp2.get(prop_key)
                    if v is not None:
                        return v
                p2 = _p.get("Properties")
                if isinstance(p2, dict):
                    v = p2.get(prop_key)
                    if v is not None:
                        return v

            return None
        outer_metadata = first_record if first_record else {}
        executor_max = outer_metadata.get("executorMax")
        executor_min = outer_metadata.get("executorMin")
        if executor_max is not None:
            try:
                executor_max = int(executor_max)
            except (ValueError, TypeError):
                executor_max = None
        if executor_min is not None:
            try:
                executor_min = int(executor_min)
            except (ValueError, TypeError):
                executor_min = None
        if executor_max is None and spark_props:
            prop_max = spark_props.get("spark.dynamicAllocation.maxExecutors") or spark_props.get("spark.executor.instances")
            if prop_max is not None:
                try:
                    executor_max = int(prop_max)
                except (ValueError, TypeError):
                    pass
        if executor_min is None and spark_props:
            prop_min = spark_props.get("spark.dynamicAllocation.minExecutors") or spark_props.get("spark.dynamicAllocation.initialExecutors")
            if prop_min is not None:
                try:
                    executor_min = int(prop_min)
                except (ValueError, TypeError):
                    pass
        is_high_concurrency = outer_metadata.get("isHighConcurrencyEnabled")
        if is_high_concurrency is not None and isinstance(is_high_concurrency, str):
            is_high_concurrency = is_high_concurrency.lower() == "true"
        elif is_high_concurrency is None:
            is_high_concurrency = False

        # Prefer the Spark config property when present.
        # User requirement: derive high concurrency from spark.trident.highconcurrency.enabled
        # (Fabric logs may carry it on ApplicationStart Spark Properties or JobStart Properties).
        hc_prop = _first_nonnull_prop("spark.trident.highconcurrency.enabled")
        if hc_prop is not None:
            try:
                if isinstance(hc_prop, bool):
                    is_high_concurrency = hc_prop
                else:
                    is_high_concurrency = str(hc_prop).strip().lower() == "true"
            except Exception:
                pass
        metadata_payload = {
            "applicationId": app_id,
            "applicationName": app_name,
            "artifactId": outer_metadata.get("artifactId"),
            "artifactType": outer_metadata.get("artifactType"),
            "capacityId": outer_metadata.get("capacityId"),
            "executorMax": executor_max,
            "executorMin": executor_min,
            "fabricEnvId": outer_metadata.get("fabricEnvId"),
            "fabricLivyId": outer_metadata.get("fabricLivyId"),
            "fabricTenantId": outer_metadata.get("fabricTenantId"),
            "fabricWorkspaceId": outer_metadata.get("fabricWorkspaceId"),
            "isHighConcurrencyEnabled": is_high_concurrency,
            "spark.native.enabled": _first_nonnull_prop("spark.native.enabled"),
            "spark.databricks.delta.autoCompact.enabled": _first_nonnull_prop("spark.databricks.delta.autoCompact.enabled"),
            "spark.microsoft.delta.targetFileSize.adaptive.enabled": _first_nonnull_prop("spark.microsoft.delta.targetFileSize.adaptive.enabled"),
            "spark.microsoft.delta.optimize.fast.enabled": _first_nonnull_prop("spark.microsoft.delta.optimize.fast.enabled"),
            "spark.microsoft.delta.optimize.fileLevelTarget.enabled": _first_nonnull_prop("spark.microsoft.delta.optimize.fileLevelTarget.enabled"),
            "spark.microsoft.delta.stats.collect.extended": _first_nonnull_prop("spark.microsoft.delta.stats.collect.extended"),
            "spark.microsoft.delta.snapshot.driverMode.enabled": _first_nonnull_prop("spark.microsoft.delta.snapshot.driverMode.enabled"),
            "spark.sql.parquet.vorder.default": _first_nonnull_prop("spark.sql.parquet.vorder.default"),
            "spark.microsoft.delta.optimizeWrite.enabled": _first_nonnull_prop("spark.microsoft.delta.optimizeWrite.enabled"),
            "spark.databricks.delta.optimizeWrite.enabled": _first_nonnull_prop("spark.databricks.delta.optimizeWrite.enabled"),
            "spark.databricks.delta.optimizeWrite.partitioned.enabled": _first_nonnull_prop("spark.databricks.delta.optimizeWrite.partitioned.enabled"),
            "spark.fabric.resourceProfile": _first_nonnull_prop("spark.fabric.resourceProfile"),
        }
    else:
        app_name = "Unknown Application"
        spark_props = {}
        metadata_payload = {
            "applicationId": app_id,
            "applicationName": "Unknown Application",
            "artifactId": None, "artifactType": None, "capacityId": None,
            "executorMax": None, "executorMin": None, "fabricEnvId": None,
            "fabricLivyId": None, "fabricTenantId": None, "fabricWorkspaceId": None,
            "isHighConcurrencyEnabled": False, "spark.native.enabled": None,
            "spark.databricks.delta.autoCompact.enabled": None,
            "spark.microsoft.delta.targetFileSize.adaptive.enabled": None,
            "spark.microsoft.delta.optimize.fast.enabled": None,
            "spark.microsoft.delta.optimize.fileLevelTarget.enabled": None,
            "spark.microsoft.delta.stats.collect.extended": None,
            "spark.microsoft.delta.snapshot.driverMode.enabled": None,
            "spark.sql.parquet.vorder.default": None,
            "spark.microsoft.delta.optimizeWrite.enabled": None,
            "spark.databricks.delta.optimizeWrite.enabled": None,
            "spark.databricks.delta.optimizeWrite.partitioned.enabled": None,
            "spark.fabric.resourceProfile": None,
        }

    out_rows.append({"applicationId": app_id, "dataset": "metadata", "payload_json": json.dumps(metadata_payload)})

    # ---- Handle missing start event ----
    if not has_start:
        out_rows.append({"applicationId": app_id, "dataset": "errors", "payload_json": json.dumps({
            "applicationID": app_id,
            "error": "Missing SparkListenerApplicationStart event"
        })})
        task_events = [props for ev, _, props in events if ev == "SparkListenerTaskEnd" and isinstance(props, dict)]
        if task_events:
            task_durations = []
            exec_times = []
            for task in task_events:
                task_info = task.get("Task Info", {})
                task_metrics = task.get("Task Metrics", {})
                launch_time = _to_float(task_info.get("Launch Time", 0))
                finish_time = _to_float(task_info.get("Finish Time", 0))
                if finish_time > launch_time > 0:
                    task_durations.append((finish_time - launch_time) / 1000.0)
                exec_time = _to_float(task_metrics.get("Executor Run Time", 0)) / 1000.0
                if exec_time > 0:
                    exec_times.append(exec_time)
            total_duration = sum(task_durations) if task_durations else 0.0
            total_executor_time = sum(exec_times) if exec_times else 0.0
            duration_min = int(total_duration // 60)
            duration_sec = int(total_duration % 60)
            duration_str = f"{duration_min}m {duration_sec}s"
            wallclock_min = int(total_executor_time // 60)
            wallclock_sec = int(total_executor_time % 60)
            wallclock_str = f"{wallclock_min}m {wallclock_sec}s"
        else:
            duration_str = "0m 0s"
            wallclock_str = "0m 0s"
        default_summary = {
            "stage_id": 0, "stage_attempt_id": 0, "num_tasks": 0, "successful_tasks": 0, "failed_tasks": 0,
            "min_duration_sec": 0.0, "max_duration_sec": 0.0, "avg_duration_sec": 0.0, "p75_duration_sec": 0.0,
            "avg_shuffle_read_mb": 0.0, "max_shuffle_read_mb": 0.0, "avg_shuffle_read_records": 0.0, "max_shuffle_read_records": 0,
            "avg_shuffle_write_mb": 0.0, "max_shuffle_write_mb": 0.0, "avg_shuffle_write_records": 0.0, "max_shuffle_write_records": 0,
            "avg_input_mb": 0.0, "max_input_mb": 0.0, "avg_input_records": 0.0, "max_input_records": 0,
            "avg_output_mb": 0.0, "max_output_mb": 0.0, "avg_output_records": 0.0, "max_output_records": 0,
            "min_launch_time": 0, "max_finish_time": 0, "num_executors": 0, "stage_execution_time_sec": 0.0, "app_id": app_id
        }
        out_rows.append({"applicationId": app_id, "dataset": "summary", "payload_json": json.dumps(default_summary)})
        out_rows.append({"applicationId": app_id, "dataset": "metrics", "payload_json": json.dumps({
            "app_id": app_id, "metric": "Application Duration (sec)", "value": 0.0
        })})
        prediction_record = {
            "Executor Count": 1,
            "Executor Multiplier": "1.0x (Current - Error State)",
            "Estimated Executor WallClock": wallclock_str,
            "Estimated Total Duration": duration_str,
            "app_id": app_id
        }
        out_rows.append({"applicationId": app_id, "dataset": "predictions", "payload_json": json.dumps(prediction_record)})
        out_rows.append({"applicationId": app_id, "dataset": "recommendations", "payload_json": json.dumps({
            "app_id": app_id, "recommendation": "Missing SparkListenerApplicationStart event - limited analysis available"
        })})
        return pd.DataFrame(out_rows)

    # ---- Duration computation ----
    start_ts = next((ts for ev, ts, _ in events if ev == "SparkListenerApplicationStart"), None)
    end_ts = next((ts for ev, ts, _ in events if ev == "SparkListenerApplicationEnd"), None)
    if start_ts is not None and end_ts is not None:
        app_duration_sec = max(0.0, (_to_float(end_ts) - _to_float(start_ts)) / 1000.0)
    else:
        ts_vals = [_to_float(ts) for _, ts, _ in events if ts is not None]
        ts_vals = [t for t in ts_vals if t > 0]
        app_duration_sec = max(0.0, (max(ts_vals) - min(ts_vals)) / 1000.0) if ts_vals else 0.0

    # ---- Event extraction ----
    task_props = [props for ev, _, props in events if ev == "SparkListenerTaskEnd" and isinstance(props, dict)]
    stage_props = [props for ev, _, props in events if ev == "SparkListenerStageCompleted" and isinstance(props, dict)]
    job_props = [props for ev, _, props in events if ev == "SparkListenerJobEnd" and isinstance(props, dict)]
    task_count = len(task_props)
    stage_count = len(stage_props)
    job_count = len(job_props)

    # ---- Streaming detection ----
    streaming_confidence = 0
    streaming_signals = []
    streaming_query_events = [ev for ev, _, _ in events if "StreamingQueryListener" in str(ev) or "streaming.StreamingQuery" in str(ev)]
    if streaming_query_events:
        streaming_confidence += 10
        streaming_signals.append(f"StreamingQueryListener events ({len(streaming_query_events)})")
    streaming_stage_keywords = [
        "statestoresave", "statestorerestore", "statestorerdd",
        "writestream", "readstream", "streaming",
        "microbatch", "microbatchexecution",
        "continuousexecution", "streamingquery", "streamexecution"
    ]
    state_store_stages = []
    for stage in stage_props:
        stage_info = stage.get("Stage Info", {})
        stage_name = str(stage_info.get("Stage Name", "")).lower()
        stage_details = str(stage_info.get("Details", "")).lower()
        if any(keyword in stage_name or keyword in stage_details for keyword in streaming_stage_keywords):
            stage_id = stage_info.get("Stage ID")
            if stage_id not in state_store_stages:
                state_store_stages.append(stage_id)
    if state_store_stages:
        streaming_confidence += 10
        streaming_signals.append(f"Streaming operations in {len(state_store_stages)} stages")
    if app_duration_sec > 0 and job_count > 0:
        jobs_per_minute = (job_count / app_duration_sec) * 60
        if jobs_per_minute > 10:
            streaming_confidence += 3
            streaming_signals.append(f"High job frequency ({jobs_per_minute:.1f}/min)")
        elif jobs_per_minute > 5:
            streaming_confidence += 2
    if app_duration_sec > 0 and stage_count > 0:
        stages_per_second = stage_count / app_duration_sec
        if stages_per_second > 0.5:
            streaming_confidence += 2
    if job_count > 50 and stage_count > 50:
        stage_job_ratio = stage_count / max(1, job_count)
        if 0.8 < stage_job_ratio < 1.5:
            streaming_confidence += 5
            streaming_signals.append(f"Micro-batch pattern ({job_count} jobs, {stage_count} stages)")
        elif job_count > 80:
            streaming_confidence += 3
    app_name_lower = app_name.lower() if app_name else ""
    if any(keyword in app_name_lower for keyword in ["stream", "checkpoint", "readstream", "writestream"]):
        streaming_confidence += 2
    is_streaming_job = streaming_confidence >= 5
    if is_streaming_job and streaming_signals:
        print(f"   Streaming job detected (confidence: {streaming_confidence}): {', '.join(streaming_signals)}")

    # ---- Streaming stats ----
    streaming_stats = []
    if is_streaming_job:
        for ev, ts, props in events:
            if "QueryProgressEvent" in str(ev) or "streaming" in str(ev).lower():
                try:
                    progress = props.get("progress", {}) if isinstance(props, dict) else {}
                    if progress:
                        batch_id = progress.get("batchId", progress.get("id", -1))
                        run_id = progress.get("runId", "unknown")
                        name = progress.get("name", "unnamed_query")
                        timestamp = progress.get("timestamp", ts)
                        batch_duration = progress.get("batchDuration", 0)
                        num_input_rows = progress.get("numInputRows", 0)
                        input_rows_per_second = progress.get("inputRowsPerSecond", 0.0)
                        process_rows_per_second = progress.get("processedRowsPerSecond", 0.0)
                        state_operators = progress.get("stateOperators", [])
                        total_state_rows = 0
                        total_state_memory = 0
                        for state_op in state_operators:
                            if isinstance(state_op, dict):
                                total_state_rows += _to_int(state_op.get("numRowsTotal", 0))
                                total_state_memory += _to_int(state_op.get("memoryUsedBytes", 0))
                        sink = progress.get("sink", {})
                        sink_description = sink.get("description", "unknown") if isinstance(sink, dict) else "unknown"
                        streaming_stats.append({
                            "app_id": app_id, "batch_id": batch_id, "run_id": run_id,
                            "query_name": name, "timestamp": timestamp,
                            "batch_duration_ms": batch_duration, "num_input_rows": num_input_rows,
                            "input_rows_per_second": input_rows_per_second,
                            "processed_rows_per_second": process_rows_per_second,
                            "state_rows_total": total_state_rows, "state_memory_bytes": total_state_memory,
                            "sink_description": sink_description
                        })
                except Exception:
                    pass
        for stat in streaming_stats:
            out_rows.append({"applicationId": app_id, "dataset": "streaming_stats", "payload_json": json.dumps(stat)})

    # ---- Task metrics ----
    exec_run_times_sec = []
    cpu_times_sec = []
    gc_times_ms = []
    executor_ids = set()
    for p in task_props:
        tm = p.get("Task Metrics", {}) if isinstance(p.get("Task Metrics"), dict) else {}
        ti = p.get("Task Info", {}) if isinstance(p.get("Task Info"), dict) else {}
        exec_time = _to_float(tm.get("Executor Run Time"), 0.0) / 1000.0
        cpu_time = _to_float(tm.get("Executor CPU Time"), 0.0) / 1000000000.0
        gc_time = _to_float(tm.get("JVM GC Time"), 0.0)
        exec_run_times_sec.append(exec_time)
        cpu_times_sec.append(cpu_time)
        gc_times_ms.append(gc_time)
        executor_ids.add(str(ti.get("Executor ID", "unknown")))

    total_exec = float(sum(exec_run_times_sec)) if exec_run_times_sec else 0.0
    total_cpu = float(sum(cpu_times_sec)) if cpu_times_sec else 0.0
    total_gc_ms = float(sum(gc_times_ms)) if gc_times_ms else 0.0
    executor_count = len([e for e in executor_ids if e != "unknown"])
    if executor_count == 0 and task_count > 0:
        executor_count = 1

    executor_cores_per_executor = get_executor_cores_config()
    try:
        if app_start_props and isinstance(app_start_props, dict):
            sp = app_start_props.get("Spark Properties", {})
            if isinstance(sp, dict):
                cc = sp.get("spark.executor.cores")
                if cc is not None:
                    executor_cores_per_executor = int(cc)
    except (ValueError, TypeError, KeyError):
        pass

    executor_eff = (total_cpu / total_exec) if total_exec > 0 else 0.0
    gc_overhead = ((total_gc_ms / 1000.0) / total_exec) if total_exec > 0 else 0.0
    parallelism_score = min(1.0, (task_count / max(1, executor_count * executor_cores_per_executor))) if executor_count > 0 else 0.0
    if len(exec_run_times_sec) > 1:
        avg_task_time = sum(exec_run_times_sec) / len(exec_run_times_sec)
        max_task_time = max(exec_run_times_sec)
        task_skew = (max_task_time / avg_task_time) if avg_task_time > 0 else 1.0
    else:
        task_skew = 1.0

    # ---- Stage summaries ----
    if stage_count > 0:
        for p in stage_props:
            stage_info = p.get("Stage Info", {})
            stage_id = _to_int(stage_info.get("Stage ID", 0))
            stage_attempt_id = _to_int(stage_info.get("Stage Attempt ID", 0))
            stage_tasks = [props for ev, _, props in events
                           if ev == "SparkListenerTaskEnd" and isinstance(props, dict)
                           and _to_int(props.get("Stage ID", -1)) == stage_id]
            if not stage_tasks:
                continue
            task_durations = []
            shuffle_read_bytes = []
            shuffle_read_records = []
            shuffle_write_bytes = []
            shuffle_write_records = []
            input_bytes = []
            input_records = []
            output_bytes = []
            output_records = []
            launch_times = []
            finish_times = []
            executor_ids_stage = set()
            successful_count = 0
            failed_count = 0
            for task in stage_tasks:
                task_info = task.get("Task Info", {})
                task_metrics = task.get("Task Metrics", {})
                if task_info.get("Failed", False):
                    failed_count += 1
                else:
                    successful_count += 1
                launch_time = _to_float(task_info.get("Launch Time", 0))
                finish_time = _to_float(task_info.get("Finish Time", 0))
                if finish_time > launch_time > 0:
                    task_durations.append((finish_time - launch_time) / 1000.0)
                    launch_times.append(launch_time)
                    finish_times.append(finish_time)
                executor_ids_stage.add(str(task_info.get("Executor ID", "unknown")))
                shuffle_read = task_metrics.get("Shuffle Read Metrics", {})
                if shuffle_read:
                    shuffle_read_bytes.append(_to_float(shuffle_read.get("Total Bytes Read", 0)) / (1024 * 1024))
                    shuffle_read_records.append(_to_float(shuffle_read.get("Total Records Read", 0)))
                shuffle_write = task_metrics.get("Shuffle Write Metrics", {})
                if shuffle_write:
                    shuffle_write_bytes.append(_to_float(shuffle_write.get("Shuffle Bytes Written", 0)) / (1024 * 1024))
                    shuffle_write_records.append(_to_float(shuffle_write.get("Shuffle Records Written", 0)))
                input_m = task_metrics.get("Input Metrics", {})
                if input_m:
                    input_bytes.append(_to_float(input_m.get("Bytes Read", 0)) / (1024 * 1024))
                    input_records.append(_to_float(input_m.get("Records Read", 0)))
                output_m = task_metrics.get("Output Metrics", {})
                if output_m:
                    output_bytes.append(_to_float(output_m.get("Bytes Written", 0)) / (1024 * 1024))
                    output_records.append(_to_float(output_m.get("Records Written", 0)))
            stage_submission = _to_float(stage_info.get("Submission Time", 0))
            stage_completion = _to_float(stage_info.get("Completion Time", 0))
            stage_execution_time = ((stage_completion - stage_submission) / 1000.0) if stage_completion > stage_submission > 0 else 0.0
            stage_summary = {
                "stage_id": stage_id, "stage_attempt_id": stage_attempt_id,
                "num_tasks": len(stage_tasks), "successful_tasks": successful_count, "failed_tasks": failed_count,
                "min_duration_sec": safe_min(task_durations), "max_duration_sec": safe_max(task_durations),
                "avg_duration_sec": safe_avg(task_durations), "p75_duration_sec": safe_percentile(task_durations, 75),
                "avg_shuffle_read_mb": safe_avg(shuffle_read_bytes), "max_shuffle_read_mb": safe_max(shuffle_read_bytes),
                "avg_shuffle_read_records": safe_avg(shuffle_read_records), "max_shuffle_read_records": safe_max_int(shuffle_read_records),
                "avg_shuffle_write_mb": safe_avg(shuffle_write_bytes), "max_shuffle_write_mb": safe_max(shuffle_write_bytes),
                "avg_shuffle_write_records": safe_avg(shuffle_write_records), "max_shuffle_write_records": safe_max_int(shuffle_write_records),
                "avg_input_mb": safe_avg(input_bytes), "max_input_mb": safe_max(input_bytes),
                "avg_input_records": safe_avg(input_records), "max_input_records": safe_max_int(input_records),
                "avg_output_mb": safe_avg(output_bytes), "max_output_mb": safe_max(output_bytes),
                "avg_output_records": safe_avg(output_records), "max_output_records": safe_max_int(output_records),
                "min_launch_time": int(min(launch_times)) if launch_times else 0,
                "max_finish_time": int(max(finish_times)) if finish_times else 0,
                "num_executors": len([e for e in executor_ids_stage if e != "unknown"]),
                "stage_execution_time_sec": stage_execution_time, "app_id": app_id
            }
            out_rows.append({"applicationId": app_id, "dataset": "summary", "payload_json": json.dumps(stage_summary)})
    else:
        default_summary = {
            "stage_id": 0, "stage_attempt_id": 0, "num_tasks": task_count,
            "successful_tasks": task_count, "failed_tasks": 0,
            "min_duration_sec": safe_min(exec_run_times_sec), "max_duration_sec": safe_max(exec_run_times_sec),
            "avg_duration_sec": safe_avg(exec_run_times_sec), "p75_duration_sec": safe_percentile(exec_run_times_sec, 75),
            "avg_shuffle_read_mb": 0.0, "max_shuffle_read_mb": 0.0, "avg_shuffle_read_records": 0.0, "max_shuffle_read_records": 0,
            "avg_shuffle_write_mb": 0.0, "max_shuffle_write_mb": 0.0, "avg_shuffle_write_records": 0.0, "max_shuffle_write_records": 0,
            "avg_input_mb": 0.0, "max_input_mb": 0.0, "avg_input_records": 0.0, "max_input_records": 0,
            "avg_output_mb": 0.0, "max_output_mb": 0.0, "avg_output_records": 0.0, "max_output_records": 0,
            "min_launch_time": 0, "max_finish_time": 0, "num_executors": executor_count,
            "stage_execution_time_sec": app_duration_sec, "app_id": app_id
        }
        out_rows.append({"applicationId": app_id, "dataset": "summary", "payload_json": json.dumps(default_summary)})

    # ---- Wall clock times ----
    executor_wall_clock_time = 0.0
    driver_wall_clock_time = app_duration_sec
    if task_props:
        task_launch_times = []
        task_finish_times = []
        for p in task_props:
            ti = p.get("Task Info", {})
            launch_time = _to_float(ti.get("Launch Time", 0))
            finish_time = _to_float(ti.get("Finish Time", 0))
            if launch_time > 0:
                task_launch_times.append(launch_time)
            if finish_time > 0:
                task_finish_times.append(finish_time)
        if task_launch_times and task_finish_times:
            executor_wall_clock_time = (max(task_finish_times) - min(task_launch_times)) / 1000.0
            if is_streaming_job:
                driver_wall_clock_time = -1.0
            else:
                driver_wall_clock_time = max(0.0, app_duration_sec - executor_wall_clock_time)

    # ---- Metrics ----
    metrics_list = [
        ("Application Duration (sec)", app_duration_sec),
        ("Task Count", float(task_count)),
        ("Stage Count", float(stage_count)),
        ("Job Count", float(job_count)),
        ("Executor Count", float(executor_count)),
        ("Executor Efficiency", float(max(0.0, min(1.0, executor_eff)))),
        ("Parallelism Score", float(max(0.0, min(1.0, parallelism_score)))),
        ("GC Overhead", float(max(0.0, min(1.0, gc_overhead)))),
        ("Task Skew Ratio", float(max(1.0, task_skew))),
        ("Total Executor Time (sec)", total_exec),
        ("Average Task Duration (sec)", float(sum(exec_run_times_sec) / len(exec_run_times_sec)) if exec_run_times_sec else 0.0),
        ("Executor Wall Clock Time (sec)", executor_wall_clock_time),
        ("Job Type", 1.0 if is_streaming_job else 0.0),
    ]
    if not is_streaming_job and driver_wall_clock_time >= 0:
        metrics_list.extend([
            ("Driver Wall Clock Time (sec)", driver_wall_clock_time),
            ("Driver Time %", (driver_wall_clock_time / max(1e-9, app_duration_sec)) * 100.0),
            ("Executor Time %", (executor_wall_clock_time / max(1e-9, app_duration_sec)) * 100.0),
        ])
    if is_streaming_job:
        if stage_count > 0:
            metrics_list.append(("Avg Micro-Batch Duration (sec)", app_duration_sec / stage_count))
        if job_count > 0:
            metrics_list.append(("Jobs Per Minute", (job_count / max(1.0, app_duration_sec)) * 60.0))
        driver_overhead_sec = max(0.0, app_duration_sec - executor_wall_clock_time)
        metrics_list.append(("Driver Wall Clock Time (sec)", driver_overhead_sec))
        metrics_list.append(("Driver Overhead %", (driver_overhead_sec / max(1e-9, app_duration_sec)) * 100.0))

    # Skew diagnostics
    if len(exec_run_times_sec) > 1:
        min_duration = float(min(exec_run_times_sec))
        max_duration = float(max(exec_run_times_sec))
        avg_duration = float(np.mean(exec_run_times_sec))
        median_duration = float(np.median(exec_run_times_sec))
        task_imbalance_ratio = max_duration / max(0.001, avg_duration)
        if task_imbalance_ratio > 10:
            task_msg = f"Some tasks taking {task_imbalance_ratio:.0f}x longer - Investigate task skew"
        elif task_imbalance_ratio > 3:
            task_msg = f"Tasks vary {task_imbalance_ratio:.1f}x in duration - Review data distribution"
        else:
            task_msg = f"Tasks balanced ({task_imbalance_ratio:.1f}x variation)"
        metrics_list.append((task_msg, task_imbalance_ratio))
        metrics_list.append(("Task Duration: Fastest (sec)", min_duration))
        metrics_list.append(("Task Duration: Slowest (sec)", max_duration))
        metrics_list.append(("Task Duration: Typical (median sec)", median_duration))

    shuffle_read_sizes = []
    shuffle_write_sizes = []
    input_data_sizes = []
    output_data_sizes = []
    for p in task_props:
        tm = p.get("Task Metrics", {}) if isinstance(p.get("Task Metrics"), dict) else {}
        shuffle_read = tm.get("Shuffle Read Metrics", {})
        if shuffle_read:
            shuffle_read_sizes.append(_to_float(shuffle_read.get("Total Bytes Read", 0)))
        shuffle_write = tm.get("Shuffle Write Metrics", {})
        if shuffle_write:
            shuffle_write_sizes.append(_to_float(shuffle_write.get("Shuffle Bytes Written", 0)))
        input_metrics = tm.get("Input Metrics", {})
        if input_metrics:
            input_data_sizes.append(_to_float(input_metrics.get("Bytes Read", 0)))
        output_metrics = tm.get("Output Metrics", {})
        if output_metrics:
            output_data_sizes.append(_to_float(output_metrics.get("Bytes Written", 0)))

    if len(shuffle_read_sizes) > 1:
        shuffle_read_avg = np.mean(shuffle_read_sizes)
        shuffle_read_max = max(shuffle_read_sizes)
        shuffle_read_ratio = shuffle_read_max / max(1, shuffle_read_avg)
        if shuffle_read_ratio > 5:
            sr_msg = f"Shuffle read imbalance {shuffle_read_ratio:.1f}x - Consider salting or repartitioning"
        elif shuffle_read_ratio > 2:
            sr_msg = f"Moderate shuffle variation {shuffle_read_ratio:.1f}x - Review join/groupBy keys"
        else:
            sr_msg = f"Shuffle reads balanced ({shuffle_read_ratio:.1f}x)"
        metrics_list.append((sr_msg, shuffle_read_ratio))
        metrics_list.append(("Shuffle Read: Typical Size (MB)", float(shuffle_read_avg / (1024 * 1024))))
        metrics_list.append(("Shuffle Read: Largest Size (MB)", float(shuffle_read_max / (1024 * 1024))))

    if len(shuffle_write_sizes) > 1:
        shuffle_write_avg = np.mean(shuffle_write_sizes)
        shuffle_write_max = max(shuffle_write_sizes)
        shuffle_write_ratio = shuffle_write_max / max(1, shuffle_write_avg)
        if shuffle_write_ratio > 5:
            sw_msg = f"Shuffle write imbalance {shuffle_write_ratio:.1f}x - Review partitioning strategy"
        elif shuffle_write_ratio > 2:
            sw_msg = f"Moderate write variation {shuffle_write_ratio:.1f}x - Some partitions writing more"
        else:
            sw_msg = f"Shuffle writes balanced ({shuffle_write_ratio:.1f}x)"
        metrics_list.append((sw_msg, shuffle_write_ratio))
        metrics_list.append(("Shuffle Write: Typical Size (MB)", float(shuffle_write_avg / (1024 * 1024))))
        metrics_list.append(("Shuffle Write: Largest Size (MB)", float(shuffle_write_max / (1024 * 1024))))

    if len(input_data_sizes) > 1:
        input_avg = np.mean(input_data_sizes)
        input_max = max(input_data_sizes)
        input_ratio = input_max / max(1, input_avg)
        if is_streaming_job:
            if input_ratio > 50:
                input_msg = f"Files varying {input_ratio:.0f}x in size - Fix file sizing in landing zone"
            elif input_ratio > 10:
                input_msg = f"File sizes vary {input_ratio:.0f}x - Use maxFilesPerTrigger"
            else:
                input_msg = f"File sizes consistent ({input_ratio:.1f}x variation)"
        else:
            if input_ratio > 50:
                input_msg = f"Input files vary {input_ratio:.0f}x - Run OPTIMIZE or repartition source"
            elif input_ratio > 10:
                input_msg = f"Moderate file variation {input_ratio:.0f}x - Consider coalescing small files"
            else:
                input_msg = f"Input files balanced ({input_ratio:.1f}x variation)"
        metrics_list.append((input_msg, input_ratio))
        metrics_list.append(("Input File: Typical Size (MB)", float(input_avg / (1024 * 1024))))
        metrics_list.append(("Input File: Largest Size (MB)", float(input_max / (1024 * 1024))))

    if len(output_data_sizes) > 1:
        output_avg = np.mean(output_data_sizes)
        output_max = max(output_data_sizes)
        output_ratio = output_max / max(1, output_avg)
        if output_avg > 1024 * 1024 or (not is_streaming_job and output_ratio > 5):
            if output_ratio > 10:
                output_msg = f"Output write imbalance {output_ratio:.0f}x - Review partitioning before writes"
            elif output_ratio > 3:
                output_msg = f"Some tasks writing {output_ratio:.1f}x more - Check partition distribution"
            else:
                output_msg = f"Output writes balanced ({output_ratio:.1f}x variation)"
            metrics_list.append((output_msg, output_ratio))
            metrics_list.append(("Output Write: Typical Size (MB)", float(output_avg / (1024 * 1024))))
            metrics_list.append(("Output Write: Largest Size (MB)", float(output_max / (1024 * 1024))))

    for k, v in metrics_list:
        out_rows.append({"applicationId": app_id, "dataset": "metrics", "payload_json": json.dumps({
            "app_id": app_id, "metric": k, "value": float(v)
        })})

    # ---- Scaling predictions ----
    if is_streaming_job:
        multipliers = [1.0]
    else:
        multipliers = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 4.0, 6.0, 8.0]

    base_total_work = max(1e-9, total_exec)
    base_duration = max(1e-9, app_duration_sec)
    base_executor_count = max(1, executor_count)

    features_pred = {
        'executor_efficiency': executor_eff,
        'parallelism_score': parallelism_score,
        'gc_overhead': gc_overhead,
        'task_skew': task_skew,
        'task_count': task_count,
        'executor_count': base_executor_count,
        'total_work': base_total_work,
        'app_duration': base_duration,
        'task_density': task_count / max(1, base_executor_count),
        'avg_task_duration': base_total_work / max(1, task_count) if task_count > 0 else 0.0,
        'work_efficiency': (base_total_work / max(1, base_executor_count)) / max(1.0, base_duration)
    }

    def classify_workload_type(f):
        if is_streaming_job:
            return 'streaming', 0.3
        elif f['executor_efficiency'] < 0.25:
            return 'cpu_starved', 0.1
        elif f['gc_overhead'] > 0.35:
            return 'memory_bound', 0.2
        elif f['task_skew'] > 4.0:
            return 'severely_skewed', 0.15
        elif f['task_skew'] > 2.5:
            return 'moderately_skewed', 0.5
        elif (1.0 - f['gc_overhead'] - f['executor_efficiency']) > 0.4 and f['parallelism_score'] > 0.6:
            return 'optimal_scalable', 0.85
        elif f['parallelism_score'] < 0.3:
            return 'starved_parallelism', 0.75
        elif f['task_density'] < 2.0:
            return 'underutilized', 0.7
        else:
            return 'balanced', 0.65

    workload_type, _ = classify_workload_type(features_pred)

    if task_count == 0:
        driver_ratio = 1.0
    elif features_pred['work_efficiency'] < 0.5:
        driver_ratio = 0.20 + (0.5 - features_pred['work_efficiency']) * 0.4
    elif features_pred['task_count'] < base_executor_count:
        driver_ratio = 0.15 + (1.0 - features_pred['task_density'] / 4.0) * 0.15
    else:
        driver_ratio = 0.08 + (1.0 - min(1.0, features_pred['parallelism_score'])) * 0.12

    driver_time_estimate = base_duration * min(0.5, driver_ratio)
    parallelizable_work = base_total_work * parallelism_score
    serial_work = base_total_work * (1.0 - parallelism_score)

    for m in multipliers:
        new_executor_count = max(1, int(base_executor_count * m))
        if workload_type == 'cpu_starved':
            scaling_efficiency = 0.10 + (features_pred['executor_efficiency'] * 0.2)
            coordination_overhead_factor = 2.0
        elif workload_type == 'memory_bound':
            scaling_efficiency = 0.20 + ((1.0 - features_pred['gc_overhead']) * 0.15)
            coordination_overhead_factor = 1.0
        elif workload_type == 'severely_skewed':
            scaling_efficiency = min(0.3, 1.0 / features_pred['task_skew'])
            coordination_overhead_factor = 1.0
        elif workload_type == 'moderately_skewed':
            scaling_efficiency = 0.50 + ((1.0 / features_pred['task_skew']) * 0.2)
            coordination_overhead_factor = 1.2
        elif workload_type == 'optimal_scalable':
            scaling_efficiency = 0.85 + (features_pred['parallelism_score'] * 0.1)
            coordination_overhead_factor = 0.3
        elif workload_type == 'starved_parallelism':
            max_scaling = min(m, features_pred['task_count'] / max(1, new_executor_count))
            scaling_efficiency = min(0.90, max_scaling / m)
            coordination_overhead_factor = 0.5
        elif workload_type == 'underutilized':
            scaling_efficiency = 0.70 + (features_pred['task_density'] / 4.0 * 0.15)
            coordination_overhead_factor = 0.6
        else:
            scaling_efficiency = 0.60 + (features_pred['parallelism_score'] * 0.15)
            coordination_overhead_factor = 0.8

        scaling_factor = 1.0 + (m - 1.0) * scaling_efficiency
        estimated_wallclock_per_executor = (parallelizable_work / (base_executor_count * scaling_factor)) + serial_work
        if workload_type == 'memory_bound':
            gc_penalty = 1.0 + (features_pred['gc_overhead'] * m * 0.25)
            estimated_wallclock_per_executor *= gc_penalty
        if workload_type == 'severely_skewed' and task_count > 0:
            avg_task_time_pred = base_total_work / task_count
            slowest_task_time = avg_task_time_pred * features_pred['task_skew']
            estimated_wallclock_per_executor = max(estimated_wallclock_per_executor, slowest_task_time * 0.75)
        coordination_overhead = ((new_executor_count / base_executor_count) - 1.0) * coordination_overhead_factor
        estimated_total_duration = estimated_wallclock_per_executor + driver_time_estimate + coordination_overhead
        serial_fraction = max(0.05, 1.0 - parallelism_score)
        amdahl_speedup = 1.0 / (serial_fraction + (1.0 - serial_fraction) / m)
        theoretical_min_duration = base_duration / amdahl_speedup
        estimated_total_duration = max(estimated_total_duration, theoretical_min_duration, driver_time_estimate)
        estimated_wallclock_per_executor = max(serial_work, estimated_wallclock_per_executor)

        confidence_factors = []
        if task_count > 100:
            confidence_factors.append(95)
        elif task_count > 20:
            confidence_factors.append(80)
        elif task_count > 5:
            confidence_factors.append(60)
        else:
            confidence_factors.append(30)
        if task_skew < 1.5:
            confidence_factors.append(95)
        elif task_skew < 3.0:
            confidence_factors.append(75)
        elif task_skew < 5.0:
            confidence_factors.append(50)
        else:
            confidence_factors.append(25)
        if executor_eff > 0.7:
            confidence_factors.append(90)
        elif executor_eff > 0.4:
            confidence_factors.append(70)
        else:
            confidence_factors.append(40)
        confidence_factors.append(max(50, 100 - abs(m - 1.0) * 10))
        prediction_confidence = sum(confidence_factors) / len(confidence_factors)

        duration_min = int(estimated_total_duration // 60)
        duration_sec_val = int(estimated_total_duration % 60)
        duration_str = f"{duration_min}m {duration_sec_val}s"
        wallclock_min = int(estimated_wallclock_per_executor // 60)
        wallclock_sec_val = int(estimated_wallclock_per_executor % 60)
        wallclock_str = f"{wallclock_min}m {wallclock_sec_val}s"

        if m == 1.0:
            multiplier_label = f"1.0x (Current - {workload_type.replace('_', ' ').title()})"
        elif m < 1.0:
            multiplier_label = f"{m:.2f}x (Scale Down)"
        else:
            confidence_emoji = "v" if prediction_confidence > 80 else ("~" if prediction_confidence > 60 else "?")
            multiplier_label = f"{m:.1f}x {confidence_emoji} (Scale Up)"

        out_rows.append({"applicationId": app_id, "dataset": "predictions", "payload_json": json.dumps({
            "Executor Count": new_executor_count,
            "Executor Multiplier": multiplier_label,
            "Estimated Executor WallClock": wallclock_str,
            "Estimated Total Duration": duration_str,
            "app_id": app_id
        })})

    # ---- Recommendations ----
    recommendations = []

    avg_task_duration = sum(exec_run_times_sec) / len(exec_run_times_sec) if exec_run_times_sec else 0.0
    max_task_duration = max(exec_run_times_sec) if exec_run_times_sec else 0.0

    if is_streaming_job:
        driver_time_pct = -1.0
        executor_time_pct = -1.0
        driver_bottleneck = False
    else:
        driver_time_pct = (driver_wall_clock_time / max(1e-9, app_duration_sec)) * 100.0
        executor_time_pct = (executor_wall_clock_time / max(1e-9, app_duration_sec)) * 100.0
        driver_bottleneck = driver_time_pct > 80.0

    job_type_label = "STREAMING" if is_streaming_job else "BATCH"
    detected_issues = []

    # Issue: Low CPU efficiency
    if executor_eff < 0.4:
        severity = 'CRITICAL' if executor_eff < 0.2 else 'HIGH'
        impact_score = (1 - executor_eff) * (200 if severity == 'CRITICAL' else 100) * min(10.0, app_duration_sec / 60.0) * executor_count
        detected_issues.append({
            'category': 'Resource Efficiency - CPU', 'severity': severity,
            'impact_score': impact_score, 'job_type': job_type_label,
            'root_cause': f"Low CPU utilization ({executor_eff:.1%}) - executors spending time on non-CPU work",
            'impact_metrics': f"Wasting {(1-executor_eff)*100:.0f}% of CPU capacity across {executor_count} executors",
            'fix_actions': [
                "Profile code to identify bottlenecks (serialization, I/O wait, locks)",
                "Reduce shuffle operations - minimize data movement",
                "DO NOT scale executors until CPU efficiency improves"
            ]
        })

    # Issue: Memory pressure
    if gc_overhead > 0.25:
        severity = 'CRITICAL' if gc_overhead > 0.4 else 'HIGH'
        impact_score = gc_overhead * (300 if severity == 'CRITICAL' else 150) * min(10.0, app_duration_sec / 60.0) * executor_count
        detected_issues.append({
            'category': 'Resource Efficiency - Memory', 'severity': severity,
            'impact_score': impact_score, 'job_type': job_type_label,
            'root_cause': f"High GC overhead ({gc_overhead:.1%}) indicates memory pressure",
            'impact_metrics': f"Losing {gc_overhead*app_duration_sec:.1f}s to garbage collection",
            'fix_actions': [
                "Increase spark.executor.memory by 50-100%",
                "Review caching strategy - use .cache() only when data is reused multiple times",
                "Call .unpersist() explicitly when cached data no longer needed"
            ]
        })

    # Issue: Driver bottleneck (batch only)
    if driver_bottleneck and not is_streaming_job:
        impact_score = (driver_time_pct / 100.0) * 500 * min(10.0, app_duration_sec / 60.0)
        detected_issues.append({
            'category': 'Architecture - Driver Overhead', 'severity': 'CRITICAL',
            'impact_score': impact_score, 'job_type': 'BATCH',
            'root_cause': f"Driver coordination takes {driver_time_pct:.0f}% of runtime - executors idle",
            'impact_metrics': f"Executors idle for {driver_time_pct:.0f}% of job ({driver_wall_clock_time:.0f}s)",
            'fix_actions': [
                "Reduce shuffle stage count with .coalesce() before actions",
                "Use broadcast joins for small tables",
                "Avoid .collect()/.take() on large datasets - use .write() instead",
                "Scaling executors will NOT help - driver is the bottleneck"
            ]
        })

    # Issue: Low parallelism
    if parallelism_score < 0.4:
        severity = 'HIGH' if parallelism_score < 0.2 else 'MEDIUM'
        impact_score = (1 - parallelism_score) * min(10.0, executor_count) * (180 if severity == 'HIGH' else 120)
        detected_issues.append({
            'category': 'Architecture - Parallelism', 'severity': severity,
            'impact_score': impact_score, 'job_type': job_type_label,
            'root_cause': f"Low parallelism ({parallelism_score:.1%}) - only {task_count} tasks for {executor_count} executors",
            'impact_metrics': f"Executors underutilized - need 2-4 tasks per executor core",
            'fix_actions': [
                f"Increase spark.sql.shuffle.partitions to at least {executor_count * 4}",
                f"Use .repartition({executor_count * 4}) to increase parallelism"
            ]
        })

    detected_issues.sort(key=lambda x: x['impact_score'], reverse=True)

    if detected_issues:
        primary = detected_issues[0]
        recommendations.append(f"PRIMARY ISSUE: {primary['category']} [{primary['severity']}]")
        recommendations.append(f"Root Cause: {primary['root_cause']}")
        recommendations.append(f"Impact: {primary['impact_metrics']}")
        for i, action in enumerate(primary['fix_actions'], 1):
            recommendations.append(f"  Fix {i}: {action}")
        if len(detected_issues) > 1:
            recommendations.append(f"\nSECONDARY ISSUES ({len(detected_issues)-1} total):")
            for i, issue in enumerate(detected_issues[1:4], 1):
                recommendations.append(f"  {i}. {issue['category']} [{issue['severity']}]: {issue['root_cause']}")
                recommendations.append(f"     Fix: {issue['fix_actions'][0]}")
    else:
        recommendations.append("No critical performance issues detected.")

    performance_score = (
        (executor_eff * 30) + (parallelism_score * 30) +
        ((1.0 - min(1.0, gc_overhead)) * 20) + ((1.0 / max(1.0, task_skew)) * 20)
    )
    summary_text = "EXCELLENT" if performance_score > 75 else ("GOOD" if performance_score > 50 else "NEEDS OPTIMIZATION")
    recommendations.append(
        f"\nPERFORMANCE SUMMARY: {summary_text} ({performance_score:.0f}/100) | "
        f"CPU: {executor_eff:.1%} | Parallelism: {parallelism_score:.1%} | "
        f"GC: {gc_overhead:.1%} | Skew: {task_skew:.1f}x"
    )

    for recommendation_text in recommendations:
        out_rows.append({"applicationId": app_id, "dataset": "recommendations", "payload_json": json.dumps({
            "app_id": app_id, "recommendation": recommendation_text
        })})

    return pd.DataFrame(out_rows)

# -------------------------------------------
# Step 5: Execute PARALLEL processing using groupBy.applyInPandas
# -------------------------------------------
if after_count > 0:
    print(f"Proceeding with {after_count} new event records for processing")
    print(f"PARALLEL PROCESSING: Using Spark parallelism for {unique_app_ids} applications")

    work_df = (
        event_log_df
        .select(
            col("applicationId_raw").alias("applicationId"),
            col("records")
        )
        .repartition(col("applicationId"))
        .cache()
    )

    print(f"EXECUTING PARALLEL PROCESSING for all applications...")

    result_df = (
        work_df
        .groupBy("applicationId")
        .applyInPandas(per_app_analyzer, schema=OUTPUT_SCHEMA)
        .cache()
    )

    processed_app_count = result_df.select("applicationId").distinct().count()
    print(f"Parallel processing complete! Processed {processed_app_count} applications")

    # -------------------------------------------
    # Step 6: Schema Validation & Write to Kusto
    # -------------------------------------------
    print("SCHEMA VALIDATION & KUSTO WRITE...")

    # Metadata
    metadata_out = (
        result_df.filter(col("dataset") == lit("metadata"))
        .select(F.from_json(col("payload_json"), METADATA_SCHEMA).alias("j"))
        .select("j.*")
    )
    if metadata_out.limit(1).count() > 0:
        print(f"Writing {metadata_out.count()} metadata records")
        write_kusto_df(metadata_out, "sparklens_metadata", mode="Append")

    # Summary
    summary_out = (
        result_df.filter(col("dataset") == lit("summary"))
        .select(F.from_json(col("payload_json"), SUMMARY_SCHEMA).alias("j"))
        .select("j.*")
    )
    if summary_out.limit(1).count() > 0:
        print(f"Writing {summary_out.count()} stage summary records")
        write_kusto_df(summary_out, "sparklens_summary", mode="Append")

    # Metrics
    metrics_out = (
        result_df.filter(col("dataset") == lit("metrics"))
        .select(F.from_json(col("payload_json"), METRICS_SCHEMA).alias("j"))
        .select("j.*")
    )
    if metrics_out.limit(1).count() > 0:
        print(f"Writing {metrics_out.count()} metrics records")
        write_kusto_df(metrics_out, "sparklens_metrics", mode="Append")

    # Predictions
    pred_out = (
        result_df.filter(col("dataset") == lit("predictions"))
        .select(F.from_json(col("payload_json"), PREDICTIONS_SCHEMA).alias("j"))
        .select("j.*")
    )
    if pred_out.limit(1).count() > 0:
        print(f"Writing {pred_out.count()} prediction records")
        write_kusto_df(pred_out, "sparklens_predictions", mode="Append")

    # Recommendations
    rec_out = (
        result_df.filter(col("dataset") == lit("recommendations"))
        .select(F.from_json(col("payload_json"), RECOMMENDATIONS_SCHEMA).alias("j"))
        .select("j.*")
    )
    if rec_out.limit(1).count() > 0:
        print(f"Writing {rec_out.count()} recommendation records")
        write_kusto_df(rec_out, "sparklens_recommedations", mode="Append")

    # Errors
    errors_schema = StructType([
        StructField("applicationID", StringType(), True),
        StructField("error", StringType(), True),
    ])
    err_out = (
        result_df.filter(col("dataset") == lit("errors"))
        .select(F.from_json(col("payload_json"), errors_schema).alias("j"))
        .select("j.*")
    )
    if err_out.limit(1).count() > 0:
        print(f"Writing {err_out.count()} error records")
        write_kusto_df(err_out, "sparklens_errors", mode="Append")

    print("\nPARALLEL PROCESSING COMPLETE!")
    print(f"   All {unique_app_ids} applications processed using Spark parallelism")
    print(f"   Each application analyzed by separate executor threads")
    print(f"   All results written to Kusto tables")

    # Cleanup
    work_df.unpersist()
    result_df.unpersist()
    event_log_df.unpersist()
    print("Memory cleanup completed")
'''),
]
